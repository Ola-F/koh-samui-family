window.ATTRACTIONS = [
  {
    "name": "בסיס קוסמוי",
    "destination": "koh_samui",
    "category_he": "בסיס",
    "category": "בסיס",
    "score": null,
    "tags": [],
    "hours": "",
    "phone": "",
    "link": "https://www.google.com/maps?q=The%20Gardens%20by%20Samui%20Beach%20Properties%20Bang%20Rak",
    "why": "",
    "reviews": "",
    "icon": "🏠"
  },
  {
    "name": "בסיס בנגקוק",
    "destination": "bangkok",
    "category_he": "בסיס",
    "category": "בסיס",
    "score": null,
    "tags": [],
    "hours": "",
    "phone": "",
    "link": "https://www.google.com/maps?q=Gate43%20Airport%20Hotel%20Bangkok",
    "why": "",
    "reviews": "",
    "icon": "🏠"
  },
  {
    "name": "בסיס קראבי",
    "destination": "krabi",
    "category_he": "בסיס",
    "category": "בסיס",
    "score": null,
    "tags": [],
    "hours": "",
    "phone": "",
    "link": "https://www.google.com/maps?q=Ao%20Nang%20Krabi",
    "why": "",
    "reviews": "",
    "icon": "🏠"
  },
  {
    "name": "Bang Rak Beach",
    "destination": "koh_samui",
    "category_he": "חופים",
    "category": "חופים",
    "score": 4,
    "tags": [
      "water",
      "stroller"
    ],
    "hours": "כל היום",
    "phone": "",
    "link": "https://maps.google.com/?q=Bang+Rak+Beach+Koh+Samui",
    "why": "חוף קרוב מאוד לקפיצות קצרות, שקיעות וימים רגועים.",
    "reviews": "נראה מתאים למשפחות וקיבל רושם חיובי מספיק כדי להיכנס לרשימה."
  },
  {
    "name": "Bophut Beach",
    "destination": "koh_samui",
    "category_he": "חופים",
    "category": "חופים",
    "score": 5,
    "tags": [
      "water",
      "stroller"
    ],
    "hours": "כל היום",
    "phone": "",
    "link": "https://maps.google.com/?q=Bophut+Beach+Koh+Samui",
    "why": "חוף משפחתי + הליכה/אוכל ליד Fisherman’s Village.",
    "reviews": "נראה מתאים למשפחות וקיבל רושם חיובי מספיק כדי להיכנס לרשימה."
  },
  {
    "name": "Choeng Mon Beach",
    "destination": "koh_samui",
    "category_he": "חופים",
    "category": "חופים",
    "score": 5,
    "tags": [
      "water",
      "stroller"
    ],
    "hours": "כל היום",
    "phone": "",
    "link": "https://maps.google.com/?q=Choeng+Mon+Beach+Koh+Samui",
    "why": "מפרץ שקט עם מים רדודים יחסית – מתאים במיוחד לילדים קטנים.",
    "reviews": "נראה מתאים למשפחות וקיבל רושם חיובי מספיק כדי להיכנס לרשימה."
  },
  {
    "name": "Mae Nam Beach",
    "destination": "koh_samui",
    "category_he": "חופים",
    "category": "חופים",
    "score": 4,
    "tags": [
      "water",
      "stroller"
    ],
    "hours": "כל היום",
    "phone": "",
    "link": "https://maps.google.com/?q=Mae+Nam+Beach+Koh+Samui",
    "why": "חוף ארוך ושקט יותר, פחות ‘סצנה’.",
    "reviews": "נראה מתאים למשפחות וקיבל רושם חיובי מספיק כדי להיכנס לרשימה."
  },
  {
    "name": "Lipa Noi Beach",
    "destination": "koh_samui",
    "category_he": "חופים",
    "category": "חופים",
    "score": 5,
    "tags": [
      "water",
      "stroller"
    ],
    "hours": "כל היום",
    "phone": "",
    "link": "https://maps.google.com/?q=Lipa+Noi+Beach+Koh+Samui",
    "why": "חוף שנחשב ידידותי לשחייה (לעיתים רדוד מאוד) – יום שלם בצד השקט של האי.",
    "reviews": "נראה מתאים למשפחות וקיבל רושם חיובי מספיק כדי להיכנס לרשימה."
  },
  {
    "name": "Crystal Bay (Silver Beach)",
    "destination": "koh_samui",
    "category_he": "חופים",
    "category": "חופים",
    "score": 4,
    "tags": [
      "water",
      "stroller"
    ],
    "hours": "כל היום",
    "phone": "",
    "link": "https://maps.google.com/?q=Crystal+Bay+Silver+Beach+Koh+Samui",
    "why": "חוף יפהפה ‘גלויה’ – אופציה ליום מיוחד.",
    "reviews": "נראה מתאים למשפחות וקיבל רושם חיובי מספיק כדי להיכנס לרשימה."
  },
  {
    "name": "Chi Samui (Bang Rak)",
    "destination": "koh_samui",
    "category_he": "מסעדות חוף",
    "category": "מסעדות חוף",
    "score": 5,
    "tags": [
      "water"
    ],
    "hours": "לבדיקה",
    "phone": "",
    "link": "https://maps.google.com/?q=Chi+Samui+Bang+Rak",
    "why": "מסעדה/ביץ׳ קלאב עם חוף ובריכה – נוח למשפחות.",
    "reviews": "נראה מתאים למשפחות וקיבל רושם חיובי מספיק כדי להיכנס לרשימה."
  },
  {
    "name": "CoCo Tam’s (Bophut)",
    "destination": "koh_samui",
    "category_he": "מסעדות חוף",
    "category": "מסעדות חוף",
    "score": 5,
    "tags": [
      "water"
    ],
    "hours": "לבדיקה",
    "phone": "",
    "link": "https://maps.google.com/?q=CoCo+Tam's+Bophut+Koh+Samui",
    "why": "אווירה על החול בבופוט – מעולה לשקיעה/ערב מוקדם.",
    "reviews": "נראה מתאים למשפחות וקיבל רושם חיובי מספיק כדי להיכנס לרשימה."
  },
  {
    "name": "The Shack",
    "destination": "koh_samui",
    "category_he": "מסעדות חוף",
    "category": "מסעדות חוף",
    "score": 4,
    "tags": [
      "water"
    ],
    "hours": "לבדיקה",
    "phone": "",
    "link": "https://maps.google.com/?q=The+Shack+Koh+Samui",
    "why": "קז׳ואל, ‘בלי פוזה’ – נעים עם ילדים.",
    "reviews": "נראה מתאים למשפחות וקיבל רושם חיובי מספיק כדי להיכנס לרשימה."
  },
  {
    "name": "KohCo Beach Club",
    "destination": "koh_samui",
    "category_he": "מסעדות חוף",
    "category": "מסעדות חוף",
    "score": 4,
    "tags": [
      "water"
    ],
    "hours": "לבדיקה",
    "phone": "",
    "link": "https://maps.google.com/?q=KohCo+Beach+Club+Koh+Samui",
    "why": "יום רגוע על הים – אופציה לשבת בנוחות.",
    "reviews": "נראה מתאים למשפחות וקיבל רושם חיובי מספיק כדי להיכנס לרשימה."
  },
  {
    "name": "Hacienda Beach Restaurant",
    "destination": "koh_samui",
    "category_he": "מסעדות חוף",
    "category": "מסעדות חוף",
    "score": 4,
    "tags": [
      "water"
    ],
    "hours": "לבדיקה",
    "phone": "",
    "link": "https://maps.google.com/?q=Hacienda+Beach+Restaurant+Koh+Samui",
    "why": "אוכל פשוט וטוב על החוף – מתאים למשפחות.",
    "reviews": "נראה מתאים למשפחות וקיבל רושם חיובי מספיק כדי להיכנס לרשימה."
  },
  {
    "name": "Maya Kids Club (Fisherman’s Village, Bophut)",
    "destination": "koh_samui",
    "category_he": "משחקיות וסדנאות",
    "category": "משחקיות וסדנאות",
    "score": 5,
    "tags": [
      "ac"
    ],
    "hours": "כל יום 08:00–19:00",
    "phone": "+66 62 221 9750",
    "link": "https://maps.google.com/?q=Maya+Kids+Club+Koh+Samui",
    "why": "מועדון ילדים/משחקייה ממוזגת ב-Fisherman’s Village – מעולה להפסקה של שעה–שעתיים.",
    "reviews": "נראה מתאים למשפחות וקיבל רושם חיובי מספיק כדי להיכנס לרשימה."
  },
  {
    "name": "Clever Kids Playroom (Mae Nam)",
    "destination": "koh_samui",
    "category_he": "משחקיות וסדנאות",
    "category": "משחקיות וסדנאות",
    "score": 4,
    "tags": [
      "ac"
    ],
    "hours": "א׳–ה׳ 09:00–19:00, ו׳ סגור, שבת 09:00–19:00 (ד׳ פיצול שעות)",
    "phone": "",
    "link": "https://maps.google.com/?q=Clever+Kids+Playroom+Mae+Nam+Koh+Samui",
    "why": "משחקייה נישתית לשגרה של חודש – כיף לכמה שעות.",
    "reviews": "נראה מתאים למשפחות וקיבל רושם חיובי מספיק כדי להיכנס לרשימה."
  },
  {
    "name": "Lotus’s (Tesco Lotus) – אזור משחקים לילדים",
    "destination": "koh_samui",
    "category_he": "קניות",
    "category": "קניות",
    "score": "check",
    "tags": [
      "ac",
      "ac",
      "supermarket"
    ],
    "hours": "09:00–22:00",
    "phone": "077 245 400",
    "link": "https://maps.google.com/?q=Tesco+Lotus+Koh+Samui+playground",
    "why": "פתרון ממוזג 'על הדרך' כשעושים קניות/סידורים – בחלק מהסניפים יש אזור משחקים/קידס זון.",
    "reviews": "מקום שנמצא רלוונטי למשפחות, אבל כדאי לבדוק פרטים עדכניים לפני הגעה."
  },
  {
    "name": "Central Festival Samui – Kids Area",
    "destination": "koh_samui",
    "category_he": "קניות",
    "category": "קניות",
    "score": 4,
    "tags": [
      "ac",
      "mall"
    ],
    "hours": "11:00–21:00",
    "phone": "+66 77 962 777",
    "link": "https://maps.google.com/?q=Central+Festival+Samui+kids+playground",
    "why": "קניון ממוזג עם אזורי ילדים – טוב כשצריך מזגן וקניות.",
    "reviews": "נראה מתאים למשפחות וקיבל רושם חיובי מספיק כדי להיכנס לרשימה."
  },
  {
    "name": "Holiday Inn Resort Samui – Playground",
    "destination": "koh_samui",
    "category_he": "משחקיות וסדנאות",
    "category": "משחקיות וסדנאות",
    "score": 4,
    "tags": [
      "ac"
    ],
    "hours": "כל יום 09:00–21:00",
    "phone": "+66 77 951 777",
    "link": "https://maps.google.com/?q=Holiday+Inn+Resort+Koh+Samui+playground",
    "why": "מגרש משחקים בריזורט – אופציה ליום ריזורט/בילוי נינוח.",
    "reviews": "נראה מתאים למשפחות וקיבל רושם חיובי מספיק כדי להיכנס לרשימה."
  },
  {
    "name": "Na Muang Waterfalls",
    "destination": "koh_samui",
    "category_he": "טבע",
    "category": "טבע",
    "score": 4,
    "tags": [],
    "hours": "כל יום 09:00–17:00",
    "phone": "",
    "link": "https://maps.google.com/?q=Na+Muang+Waterfall+Koh+Samui",
    "why": "טבע ירוק ומפלים – שינוי אווירה מהחופים.",
    "reviews": "נראה מתאים למשפחות וקיבל רושם חיובי מספיק כדי להיכנס לרשימה."
  },
  {
    "name": "Secret Buddha Garden (Ta Nim)",
    "destination": "koh_samui",
    "category_he": "טבע",
    "category": "טבע",
    "score": 4,
    "tags": [],
    "hours": "לבדיקה",
    "phone": "",
    "link": "https://maps.google.com/?q=Secret+Buddha+Garden+Koh+Samui",
    "why": "גן פסלים מסתורי בהרים – חוויה סקרנית לילדים.",
    "reviews": "נראה מתאים למשפחות וקיבל רושם חיובי מספיק כדי להיכנס לרשימה."
  },
  {
    "name": "Samui Elephant Sanctuary",
    "destination": "koh_samui",
    "category_he": "חיות",
    "category": "חיות",
    "score": 5,
    "tags": [],
    "hours": "כל יום 09:00–17:00",
    "phone": "+66 95 269 8343",
    "link": "https://www.samuielephantsanctuary.org",
    "why": "מפגש פילים עם דגש על הצלה וללא רכיבה/מופעים (לפי הפרסומים).",
    "reviews": "נראה מתאים למשפחות וקיבל רושם חיובי מספיק כדי להיכנס לרשימה."
  },
  {
    "name": "Paradise Park Farm",
    "destination": "koh_samui",
    "category_he": "חיות",
    "category": "חיות",
    "score": 3,
    "tags": [],
    "hours": "כל יום 09:00–17:00",
    "phone": "+66 81 255 1222",
    "link": "https://maps.google.com/?q=Paradise+Park+Farm+Koh+Samui",
    "why": "חיות, נוף ונקודות צילום – יום גיוון.",
    "reviews": "נראה מתאים למשפחות וקיבל רושם חיובי מספיק כדי להיכנס לרשימה."
  },
  {
    "name": "Tropical Kaleidoscope",
    "destination": "koh_samui",
    "category_he": "משחקיות וסדנאות",
    "category": "משחקיות וסדנאות",
    "score": 4,
    "tags": [],
    "hours": "לבדיקה",
    "phone": "",
    "link": "https://maps.google.com/?q=Tropical+Kaleidoscope+Koh+Samui",
    "why": "חוויה נישתית צבעונית/אמנותית – מתאימה לילדים סקרנים.",
    "reviews": "נראה מתאים למשפחות וקיבל רושם חיובי מספיק כדי להיכנס לרשימה."
  },
  {
    "name": "Kidomo Kids Club",
    "destination": "koh_samui",
    "category_he": "משחקיות וסדנאות",
    "category": "משחקיות וסדנאות",
    "score": "check",
    "tags": [
      "ac"
    ],
    "hours": "שבת–חמישי 10:00–18:00, ראשון 12:00–17:00, שישי סגור",
    "phone": "+66 91 393 2000",
    "link": "https://www.facebook.com/people/Kidomo-Kids-Club/61557885639437/",
    "why": "קלאב ילדים/משחקייה לפי עמוד פייסבוק. מתאים להשלמת אופציות לחודש.",
    "reviews": "מקום שנמצא רלוונטי למשפחות, אבל כדאי לבדוק פרטים עדכניים לפני הגעה."
  },
  {
    "name": "City of Bricks – LEGO Playroom",
    "destination": "koh_samui",
    "category_he": "משחקיות וסדנאות",
    "category": "משחקיות וסדנאות",
    "score": "check",
    "tags": [],
    "hours": "לבדיקה",
    "phone": "",
    "link": "https://www.google.com/maps?q=City+of+bricks+LEGO+playroom/+Kid%27s+Club,+10/81,+Mae+Nam,+Surat+Thani+84330",
    "why": "משחקיית LEGO/חלל משחק לפי גוגל מפות – יכול להחזיק ילדים כמה שעות.",
    "reviews": "מקום שנמצא רלוונטי למשפחות, אבל כדאי לבדוק פרטים עדכניים לפני הגעה."
  },
  {
    "name": "Beavers Animal Cafe",
    "destination": "koh_samui",
    "category_he": "חיות",
    "category": "חיות",
    "score": "check",
    "tags": [
      "ac"
    ],
    "hours": "לבדיקה",
    "phone": "",
    "link": "https://www.facebook.com/beaversanimalcafe",
    "why": "בית קפה עם חיות לפי עמוד פייסבוק.",
    "reviews": "מקום שנמצא רלוונטי למשפחות, אבל כדאי לבדוק פרטים עדכניים לפני הגעה."
  },
  {
    "name": "Cat Cafe by CatWorld",
    "destination": "koh_samui",
    "category_he": "חיות",
    "category": "חיות",
    "score": "check",
    "tags": [],
    "hours": "לבדיקה",
    "phone": "",
    "link": "https://www.facebook.com/groups/2714665732153676/user/61575732334095/",
    "why": "בית קפה/חוויה סביב חתולים (מקור: קבוצת פייסבוק) – עשוי להיות נחמד לילדים שאוהבים בעלי חיים.",
    "reviews": "מקום שנמצא רלוונטי למשפחות, אבל כדאי לבדוק פרטים עדכניים לפני הגעה."
  },
  {
    "name": "LEO & LILY",
    "destination": "koh_samui",
    "category_he": "משחקיות וסדנאות",
    "category": "משחקיות וסדנאות",
    "score": "check",
    "tags": [],
    "hours": "לבדיקה",
    "phone": "",
    "link": "https://www.facebook.com/groups/328042461124951/user/61563343420157/",
    "why": "פעילות/חוג (כולל אזכור לחוג בישול לילדים) – שווה לבדיקה בזמן שהות ארוכה.",
    "reviews": "מקום שנמצא רלוונטי למשפחות, אבל כדאי לבדוק פרטים עדכניים לפני הגעה."
  },
  {
    "name": "Lite Samui",
    "destination": "koh_samui",
    "category_he": "משחקיות וסדנאות",
    "category": "משחקיות וסדנאות",
    "score": "check",
    "tags": [
      "stroller",
      "ac",
      "ac"
    ],
    "hours": "לבדיקה",
    "phone": "",
    "link": "https://www.facebook.com/profile.php?id=100090805450586",
    "why": "מקום/קהילה מקומית לילדים (על בסיס פייסבוק) – שווה לבדיקה לשעות משחק/פעילות.",
    "reviews": "מקום שנמצא רלוונטי למשפחות, אבל כדאי לבדוק פרטים עדכניים לפני הגעה."
  },
  {
    "name": "Fisherman’s Village Walking Street",
    "destination": "koh_samui",
    "category_he": "שווקים",
    "category": "שווקים",
    "score": "check",
    "tags": [
      "water"
    ],
    "hours": "שישי 17:00–23:00 (משוער)",
    "phone": "",
    "link": "https://maps.google.com/?q=Fisherman's+Village+Walking+Street+Koh+Samui",
    "why": "שוק ערב/Walking Street פופולרי: אוכל, דוכנים, אווירה – מתאים לטיול ערב עם ילדים.",
    "reviews": "מקום שנמצא רלוונטי למשפחות, אבל כדאי לבדוק פרטים עדכניים לפני הגעה."
  },
  {
    "name": "Lamai Night Market",
    "destination": "koh_samui",
    "category_he": "שווקים",
    "category": "שווקים",
    "score": "check",
    "tags": [],
    "hours": "כל יום 15:00–24:00 (משוער)",
    "phone": "+66 84 695 3502",
    "link": "https://maps.google.com/?q=Lamai+Night+Market+Koh+Samui",
    "why": "שוק ערב באיזור לאמאי – אוכל ודוכנים.",
    "reviews": "מקום שנמצא רלוונטי למשפחות, אבל כדאי לבדוק פרטים עדכניים לפני הגעה."
  },
  {
    "name": "Chaweng Night Market",
    "destination": "koh_samui",
    "category_he": "שווקים",
    "category": "שווקים",
    "score": "check",
    "tags": [],
    "hours": "כל יום (משוער) 11:00–01:00",
    "phone": "",
    "link": "https://maps.google.com/?q=Chaweng+Night+Market+Koh+Samui",
    "why": "אזור שוק/אוכל בערב בצ׳אוונג.",
    "reviews": "מקום שנמצא רלוונטי למשפחות, אבל כדאי לבדוק פרטים עדכניים לפני הגעה."
  },
  {
    "name": "Hin Lad Waterfall",
    "destination": "koh_samui",
    "category_he": "טבע",
    "category": "טבע",
    "score": "check",
    "tags": [],
    "hours": "לבדיקה",
    "phone": "",
    "link": "https://maps.google.com/?q=Hin+Lad+Waterfall+Koh+Samui",
    "why": "מפל/מסלול קצר יחסית, אופציה לטבע קליל.",
    "reviews": "מקום שנמצא רלוונטי למשפחות, אבל כדאי לבדוק פרטים עדכניים לפני הגעה."
  },
  {
    "name": "Carnival Beach Village",
    "destination": "koh_samui",
    "category_he": "מסעדות",
    "category": "מסעדות",
    "score": "check",
    "tags": [],
    "hours": "כל יום 09:00–22:00",
    "phone": "+66 95 282 4468",
    "link": "https://maps.google.com/?q=Carnival+Beach+Village+Koh+Samui",
    "why": "מסעדה/מתחם אוכל שנראית ידידותית למשפחות – נכנסה לרשימת ההמלצות שציינת.",
    "reviews": "מקום שנמצא רלוונטי למשפחות, אבל כדאי לבדוק פרטים עדכניים לפני הגעה."
  },
  {
    "name": "JOY's KITCHEN (MULAJOY)",
    "destination": "koh_samui",
    "category_he": "מסעדות",
    "category": "מסעדות",
    "score": "check",
    "tags": [],
    "hours": "ב׳–ש׳ 09:30–19:00 (א׳ סגור)",
    "phone": "+66 61 617 9909",
    "link": "https://maps.google.com/?q=MOM+TO+BE+Mulajoy+Samui",
    "why": "בית קפה/מסעדה שהופיעה בהמלצות שלך – עשוי להתאים לעצירה רגועה עם ילדים.",
    "reviews": "מקום שנמצא רלוונטי למשפחות, אבל כדאי לבדוק פרטים עדכניים לפני הגעה."
  },
  {
    "name": "Baannairai Farm & Café",
    "destination": "koh_samui",
    "category_he": "מסעדות",
    "category": "מסעדות",
    "score": 5,
    "tags": [],
    "hours": "כל יום 09:00–18:00 (ד׳ סגור)",
    "phone": "+66 86 479 2559",
    "link": "https://maps.google.com/?q=Baannairai+Farm+%26+Caf%C3%A9+Koh+Samui",
    "why": "קפה/חווה בסגנון משפחתי – לרוב מקומות כאלה מצליחים עם ילדים בזכות מרחב ואווירה קלילה.",
    "reviews": "נראה מתאים למשפחות וקיבל רושם חיובי מספיק כדי להיכנס לרשימה."
  },
  {
    "name": "Samui Pier (Restaurant/Cafe)",
    "destination": "koh_samui",
    "category_he": "מסעדות",
    "category": "מסעדות",
    "score": "check",
    "tags": [],
    "hours": "לבדיקה",
    "phone": "",
    "link": "https://maps.google.com/?q=Samui+Pier+restaurant+Koh+Samui",
    "why": "מקום שהופיע אצלך בהמלצות – יכול להתאים לארוחה קלילה/שקיעה.",
    "reviews": "מקום שנמצא רלוונטי למשפחות, אבל כדאי לבדוק פרטים עדכניים לפני הגעה."
  },
  {
    "name": "Suzette Samui",
    "destination": "koh_samui",
    "category_he": "מסעדות",
    "category": "מסעדות",
    "score": 5,
    "tags": [],
    "hours": "ג׳–א׳ 11:00–22:00 (ב׳ סגור)",
    "phone": "+66 95 361 4559",
    "link": "https://maps.google.com/?q=Suzette+Samui",
    "why": "ציינת שקראת שיש במקום גם אזור/משחקייה לילדים ושייתכן גם חוג בישול.",
    "reviews": "נראה מתאים למשפחות וקיבל רושם חיובי מספיק כדי להיכנס לרשימה."
  },
  {
    "name": "Santiburi Koh Samui – Day Pass",
    "destination": "koh_samui",
    "category_he": "ריזורטים עם Day Pass",
    "category": "ריזורטים עם Day Pass",
    "score": 5,
    "tags": [],
    "hours": "כל יום 09:00–17:00",
    "phone": "+66 77 425 031",
    "link": "https://maps.google.com/?q=Santiburi+Koh+Samui",
    "why": "בריכה ענקית וחוף Mae Nam; קרדיט לאוכל/שתייה ומועדון ילדים לפי סוג החבילה.",
    "reviews": "נראה מתאים למשפחות וקיבל רושם חיובי מספיק כדי להיכנס לרשימה."
  },
  {
    "name": "Tolani Resort Koh Samui (KOA Dining) – Day Pass",
    "destination": "koh_samui",
    "category_he": "ריזורטים עם Day Pass",
    "category": "ריזורטים עם Day Pass",
    "score": 4,
    "tags": [],
    "hours": "לבדיקה (בד״כ במהלך שעות הפעילות של KOA/הריזורט)",
    "phone": "",
    "link": "https://maps.google.com/?q=Tolani+Resort+Koh+Samui+KOA+Dining",
    "why": "יום “בריכה+חוף” במחיר נגיש יחסית, כולל קרדיט מלא לאוכל/שתייה.",
    "reviews": "נראה מתאים למשפחות וקיבל רושם חיובי מספיק כדי להיכנס לרשימה."
  },
  {
    "name": "Holiday Inn Resort Samui Bophut – Family Day Pass (לבדיקה)",
    "destination": "koh_samui",
    "category_he": "ריזורטים עם Day Pass",
    "category": "ריזורטים עם Day Pass",
    "score": "check",
    "tags": [],
    "hours": "לבדיקה מול המלון (טלפון/מייל באתר הרשמי)",
    "phone": "+66 77 951 777",
    "link": "https://maps.google.com/?q=Holiday+Inn+Resort+Samui+Bophut+Beach",
    "why": "אחד הריזורטים הכי “ילדים-במרכז”: Kids Club ממוזג, Splash Pad ומגרש משחקים.",
    "reviews": "מקום שנמצא רלוונטי למשפחות, אבל כדאי לבדוק פרטים עדכניים לפני הגעה."
  },
  {
    "name": "Outrigger Koh Samui Beach Resort – Day Pass (לבדיקה)",
    "destination": "koh_samui",
    "category_he": "ריזורטים עם Day Pass",
    "category": "ריזורטים עם Day Pass",
    "score": "check",
    "tags": [],
    "hours": "כל יום 10:00–22:00",
    "phone": "+66 77 458 560",
    "link": "https://maps.google.com/?q=Outrigger+Koh+Samui+Beach+Resort",
    "why": "אפשרות Day Pass במחיר נוח, עם פעילות יומית ואווירה רגועה.",
    "reviews": "מקום שנמצא רלוונטי למשפחות, אבל כדאי לבדוק פרטים עדכניים לפני הגעה."
  },
  {
    "name": "Central Festival Samui",
    "destination": "koh_samui",
    "category_he": "קניות",
    "category": "קניות",
    "score": 4,
    "tags": [
      "ac",
      "mall"
    ],
    "hours": "11:00–21:00",
    "phone": "+66 77 962 777",
    "link": "https://maps.google.com/?q=Central+Festival+Samui",
    "why": "קניון מרכזי וממוזג — פתרון מצוין ליום חם/גשום עם ילדים (חנויות, אוכל, שירותים נוחים).",
    "reviews": "נראה מתאים למשפחות וקיבל רושם חיובי מספיק כדי להיכנס לרשימה."
  },
  {
    "name": "Big C Supercenter Samui",
    "destination": "koh_samui",
    "category_he": "קניות",
    "category": "קניות",
    "score": 4,
    "tags": [
      "ac",
      "supermarket"
    ],
    "hours": "09:00–22:00",
    "phone": "077 960 711",
    "link": "https://maps.google.com/?q=Big+C+Supercenter+Samui",
    "why": "סופר/כלבו במחירים מקומיים — שימושי למשפחות (בגדי ילדים בסיסיים, צעצועים, ציוד יומיומי).",
    "reviews": "נראה מתאים למשפחות וקיבל רושם חיובי מספיק כדי להיכנס לרשימה."
  },
  {
    "name": "Lotus’s Samui",
    "destination": "koh_samui",
    "category_he": "קניות",
    "category": "קניות",
    "score": 4,
    "tags": [
      "ac",
      "supermarket"
    ],
    "hours": "09:00–22:00",
    "phone": "077 245 400",
    "link": "https://maps.google.com/?q=Lotus%27s+Samui",
    "why": "קניות יומיומיות נוחות במחירים מקומיים + אזורים ממוזגים ומזון מוכן.",
    "reviews": "נראה מתאים למשפחות וקיבל רושם חיובי מספיק כדי להיכנס לרשימה."
  },
  {
    "name": "Makro Food Service Samui",
    "destination": "koh_samui",
    "category_he": "קניות",
    "category": "קניות",
    "score": 4,
    "tags": [
      "ac",
      "supermarket"
    ],
    "hours": "06:00–22:00",
    "phone": "077 960 140",
    "link": "https://maps.google.com/?q=Makro+Koh+Samui",
    "why": "קניות גדולות למשפחה במחירים טובים (סיטונאות).",
    "reviews": "נראה מתאים למשפחות וקיבל רושם חיובי מספיק כדי להיכנס לרשימה."
  },
  {
    "name": "7‑Eleven Bang Rak (סניף מומלץ)",
    "destination": "koh_samui",
    "category_he": "קניות",
    "category": "קניות",
    "score": 4,
    "tags": [
      "supermarket"
    ],
    "hours": "",
    "phone": "",
    "link": "https://maps.google.com/?q=7-Eleven+Bang+Rak+Koh+Samui",
    "why": "אופציה נוחה לקניות יומיומיות למשפחה.",
    "reviews": "נראה מתאים למשפחות וקיבל רושם חיובי מספיק כדי להיכנס לרשימה."
  },
  {
    "name": "Lotus’s Express (Bang Rak)",
    "destination": "koh_samui",
    "category_he": "קניות",
    "category": "קניות",
    "score": 4,
    "tags": [
      "supermarket"
    ],
    "hours": "09:00–22:00",
    "phone": "077 245 400",
    "link": "https://maps.google.com/?q=Lotus's+Express+Bang+Rak+Koh+Samui",
    "why": "אופציה נוחה לקניות יומיומיות למשפחה.",
    "reviews": "נראה מתאים למשפחות וקיבל רושם חיובי מספיק כדי להיכנס לרשימה."
  },
  {
    "name": "Bang Rak Fresh Market",
    "destination": "koh_samui",
    "category_he": "קניות",
    "category": "קניות",
    "score": 4,
    "tags": [
      "shopping"
    ],
    "hours": "",
    "phone": "",
    "link": "https://maps.google.com/?q=Bang+Rak+Fresh+Market+Koh+Samui",
    "why": "אופציה נוחה לקניות יומיומיות למשפחה.",
    "reviews": "נראה מתאים למשפחות וקיבל רושם חיובי מספיק כדי להיכנס לרשימה."
  },
  {
    "name": "Makro Food Service Samui",
    "destination": "koh_samui",
    "category_he": "קניות",
    "category": "קניות",
    "score": 4,
    "tags": [
      "supermarket"
    ],
    "hours": "06:00–22:00",
    "phone": "077 960 140",
    "link": "https://maps.google.com/?q=Makro+Koh+Samui",
    "why": "אופציה נוחה לקניות יומיומיות למשפחה.",
    "reviews": "נראה מתאים למשפחות וקיבל רושם חיובי מספיק כדי להיכנס לרשימה."
  },
  {
    "name": "Big C Supercenter Samui",
    "destination": "koh_samui",
    "category_he": "קניות",
    "category": "קניות",
    "score": 4,
    "tags": [
      "supermarket"
    ],
    "hours": "09:00–22:00",
    "phone": "077 960 711",
    "link": "https://maps.google.com/?q=Big+C+Koh+Samui",
    "why": "אופציה נוחה לקניות יומיומיות למשפחה.",
    "reviews": "נראה מתאים למשפחות וקיבל רושם חיובי מספיק כדי להיכנס לרשימה."
  },
  {
    "name": "Lotus’s Samui",
    "destination": "koh_samui",
    "category_he": "קניות",
    "category": "קניות",
    "score": 4,
    "tags": [
      "supermarket"
    ],
    "hours": "09:00–22:00",
    "phone": "077 245 400",
    "link": "https://maps.google.com/?q=Lotus's+Koh+Samui",
    "why": "אופציה נוחה לקניות יומיומיות למשפחה.",
    "reviews": "נראה מתאים למשפחות וקיבל רושם חיובי מספיק כדי להיכנס לרשימה."
  },
  {
    "name": "Let’s Relax Spa Samui",
    "destination": "koh_samui",
    "category_he": "ספא & טיפוח",
    "category": "ספא & טיפוח",
    "score": 4,
    "tags": [
      "ac"
    ],
    "hours": "10:00–23:45",
    "phone": "+66 77 430 231",
    "link": "https://maps.google.com/?q=Let%27s+Relax+Spa+Koh+Samui",
    "why": "ספא מסודר (רשת). מתאים במיוחד לטיפולים קצרים כשנמצאים עם ילדים.",
    "reviews": "נראה מתאים למשפחות וקיבל רושם חיובי מספיק כדי להיכנס לרשימה."
  },
  {
    "name": "Health Land Samui (לבדיקה)",
    "destination": "koh_samui",
    "category_he": "ספא & טיפוח",
    "category": "ספא & טיפוח",
    "score": "check",
    "tags": [
      "ac"
    ],
    "hours": "",
    "phone": "",
    "link": "https://maps.google.com/?q=Health+Land+Spa+Koh+Samui",
    "why": "רשת ספא מוכרת. דורש בדיקה נקודתית של מדיניות ילדים וסניף.",
    "reviews": "מקום שנמצא רלוונטי למשפחות, אבל כדאי לבדוק פרטים עדכניים לפני הגעה."
  },
  {
    "name": "צמות/ציפורניים באזורים תיירותיים (לבדיקה)",
    "destination": "koh_samui",
    "category_he": "ספא & טיפוח",
    "category": "ספא & טיפוח",
    "score": "check",
    "tags": [],
    "hours": "",
    "phone": "",
    "link": "https://maps.google.com/?q=braids+nails+Koh+Samui+Chaweng",
    "why": "חוויה שילדים נהנים ממנה (צמות/ציפורניים). איכות משתנה בין מקומות.",
    "reviews": "מקום שנמצא רלוונטי למשפחות, אבל כדאי לבדוק פרטים עדכניים לפני הגעה."
  },
  {
    "name": "Haven Elephant Café & Restaurant",
    "destination": "koh_samui",
    "category_he": "חיות",
    "category": "חיות",
    "score": 5,
    "tags": [],
    "hours": "09:00–19:00",
    "phone": "+66 91 034 2526",
    "link": "https://www.google.com/maps/search/?api=1&query=Haven%20Elephant%20Caf%C3%A9%20%26%20Restaurant%20Koh%20Samui",
    "why": "קפה-מסעדה עם תצפית על פילים במתחם; חוויה מיוחדת לילדים, עם אפשרות לראות את הפילים מקרוב בזמן הארוחה.",
    "reviews": "נראה מתאים למשפחות וקיבל רושם חיובי מספיק כדי להיכנס לרשימה."
  },
  {
    "name": "Capybara Coffee Samui",
    "destination": "koh_samui",
    "category_he": "חיות",
    "category": "חיות",
    "score": "check",
    "tags": [],
    "hours": "",
    "phone": "",
    "link": "https://www.capybaracoffeethailand.com/capybara-coffee-samui/",
    "why": "בית קפה עם אינטראקציה עם קפיברות (ולעתים גם חיות נוספות). מתאים להפסקה של כשעה עם ילדים.",
    "reviews": "מקום שנמצא רלוונטי למשפחות, אבל כדאי לבדוק פרטים עדכניים לפני הגעה."
  },
  {
    "name": "Moon Salon",
    "destination": "koh_samui",
    "category_he": "ספא & טיפוח",
    "category": "ספא & טיפוח",
    "score": "check",
    "tags": [],
    "hours": "",
    "phone": "",
    "link": "",
    "why": "צמות/ציפורניים (למבוגרים).",
    "reviews": "מקום שנמצא רלוונטי למשפחות, אבל כדאי לבדוק פרטים עדכניים לפני הגעה."
  },
  {
    "name": "Madam Dum (ראש / רגליים)",
    "destination": "koh_samui",
    "category_he": "ספא & טיפוח",
    "category": "ספא & טיפוח",
    "score": "check",
    "tags": [],
    "hours": "",
    "phone": "",
    "link": "",
    "why": "מסאז׳ ראש/רגליים (למבוגרים).",
    "reviews": "מקום שנמצא רלוונטי למשפחות, אבל כדאי לבדוק פרטים עדכניים לפני הגעה."
  },
  {
    "name": "UniKids (Big C, Chaweng)",
    "destination": "koh_samui",
    "category_he": "משחקיות וסדנאות",
    "category": "משחקיות וסדנאות",
    "score": 4,
    "tags": [
      "ac"
    ],
    "hours": "א׳ 12:00–17:00 | ב׳–ה׳ 10:00–18:00 | ו׳ סגור | שבת 10:00–18:00",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=UniKids%20Big%20C%20Koh%20Samui",
    "why": "משחקייה פנימית בהירה ונקייה ליד Big C – נוחה במיוחד לימים חמים/גשומים ולשילוב עם קניות.",
    "reviews": "נראה מתאים למשפחות וקיבל רושם חיובי מספיק כדי להיכנס לרשימה."
  },
  {
    "name": "Move Time Club",
    "destination": "koh_samui",
    "category_he": "משחקיות וסדנאות",
    "category": "משחקיות וסדנאות",
    "score": "check",
    "tags": [
      "ac"
    ],
    "hours": "קפה/אזור משחק: 15:00–20:00 (סגור בשלישי)",
    "phone": "WhatsApp +66 80 853 0400",
    "link": "https://www.google.com/maps/search/?api=1&query=Move%20Time%20Club%20Maenam%20Koh%20Samui",
    "why": "מרכז פעילויות לילדים + בית קפה. מתאים לשעות אחה״צ, כולל גם פינת עבודה שקטה להורים.",
    "reviews": "מקום שנמצא רלוונטי למשפחות, אבל כדאי לבדוק פרטים עדכניים לפני הגעה."
  },
  {
    "name": "Siam Serpentarium",
    "destination": "בנקוק",
    "category_he": "חיות",
    "category": "חיות",
    "score": 4,
    "tags": [
      "ac"
    ],
    "hours": "לבדיקה",
    "phone": "",
    "link": "https://maps.google.com/?q=Siam+Serpentarium",
    "why": "מוזיאון נחשים ממוזג ומסודר ליד אזור שדה התעופה; לרוב לא עמוס.",
    "reviews": "נראה מתאים למשפחות וקיבל רושם חיובי מספיק כדי להיכנס לרשימה."
  },
  {
    "name": "Lat Krabang Park (Suan Phra Nakhon)",
    "destination": "בנקוק",
    "category_he": "טבע",
    "category": "טבע",
    "score": 4,
    "tags": [],
    "hours": "כל היום",
    "phone": "+66 2 326 9994",
    "link": "https://maps.google.com/?q=Lat+Krabang+Park+Suan+Phra+Nakhon",
    "why": "פארק מקומי שקט ונקי ליד Lat Krabang – מעולה להפסקה עם ילדים.",
    "reviews": "נראה מתאים למשפחות וקיבל רושם חיובי מספיק כדי להיכנס לרשימה."
  },
  {
    "name": "HarborLand – MEGA Bangna",
    "destination": "בנקוק",
    "category_he": "משחקיות וסדנאות",
    "category": "משחקיות וסדנאות",
    "score": 4,
    "tags": [
      "ac",
      "mall"
    ],
    "hours": "Mon–Fri 10:30–20:00 | Weekend 10:00–20:00",
    "phone": "(+66) 065 848 2000",
    "link": "https://maps.google.com/?q=MEGA+HarborLand+Megabangna",
    "why": "אחת המשחקיות הגדולות והמושקעות באזור; ממוזגת, נקייה ומגוונת לגילאי גן.",
    "reviews": "נראה מתאים למשפחות וקיבל רושם חיובי מספיק כדי להיכנס לרשימה."
  },
  {
    "name": "MEGA Bangna (קניון)",
    "destination": "בנקוק",
    "category_he": "קניות",
    "category": "קניות",
    "score": 4,
    "tags": [
      "ac",
      "mall"
    ],
    "hours": "לבדיקה",
    "phone": "",
    "link": "https://maps.google.com/?q=Mega+Bangna",
    "why": "קניון גדול ונוח למשפחות (ממוזג) עם הרבה אוכל ואפשרויות לילדים.",
    "reviews": "נראה מתאים למשפחות וקיבל רושם חיובי מספיק כדי להיכנס לרשימה."
  },
  {
    "name": "Chocolate Ville",
    "destination": "בנקוק",
    "category_he": "מסעדות",
    "category": "מסעדות",
    "score": 4,
    "tags": [],
    "hours": "לבדיקה",
    "phone": "",
    "link": "https://maps.google.com/?q=Chocolate+Ville+Bangkok",
    "why": "מקום משפחתי יפה עם אווירה, מרווח, טוב לעצירה עם ילדים (מומלץ להגיע מוקדם).",
    "reviews": "נראה מתאים למשפחות וקיבל רושם חיובי מספיק כדי להיכנס לרשימה."
  },
  {
    "name": "MK Restaurant (באזור Mega Bangna / Lat Krabang)",
    "destination": "בנקוק",
    "category_he": "מסעדות",
    "category": "מסעדות",
    "score": "check",
    "tags": [
      "ac",
      "mall"
    ],
    "hours": "לבדיקה",
    "phone": "לבדיקה",
    "link": "https://maps.google.com/?q=MK+Restaurant+Mega+Bangna",
    "why": "רשת סוקי פופולרית למשפחות – אוכל עדין, ילדים אוהבים לבשל ליד השולחן.",
    "reviews": "מקום שנמצא רלוונטי למשפחות, אבל כדאי לבדוק פרטים עדכניים לפני הגעה."
  },
  {
    "name": "Sizzler (Mega Bangna)",
    "destination": "בנקוק",
    "category_he": "מסעדות",
    "category": "מסעדות",
    "score": "check",
    "tags": [
      "ac",
      "mall"
    ],
    "hours": "לבדיקה",
    "phone": "לבדיקה",
    "link": "https://maps.google.com/?q=Sizzler+Mega+Bangna",
    "why": "תפריט מוכר לילדים, פתרון נוח לצהריים בתוך קניון.",
    "reviews": "מקום שנמצא רלוונטי למשפחות, אבל כדאי לבדוק פרטים עדכניים לפני הגעה."
  },
  {
    "name": "Siam Premium Outlets Bangkok",
    "destination": "בנקוק",
    "category_he": "קניות",
    "category": "קניות",
    "score": 4,
    "tags": [
      "ac",
      "mall"
    ],
    "hours": "ב׳–ו׳ 11:00–20:00 | ש׳–א׳ 10:00–20:00",
    "phone": "+66 2 082 8998",
    "link": "https://maps.google.com/?q=Siam+Premium+Outlets+Bangkok",
    "why": "אאוטלט גדול ליד שדה התעופה; נוח למשפחות (שירותים/מנוחה) ואפשר להסתובב בלי עומס של מרכז העיר.",
    "reviews": "נראה מתאים למשפחות וקיבל רושם חיובי מספיק כדי להיכנס לרשימה."
  },
  {
    "name": "Central Village – Bangkok Luxury Outlet",
    "destination": "בנקוק",
    "category_he": "קניות",
    "category": "קניות",
    "score": 4,
    "tags": [
      "ac",
      "mall"
    ],
    "hours": "כל יום 10:00–22:00",
    "phone": "+66 2 550 6555",
    "link": "https://maps.google.com/?q=Central+Village+Bangkok+Luxury+Outlet",
    "why": "אאוטלט קרוב לשדה התעופה; מרווח ונעים לטיול קצר עם ילדים, כולל אזור 'Siam playground' לפי האתר הרשמי.",
    "reviews": "נראה מתאים למשפחות וקיבל רושם חיובי מספיק כדי להיכנס לרשימה."
  },
  {
    "name": "Hua Takhe Old Market",
    "destination": "בנקוק",
    "category_he": "שווקים",
    "category": "שווקים",
    "score": 4,
    "tags": [],
    "hours": "א׳–ו׳ 06:00–17:00 | ש׳ 06:00–18:00",
    "phone": "",
    "link": "https://maps.google.com/?q=Hua+Takhe+Old+Market",
    "why": "שוק/אזור ישן על תעלה ב-Lat Krabang; הליכה קצרה, בתי קפה ואווירה מקומית בלי עומס של שווקים תיירותיים.",
    "reviews": "נראה מתאים למשפחות וקיבל רושם חיובי מספיק כדי להיכנס לרשימה."
  },
  {
    "name": "The Paseo Mall Lat Krabang",
    "destination": "בנקוק",
    "category_he": "קניות",
    "category": "קניות",
    "score": "check",
    "tags": [
      "ac",
      "mall"
    ],
    "hours": "כל יום 10:00–21:00",
    "phone": "+66 2 329 8999",
    "link": "https://maps.google.com/?q=The+Paseo+Mall+Lat+Krabang",
    "why": "קומיוניטי-מול קרוב ל-Lat Krabang; נוח לאוכל/סידורים עם ילדים בלי להיכנס למרכז.",
    "reviews": "מקום שנמצא רלוונטי למשפחות, אבל כדאי לבדוק פרטים עדכניים לפני הגעה."
  },
  {
    "name": "Robinson Lifestyle Lat Krabang",
    "destination": "בנקוק",
    "category_he": "קניות",
    "category": "קניות",
    "score": "check",
    "tags": [
      "ac",
      "shopping"
    ],
    "hours": "כל יום 10:00–21:00",
    "phone": "+66 2 320 7250",
    "link": "https://maps.google.com/?q=Robinson+Lifestyle+Latkrabang",
    "why": "קניון נוח באזור; אופציה טובה ליום חם/גשום, אוכל ומרחב להסתובבות.",
    "reviews": "מקום שנמצא רלוונטי למשפחות, אבל כדאי לבדוק פרטים עדכניים לפני הגעה."
  },
  {
    "name": "The First Lounge (Gate43 Hotel Restaurant)",
    "destination": "בנקוק",
    "category_he": "מסעדות",
    "category": "מסעדות",
    "score": "check",
    "tags": [
      "ac"
    ],
    "hours": "06:30–23:00",
    "phone": "+66 98 747 7214",
    "link": "https://maps.google.com/?q=Gate43+Airport+Hotel+The+First+Lounge",
    "why": "המסעדה של המלון – הכי קל עם ילדים אחרי טיסה/ערב עייף.",
    "reviews": "מקום שנמצא רלוונטי למשפחות, אבל כדאי לבדוק פרטים עדכניים לפני הגעה."
  },
  {
    "name": "Thai-Kor (The Paseo Mall)",
    "destination": "בנקוק",
    "category_he": "מסעדות",
    "category": "מסעדות",
    "score": "check",
    "tags": [
      "ac",
      "mall"
    ],
    "hours": "כל יום 10:00–21:00",
    "phone": "+66 2 346 4373",
    "link": "https://maps.google.com/?q=Thai-Kor+The+Paseo+Mall+Lat+Krabang",
    "why": "מסעדה קוריאנית בקניון – נוח עם ילדים, ממוזג, במיקום פרקטי.",
    "reviews": "מקום שנמצא רלוונטי למשפחות, אבל כדאי לבדוק פרטים עדכניים לפני הגעה."
  },
  {
    "name": "Tha Pom Khlong Song Nam (Thapom Klong Song Nam)",
    "destination": "krabi",
    "category_he": "טבע",
    "category": "טבע",
    "score": 4,
    "tags": [
      "water",
      "calm"
    ],
    "hours": "08:00–17:00",
    "phone": "+66 99 372 6989",
    "link": "https://www.google.com/maps/search/?api=1&query=Tha%20Pom%20Khlong%20Song%20Nam%20Krabi",
    "why": "אחד מאתרי הטבע הכי מיוחדים באזור: שבילי עץ קצרים מעל מים שקופים בגוון כחול-ירקרק, עם הרבה צל ותחושה רגועה. מתאים במיוחד למשפחה שמחפשת טבע יפה בלי מאמץ גדול.",
    "reviews": "רוב המבקרים מדגישים את הצלילות החריגה של המים ואת העובדה שזה מקום שנעים לטייל בו גם עם ילדים. החיסרון שחוזר הוא שבשעות העומס החוויה פחות קסומה, ולכן עדיף להגיע מוקדם."
  },
  {
    "name": "Khlong Rood (Klong Root / Khlong Rut) – Clear Water Kayak",
    "destination": "krabi",
    "category_he": "טבע",
    "category": "טבע",
    "score": 4,
    "tags": [
      "water",
      "calm"
    ],
    "hours": "08:00–18:00",
    "phone": "087-397-2969",
    "link": "https://www.google.com/maps/search/?api=1&query=Khlong%20Rood%20Krabi",
    "why": "חוויה יפה ושונה מחוף: קיאק במים צלולים מאוד בין עצים וצמחייה, עם תחושה רגועה ופוטוגנית. מתאים יותר ליום קליל של כמה שעות מאשר ליום אטרקציות עמוס.",
    "reviews": "מבקרים אוהבים את הצבע של המים ואת האווירה השקטה, במיוחד כשמגיעים מוקדם. מצד שני, חלקם מציינים שהקיאק עצמו הוא עיקר החוויה, כך שזה מתאים יותר למי שבא במיוחד בשביל השיט."
  },
  {
    "name": "Dragon’s Crest (Ngon Nak Nature Trail)",
    "destination": "krabi",
    "category_he": "טבע",
    "category": "טבע",
    "score": 4,
    "tags": [
      "challenging"
    ],
    "hours": "08:00–14:00",
    "phone": "+66 63 059 7062",
    "link": "https://www.google.com/maps/search/?api=1&query=Dragon%27s%20Crest%20Ngon%20Nak%20Nature%20Trail%20Krabi",
    "why": "זה המסלול של הוואו הנופי בקראבי, עם תצפית דרמטית במיוחד על הים, האיים והמצוקים. מתאים רק אם בא לכם מסלול אמיתי ולא טיול קצר עם ילד קטן.",
    "reviews": "מי שמסיים את העלייה כמעט תמיד כותב שהתצפית שווה את המאמץ. לצד זה יש הרבה אזכורים לחום, ללחות ולעלייה הממושכת, ולכן זה פחות מתאים ליום משפחתי נינוח."
  },
  {
    "name": "Khao Phanom Bencha National Park",
    "destination": "krabi",
    "category_he": "טבע",
    "category": "טבע",
    "score": 4,
    "tags": [
      "calm"
    ],
    "hours": "08:00–16:30",
    "phone": "+66 61 232 4901",
    "link": "https://www.google.com/maps/search/?api=1&query=Khao%20Phanom%20Bencha%20National%20Park",
    "why": "פארק לאומי ירוק ויפה שנותן תחושת ג׳ונגל אמיתית, עם שבילים, מפלים ואוויר אחר לגמרי מחופי האזור. טוב במיוחד אם רוצים יום טבע מוצל יחסית.",
    "reviews": "מבקרים אוהבים את הירוק, את התחושה הפחות מתוירת ואת האפשרות לשלב כמה נקודות באותו אזור. חלקם מציינים שלא כל השבילים מתאימים לכל גיל, ולכן שווה לבחור מראש מסלול קצר ופשוט."
  },
  {
    "name": "Huay To Waterfall (Khao Phanom Bencha NP)",
    "destination": "krabi",
    "category_he": "טבע",
    "category": "טבע",
    "score": 4,
    "tags": [
      "water"
    ],
    "hours": "08:30–16:30",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Huay%20To%20Waterfall%20Krabi",
    "why": "מפל יפה בתוך יער טרופי, עם אווירה קרירה יותר מהחוף ובריכות טבעיות באזור התחתון. מעולה כחלק מיום בפארק, במיוחד אם רוצים טבע בלי הליכה ארוכה מדי.",
    "reviews": "ביקורות רבות מדברות על מקום נעים, ירוק ופוטוגני, במיוחד אחרי גשם או בעונה רטובה. חלק מהמבקרים מזכירים שהמפל משתנה לפי העונה ושהחלקים העליונים כבר יותר מאתגרים."
  },
  {
    "name": "Emerald Pool (Sa Morakot) – Thung Teao Forest",
    "destination": "krabi",
    "category_he": "טבע",
    "category": "טבע",
    "score": 4,
    "tags": [
      "water"
    ],
    "hours": "10:00–15:30",
    "phone": "+66 98 041 8171",
    "link": "https://www.google.com/maps/search/?api=1&query=Emerald%20Pool%20Krabi%20Sa%20Morakot",
    "why": "אחת האטרקציות הכי מפורסמות באזור ולא סתם: בריכה טבעית בצבע אזמרגד בתוך יער, עם הליכה יחסית פשוטה במסלול מסודר. זו חוויה מאוד יפה, אבל עדיף להגיע מוקדם כדי ליהנות ממנה באמת.",
    "reviews": "אנשים מתלהבים מהצבע של המים ומהתחושה הייחודית של המקום. מה שחוזר שוב ושוב הוא שהשעות המאוחרות חמות ועמוסות יותר, ולכן הביקורות הטובות ביותר כמעט תמיד מגיעות ממי שהגיעו מוקדם."
  },
  {
    "name": "Klong Thom Hot Springs",
    "destination": "krabi",
    "category_he": "טבע",
    "category": "טבע",
    "score": 4,
    "tags": [
      "water",
      "calm"
    ],
    "hours": "06:00–18:00",
    "phone": "062 570 8175",
    "link": "https://www.google.com/maps/search/?api=1&query=Klong%20Thom%20Hot%20Springs%20Krabi",
    "why": "בריכות מים חמים בטבע, יותר עצירה רגועה ופחות אטרקציית חובה. טוב במיוחד בשילוב עם Emerald Pool, כי שתיהן באותו כיוון ויוצרות יום טבע נעים.",
    "reviews": "מבקרים אוהבים את התחושה המרגיעה ואת האפשרות לטבול כמה דקות בין העצים. חלקם כותבים שזה פחות מרשים כמקום יחיד בפני עצמו, אבל כשמשלבים עם האמרלד פול זה עובד מצוין."
  },
  {
    "name": "Ao Thalane – Mangrove Kayaking (Sea Kayak Krabi)",
    "destination": "krabi",
    "category_he": "טבע",
    "category": "טבע",
    "score": 4,
    "tags": [
      "water",
      "calm"
    ],
    "hours": "",
    "phone": "+66 89 724 8579",
    "link": "https://www.google.com/maps/search/?api=1&query=Sea%20Kayak%20Krabi%20Ao%20Thalane",
    "why": "שיט קיאקים רגוע בין מנגרובים, קירות אבן וגונות צרות שנותן זווית טבע אחרת על קראבי. מתאים במיוחד למי שמחפש נוף יפה בלי חוף, ובקצב שקט.",
    "reviews": "הרבה ביקורות מדברות על נוף מיוחד ואווירה שלווה, במיוחד כשאין רוח. מנגד, עם ילדים קטנים מאוד או ביום חם במיוחד, חלק מהמשפחות מרגישות שזה ארוך מדי ביחס לרמת העניין."
  },
  {
    "name": "Railay Beach",
    "destination": "krabi",
    "category_he": "חופים",
    "category": "חופים",
    "score": 5,
    "tags": [
      "calm",
      "water"
    ],
    "hours": "",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Railay%20Beach%20Krabi",
    "why": "אחד המקומות הכי יפים באזור, עם מצוקים דרמטיים, חול נעים ואווירה שאין באו נאנג עצמה. עצם ההגעה בסירה כבר מרגישה כמו חלק מהחוויה.",
    "reviews": "מבקרים מתלהבים מאוד מהמראה של החוף ומהתחושה המיוחדת של חצי אי בלי כבישים. הביקורות הפחות טובות בדרך כלל מתייחסות לעומס בשעות השיא, לכן שווה להגיע מוקדם או לקראת אחה״צ."
  },
  {
    "name": "Ao Nang Landmark Night Market",
    "destination": "krabi",
    "category_he": "שווקים",
    "category": "שווקים",
    "score": 4,
    "tags": [
      "calm"
    ],
    "hours": "17:00–23:00",
    "phone": "+66 88 982 8899",
    "link": "https://www.google.com/maps/search/?api=1&query=Ao%20Nang%20Landmark%20Night%20Market",
    "why": "בילוי ערב קל, פשוט ומאוד נוח למשפחות: הרבה דוכני אוכל, מקומות ישיבה, מוזיקה ואווירה חיה בלי מחויבות גדולה. טוב במיוחד כשרוצים ערב לא כבד אחרי יום טיול.",
    "reviews": "רוב המבקרים אוהבים את המבחר ואת זה שקל שכל אחד מוצא מה לאכול. יש גם הערות על כך שחלק מהדוכנים תיירותיים יותר ופחות מיוחדים, אבל כמקום ערב משפחתי זו בחירה מוצלחת."
  },
  {
    "name": "Khaothong Hill",
    "destination": "krabi",
    "category_he": "מסעדות",
    "category": "מסעדות",
    "score": 4,
    "tags": [
      "ac",
      "calm"
    ],
    "hours": "11:00–20:00",
    "phone": "+66 96 991 9365",
    "link": "https://maps.app.goo.gl/kdstxf27GXUrytWC6",
    "why": "אחת מנקודות הישיבה היפות באזור עם תצפית מרשימה, אוויר נעים יותר בשעות אחר הצהריים ואווירת שקיעה חזקה. מתאים מאוד ליום רגוע בלי הרבה הליכה.",
    "reviews": "אנשים חוזרים שוב ושוב על הנוף היפה ועל התחושה שמקבלים תמורה גבוהה בלי מאמץ. חלק מהביקורות מזכירות שירות איטי בשעות עמוסות, אבל כמעט תמיד מציינות שהנוף מפצה על זה."
  },
  {
    "name": "Andalay Beach Bar & Cafe",
    "destination": "krabi",
    "category_he": "מסעדות חוף",
    "category": "מסעדות חוף",
    "score": 4,
    "tags": [
      "calm",
      "water"
    ],
    "hours": "10:00–20:30",
    "phone": "+66 61 217 9779",
    "link": "https://www.google.com/maps/search/?api=1&query=Andalay%20Beach%20Bar%20%26%20Cafe%20Krabi",
    "why": "מסעדת חוף רגועה באזור שקט יותר, טובה במיוחד לשעות של שקיעה, משחק בחול וישיבה ארוכה יחסית בנחת. מתאימה למי שמעדיף אווירה רגועה על פני מקום טרנדי ורועש.",
    "reviews": "מבקרים מדגישים את הלוקיישן הנעים ואת האווירה המשפחתית. מה שחוזר פחות לטובה הוא שהאוכל נחשב טוב ולא תמיד מצטיין, כך שהערך המרכזי כאן הוא בעיקר החוף והאווירה."
  },
  {
    "name": "The Last Fisherman Bar (Ao Nang)",
    "destination": "krabi",
    "category_he": "מסעדות חוף",
    "category": "מסעדות חוף",
    "score": 4,
    "tags": [
      "calm",
      "water"
    ],
    "hours": "11:00–16:00, 17:30–22:00",
    "phone": "+66 81 458 0170",
    "link": "https://www.google.com/maps/search/?api=1&query=The%20Last%20Fisherman%20Bar%20Ao%20Nang",
    "why": "אחד המקומות הנוחים ביותר לשבת ממש על החוף באזור Ao Nang, עם שקיעה יפה ואווירה נינוחה. בחירה טובה לערב קליל בלי לחפש יותר מדי.",
    "reviews": "רוב הביקורות מחמיאות ללוקיישן ולתחושת החופשה, במיוחד בשקיעה. יש גם אזכורים לשירות משתנה בשעות עמוסות, ולכן עדיף להגיע מעט לפני הזמן החזק של הערב."
  },
  {
    "name": "Ao Nang Elephant Sanctuary",
    "destination": "krabi",
    "category_he": "חיות",
    "category": "חיות",
    "score": 4,
    "tags": [
      "calm"
    ],
    "hours": "09:00–17:00",
    "phone": "+66 65 390 9925",
    "link": "https://www.google.com/maps/search/?api=1&query=Ao%20Nang%20Elephant%20Sanctuary",
    "why": "מפגש עם פילים בסגנון יותר עדין ורגוע, עם דגש על האכלה ולמידה ולא על מופעים. מתאים למי שרוצה חוויית חיות אבל מעדיף מסגרת ממוסדת וברורה.",
    "reviews": "הביקורות החיוביות מציינות יחס נעים של הצוות וחוויה מרגשת לילדים. לצד זה, יש מבקרים שממליצים לקרוא היטב את אופי הפעילות מראש כדי לוודא שהיא תואמת את רמת האתיות שאתם מחפשים."
  },
  {
    "name": "Botany Cafe & Eatery",
    "destination": "krabi",
    "category_he": "מסעדות",
    "category": "מסעדות",
    "score": 4,
    "tags": [
      "calm"
    ],
    "hours": "09:00–18:00",
    "phone": "+66 94 509 1656",
    "link": "https://maps.google.com/?q=Botany+Cafe+%26+Eatery+Krabi",
    "why": "מקום ירוק, נעים ולא כבד, שמתאים מאוד לבראנץ׳ או עצירה רגועה עם ילדים בזכות הגינה ופינת המשחק הקטנה. אופציה טובה כשלא רוצים עוד מסעדת חוף.",
    "reviews": "מבקרים אוהבים את העיצוב, את האווירה השקטה ואת זה שקל לשבת שם עם ילדים. הביקורות פחות על מהירות שירות ויותר על העובדה שזה מקום שבאים אליו בשביל האווירה, לא בשביל ארוחה מהירה."
  },
  {
    "name": "Cooper’s Farm2Plate",
    "destination": "krabi",
    "category_he": "מסעדות",
    "category": "מסעדות",
    "score": 4,
    "tags": [
      "calm"
    ],
    "hours": "12:00–15:00, 18:00–21:00",
    "phone": "+66 98 998 9338",
    "link": "https://maps.google.com/?q=Cooper%E2%80%99s+Farm2Plate+Krabi",
    "why": "מסעדה נעימה ומטופחת בסגנון farm to table בתוך ריזורט אקולוגי, עם תחושה שקטה ומסודרת. טובה במיוחד למי שמחפש אוכל יותר מוקפד ואווירה רגועה.",
    "reviews": "הביקורות מחמיאות מאוד לסביבה, להצגה היפה של המנות ולאווירה הנעימה. מי שפחות מתחבר למטבח הטבעוני או המחירים של מקום ריזורטי עשוי פחות להתלהב."
  },
  {
    "name": "Much & Mellow Aloha",
    "destination": "krabi",
    "category_he": "מסעדות חוף",
    "category": "מסעדות חוף",
    "score": 4,
    "tags": [
      "calm"
    ],
    "hours": "08:00–18:00",
    "phone": "+66 84 293 2465",
    "link": "https://maps.google.com/?q=Much+%26+Mellow+Aloha+Krabi",
    "why": "קפה קליל ונעים עם אווירת חופש לא מחייבת, טוב לעצירה של בוקר או צהריים קלים. מתאים כשמחפשים מקום פשוט, יפה ולא עמוס מדי.",
    "reviews": "מבקרים מתארים מקום חמוד ופוטוגני עם אווירה רגועה. החיסרון העיקרי שחוזר הוא שלא מדובר ביעד קולינרי גדול, אלא במקום טוב ונעים לעצירה קצרה."
  },
  {
    "name": "The Fun Garden",
    "destination": "krabi",
    "category_he": "משחקיות וסדנאות",
    "category": "משחקיות וסדנאות",
    "score": 5,
    "tags": [
      "calm"
    ],
    "hours": "11:30–20:30",
    "phone": "+66 94 638 0103",
    "link": "https://maps.google.com/?q=The+Fun+Garden+Krabi",
    "why": "אחת התוספות הכי שימושיות למשפחות באזור: שילוב של משחקייה חיצונית ופנימית, מרחב פתוח, פינות יצירה ואפשרות אמיתית להעביר שם כמה שעות. מצוין ליום חם או ליום שצריך בו הפסקה מחופים.",
    "reviews": "הביקורות חוזרות על כך שזה מקום שכיף לילדים ושנעים גם להורים בזכות הקפה והמרחב. מי שמחפש מקום ממוזג בלבד צריך לזכור שחלק מהחוויה כאן הוא דווקא החוץ."
  },
  {
    "name": "23 Roasters Cafe Krabi",
    "destination": "krabi",
    "category_he": "מסעדות",
    "category": "מסעדות",
    "score": 4,
    "tags": [
      "calm"
    ],
    "hours": "08:15–17:30",
    "phone": "+66 63 786 6419",
    "link": "https://maps.google.com/?q=23+Roasters+Cafe+Krabi",
    "why": "אחד מבתי הקפה היותר אהובים באזור אם חשוב לכם קפה טוב באמת, מאפים ואווירה מוקפדת. מתאים במיוחד להורים שמחפשים עצירה איכותית ולא רק פונקציונלית.",
    "reviews": "המקום מקבל הרבה אהבה על הקפה, המאפים והעיצוב הנעים. פחות מדובר על מקום לילדים ויותר על עצירה טובה למבוגרים, לכן הוא עובד הכי טוב כשמשלבים עם פעילות אחרת."
  },
  {
    "name": "Din Daeng Doi",
    "destination": "krabi",
    "category_he": "טבע",
    "category": "טבע",
    "score": 4,
    "tags": [
      "water",
      "calm"
    ],
    "hours": "",
    "phone": "",
    "link": "https://maps.google.com/?q=Din+Daeng+Doi+Krabi",
    "why": "נקודת טבע פחות מוכרת עם מים זורמים, תחושת יער ושקט יחסי. מתאימה למי שאוהב לגלות מקומות פחות תיירותיים ופחות ״מסודרים״.",
    "reviews": "הביקורות החיוביות מדברות על טבע יפה ועל אווירה מקומית יותר. מי שמחפש אתר מפותח עם שירותים ברורים ושילוט מושלם עלול להרגיש שזה מקום יותר פראי ופחות נוח."
  },
  {
    "name": "BlueTara Cafe & Restaurant Krabi",
    "destination": "krabi",
    "category_he": "מסעדות",
    "category": "מסעדות",
    "score": 4,
    "tags": [
      "water",
      "calm"
    ],
    "hours": "09:00–18:00",
    "phone": "+66 82 563 5988",
    "link": "https://maps.google.com/?q=BlueTara+Cafe+%26+Restaurant+Krabi",
    "why": "מקום נעים מאוד לישיבה ליד מים, עם הרבה ירוק מסביב ואווירה רגועה. טוב לארוחה קלה או קפה במקום שמרגיש קצת יותר טבעי ופחות עירוני.",
    "reviews": "מבקרים אוהבים את הלוקיישן ואת האפשרות לשבת קרוב למים. האוכל מקבל בדרך כלל תגובות חיוביות, אבל החוזקה העיקרית שבולטת בביקורות היא האווירה עצמה."
  },
  {
    "name": "Thankiri Kamnan Park - Krabi",
    "destination": "krabi",
    "category_he": "מסעדות",
    "category": "מסעדות",
    "score": 4,
    "tags": [
      "water",
      "calm"
    ],
    "hours": "08:00–18:00",
    "phone": "096 310 3896",
    "link": "https://maps.google.com/?q=Thankiri+Kamnan+Park+Krabi",
    "why": "מתחם ירוק ונעים עם מים, צל וישיבה פתוחה שנותן תחושה של פיקניק מסודר יותר מאשר מסעדה רגילה. מתאים במיוחד למשפחות שרוצות מרחב ונינוחות.",
    "reviews": "הביקורות נוטות לפרגן מאוד לסביבה הירוקה ולתחושת הרוגע. חשוב להגיע עם ציפייה למקום שהוא קודם כול חוויה של ישיבה בטבע, ופחות מסעדת יעד קולינרית."
  },
  {
    "name": "The Hideaway",
    "destination": "krabi",
    "category_he": "מסעדות",
    "category": "מסעדות",
    "score": 4,
    "tags": [
      "water",
      "calm"
    ],
    "hours": "א׳-ג׳ 10:30–18:00, ד׳ סגור, ה׳ 10:30–18:00, ו׳-ש׳ 10:30–19:30",
    "phone": "+66 98 281 8647",
    "link": "https://maps.google.com/?q=The+Hideaway+Krabi",
    "why": "בית קפה רגוע בתוך ירוק, עם מים זורמים ליד ומקום שנעים פשוט לשבת בו. בחירה טובה כשרוצים לעצור במקום שקט ולא מתויר מדי.",
    "reviews": "מבקרים מדברים הרבה על האווירה, השקט והתחושה שהמקום באמת מסתתר בטבע. מי שמגיע במיוחד בשביל אוכל יוצא דופן פחות יתרשם מאשר מי שמחפש פינה נעימה."
  },
  {
    "name": "Noppharat Thara Beach",
    "destination": "krabi",
    "category_he": "חופים",
    "category": "חופים",
    "score": 4,
    "tags": [
      "water",
      "calm"
    ],
    "hours": "כל היום",
    "phone": "",
    "link": "https://www.tourismthailand.org/Attraction/noppharat-thara-beach",
    "why": "חוף רחב, נוח וקליל במיוחד, עם שורת עצים שנותנת יותר צל מרוב החופים באזור. מצוין לשקיעה, משחק בחול או עצירה קצרה בלי לוגיסטיקה מסובכת.",
    "reviews": "מבקרים אוהבים את המרחב ואת התחושה שהחוף פחות צפוף מהמרכז של Ao Nang. מצד שני, מי שמחפש חוף ״גלויה״ עם מים טורקיז דרמטיים יעדיף בדרך כלל את Railay או Tubkaek."
  },
  {
    "name": "Khlong Muang Beach",
    "destination": "krabi",
    "category_he": "חופים",
    "category": "חופים",
    "score": 5,
    "tags": [
      "water",
      "calm"
    ],
    "hours": "כל היום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Khlong+Muang+Beach+Krabi",
    "why": "אחד החופים הכי נעימים למשפחות באזור, בזכות האווירה השקטה, המים הנעימים והתחושה הפחות מסחרית. מצוין לבוקר רגוע או לשקיעה ארוכה.",
    "reviews": "ביקורות רבות מדגישות את השקט ואת זה שקל יותר להירגע כאן מאשר באו נאנג. מי שמחפש הרבה מסעדות, דוכנים ותנועה סביבו ירגיש שזה אזור איטי יותר."
  },
  {
    "name": "Tubkaek Beach",
    "destination": "krabi",
    "category_he": "חופים",
    "category": "חופים",
    "score": 5,
    "tags": [
      "water",
      "calm"
    ],
    "hours": "כל היום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Tubkaek+Beach+Krabi",
    "why": "חוף יפהפה ושקט עם נוף חזק לאיים באופק, כזה שמתאים ליום רגוע במיוחד או לשקיעה במסעדת ריזורט. אחד המקומות היותר יפים באזור למי שמחפש שלווה.",
    "reviews": "המבקרים מתלהבים מהנוף ומהאווירה השקטה והיותר יוקרתית. החיסרון העיקרי שחוזר הוא שפחות מדובר בחוף עם הרבה אקשן, אלא במקום לשקט ולישיבה נינוחה."
  },
  {
    "name": "Sofitel Krabi Phokeethra – Family Day Pass",
    "destination": "krabi",
    "category_he": "ריזורטים עם Day Pass",
    "category": "ריזורטים עם Day Pass",
    "score": 5,
    "tags": [
      "water",
      "calm"
    ],
    "hours": "לבדיקה",
    "phone": "",
    "link": "https://www.sofitelkrabiphokeethra.com/offers/family-day-pass/",
    "why": "פתרון מעולה ליום קל עם ילדים: בריכה ענקית, מתקנים, שירותי ריזורט והכול בלי להתחייב ללינה. זה בדיוק מסוג המקומות שטובים כשצריך יום מפנק ונטול מאמץ.",
    "reviews": "הביקורות והחומר הרשמי מדגישים את גודל הבריכה ואת העובדה שהמקום מתאים מאוד למשפחות. שווה לבדוק זמינות מראש, כי ההטבה אינה תמיד פתוחה בכל תקופה.",
    "day_pass_lines": [
      "Family Day Pass רשמי של המלון",
      "כולל שימוש בבריכה ובחלק מהמתקנים",
      "כדאי לבדוק מחיר ותנאים מעודכנים לפני הגעה"
    ]
  },
  {
    "name": "The Beach Club Krabi",
    "destination": "krabi",
    "category_he": "מסעדות חוף",
    "category": "מסעדות חוף",
    "score": 4,
    "tags": [
      "water",
      "calm"
    ],
    "hours": "10:00–22:00",
    "phone": "",
    "link": "https://thebeachkrabi.com/beach-club/",
    "why": "ביץ׳ קלאב מסודר על החוף עם בריכה, ישיבה נוחה ואווירה של יום חופש בלי יותר מדי תכנון. מתאים מאוד לשילוב של ים, אוכל ובריכה באותו מקום.",
    "reviews": "החוזקה העיקרית שחוזרת היא הלוקיישן והישיבה הנוחה מול הים. מי שמחפש מקום פשוט וזול ירגיש שזה יותר מקום של בילוי מסודר מאשר חוף קז׳ואלי.",
    "day_pass_lines": [
      "קיים Day Pass עם זיכוי חלקי לאוכל ושתייה",
      "כדאי לבדוק מחיר ותנאים עדכניים לפני הגעה"
    ]
  },
  {
    "name": "Dusit Thani Krabi Beach Resort",
    "destination": "krabi",
    "category_he": "מסעדות חוף",
    "category": "מסעדות חוף",
    "score": 4,
    "tags": [
      "water",
      "calm"
    ],
    "hours": "לבדיקה",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Dusit+Thani+Krabi+Beach+Resort",
    "why": "ריזורט על חוף יפה ושקט יחסית, עם אווירה מסודרת ונעימה. גם בלי Day Pass רשמי, זה מקום ששווה לשקול עבור ארוחה, קפה או ביקור קצר באזור החוף.",
    "reviews": "מבקרים נוטים להחמיא מאוד לחוף היפה ולתחושת הנוחות של המקום. זה פחות יעד אטרקציה בפני עצמו ויותר מקום נעים לשלב סביב Klong Muang."
  },
  {
    "name": "The Tubkaak Resort – Beachfront Dining",
    "destination": "krabi",
    "category_he": "מסעדות חוף",
    "category": "מסעדות חוף",
    "score": 4,
    "tags": [
      "water",
      "calm"
    ],
    "hours": "לבדיקה",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=The+Tubkaak+Resort+Krabi",
    "why": "מסעדת חוף מרשימה עם נוף יפה במיוחד לאיים שמול Tubkaek, מתאימה לערב רגוע או ארוחה מיוחדת יותר. זו בחירה על אווירה ונוף לא פחות מאשר על אוכל.",
    "reviews": "הביקורות מדברות הרבה על הלוקיישן והשקיעה, ופחות על מקום לילדים במובן האקטיבי. זה מקום שעובד טוב כשבאים לשבת יפה ובנחת."
  },
  {
    "name": "Following Giants – Krabi",
    "destination": "krabi",
    "category_he": "חיות",
    "category": "חיות",
    "score": 5,
    "tags": [
      "calm"
    ],
    "hours": "לבדיקה",
    "phone": "",
    "link": "https://www.followinggiants.net/",
    "why": "אופציה חזקה מאוד למי שמחפש חוויית פילים אתית יותר, עם דגש על תצפית והתבוננות ולא על אינטראקציה כפויה. מתאים למשפחות שרוצות להרגיש נוח יותר עם אופי הפעילות.",
    "reviews": "החומר הרשמי מדגיש מודל no touch ותצפית בהתנהגות טבעית, וזה גם מה שמושך הרבה מבקרים. צריך לקחת בחשבון שמי שמחפש האכלה, רחצה או הרבה מגע עלול להרגיש שהחוויה כאן עדינה יותר."
  },
  {
    "name": "Susan Hoi Shell Cemetery",
    "destination": "krabi",
    "category_he": "טבע",
    "category": "טבע",
    "score": 4,
    "tags": [
      "calm"
    ],
    "hours": "08:00–17:00",
    "phone": "",
    "link": "https://www.tourismthailand.org/Attraction/75-million-year-old-shell-cemetery",
    "why": "עצירה קצרה ומעניינת בזכות התופעה הגיאולוגית הייחודית והטיילת שליד הים. זה לא יום טיול בפני עצמו, אלא תוספת נחמדה בדרך או לשילוב עם אזור Ao Nam Mao.",
    "reviews": "מבקרים בדרך כלל מעריכים את הייחוד של המקום ואת זה שלא צריך הרבה זמן כדי לראות אותו. מי שמגיע עם ציפייה לאטרקציה גדולה עלול להרגיש שזה קצר ופשוט יחסית."
  },
  {
    "name": "Hong Islands Tour",
    "destination": "krabi",
    "category_he": "שייטים / איים",
    "category": "שייטים / איים",
    "score": 5,
    "tags": [
      "water",
      "calm"
    ],
    "hours": "לרוב יציאה בבוקר, תלוי מפעיל",
    "phone": "",
    "link": "https://www.tourismthailand.org/Attraction/hat-noppharat-thara-mu-ko-phi-phi-national-park",
    "why": "מבין כל השייטים באזור זה בדרך כלל השילוב הכי מוצלח למשפחות: לגונה יפה, חופים קטנים, מים יפים ושייט רגוע יחסית. מתאים במיוחד למי שרוצה יום איים בלי להרגיש במירוץ בין יותר מדי תחנות.",
    "reviews": "הביקורות החיוביות מדגישות את Hong Lagoon, את צבע המים ואת העובדה שזה מסלול נעים יותר ופחות עמוס מהשייטים הקלאסיים. מי שבוחר סירה פרטית או יציאה מוקדמת בדרך כלל נהנה יותר מהשקט.",
    "price": "קבוצתי לרוב כ 1,100 עד 1,500 באט לאדם, פרטי בלונגטייל לרוב סביב 4,400 עד 5,500 באט לסירה, לא כולל דמי פארק",
    "how_to_get": "רוב הסיורים יוצאים מ Noppharat Thara Pier, וחלק מהמפעילים כוללים איסוף מאזורים כמו Ao Nang, Klong Muang ו Tubkaek. אם לוקחים סירה פרטית, הכי נוח לסגור דרך ספק מקומי אמין יום קודם.",
    "includes_lines": [
      "שייט בלונגטייל או ספידבוט לפי החבילה",
      "ציוד שנורקלינג",
      "מים ופירות, ולעיתים גם ארוחת צהריים",
      "איסוף מהמלון בחלק מהמסלולים"
    ],
    "tips_lines": [
      "עדיף לבחור יציאה מוקדמת כדי ליהנות מהלגונה לפני העומס",
      "עם ילד קטן לרוב עדיף מסלול פרטי או קבוצה קטנה",
      "שווה לבדוק מראש אם דמי הפארק כלולים או משולמים במזומן בנפרד",
      "כדאי להביא בגדים להחלפה, כובע ונעלי מים פשוטות"
    ],
    "icon": "🚤"
  },
  {
    "name": "4 Islands Tour",
    "destination": "krabi",
    "category_he": "שייטים / איים",
    "category": "שייטים / איים",
    "score": 4,
    "tags": [
      "water"
    ],
    "hours": "לרוב 08:00–16:00, תלוי מפעיל",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Ao%20Nang%20Beach%20Krabi",
    "why": "השייט הקלאסי של קראבי: מסלול מגוון בין Poda, Chicken Island, Tup ו Phra Nang. הוא נותן הרבה תמונות יפות והרבה תחנות ביום אחד, ולכן טוב למי שרוצה טעימה מהאיים המפורסמים.",
    "reviews": "מבקרים אוהבים את המגוון ואת תחושת הוואו של רצועת החול בין האיים כשהגאות מאפשרת. מצד שני, זה נחשב לשייט יותר עמוס ופחות רגוע, ולכן עם ילד קטן חלק מהמשפחות מעדיפות מסלול פרטי או את Hong Islands.",
    "price": "קבוצתי לרוב כ 700 עד 1,300 באט לאדם, פרטי בלונגטייל לרוב סביב 3,700 עד 7,200 באט לסירה, לעיתים דמי פארק בנפרד",
    "how_to_get": "רוב היציאות הן מ Ao Nang Beach או Noppharat Thara, בדרך כלל עם איסוף מלון באזורים המרכזיים. אם חשוב לכם קצב רגוע יותר, עדיף לסגור שייט פרטי ולא מסלול קבוצתי.",
    "includes_lines": [
      "שייט בין ארבע תחנות עיקריות סביב Ao Nang",
      "ציוד שנורקלינג",
      "מים ולעיתים ארוחת צהריים",
      "איסוף מהמלון בחלק מהמסלולים"
    ],
    "tips_lines": [
      "זה המסלול היותר עמוס ופופולרי, אז יציאה מוקדמת משפרת מאוד את החוויה",
      "כדאי לבדוק מצב גאות אם חשוב לכם לראות את הסנדבר בין האיים",
      "עם ילד קטן עדיף לקחת הרבה מים, חטיפים וצלון קל אם יש",
      "לפני סגירה שווה לשאול כמה זמן בפועל עוצרים בכל אי"
    ],
    "icon": "⛵"
  },
  {
    "name": "Le Petit Prince Kids Club",
    "destination": "krabi",
    "category_he": "משחקיות וסדנאות",
    "category": "משחקיות וסדנאות",
    "score": 5,
    "tags": [
      "ac",
      "calm"
    ],
    "hours": "כל יום 08:00–18:00",
    "phone": "66 75 627 800",
    "link": "https://www.sofitelkrabiphokeethra.com/leisureandlifestyle/kids-club/",
    "why": "קידס קלאב מושקע במיוחד בתוך Sofitel, עם חללים מעוצבים, פינות קריאה, יצירה, משחק דיגיטלי ופעילויות מתחלפות. תוספת חזקה מאוד לאתר כי זו אופציה איכותית ליום חם או להפסקה מריזורט.",
    "reviews": "החומר הרשמי מדגיש מרחב מעוצב ורב גילאי, עם סדנאות ופעילויות לאורך השבוע. היתרון הגדול הוא האיכות והסדר, אבל חשוב לבדוק מראש אם נדרש Day Pass או הזמנה נפרדת לשימוש חיצוני.",
    "icon": "🧸"
  },
  {
    "name": "Holiday Ao Nang Beach Resort – Kids Club",
    "destination": "krabi",
    "category_he": "משחקיות וסדנאות",
    "category": "משחקיות וסדנאות",
    "score": 4,
    "tags": [
      "ac",
      "water",
      "calm"
    ],
    "hours": "מועדון ילדים לרוב 08:00–18:00, בריכות ילדים עד 20:00",
    "phone": "66 75 810 888",
    "link": "https://holidayresortkrabi.com/facilities/kids-club",
    "why": "מתחם משפחתי חזק עם קידס קלאב, בריכת ילדים ומגלשות מים, כך שהוא נותן יותר ממקום משחק סגור בלבד. טוב במיוחד אם רוצים לשלב מים ופעילות באותו מקום.",
    "reviews": "האתר הרשמי מדגיש אזור ילדים פעיל ומתחם מים למשפחות. זו אופציה טובה כשמחפשים בילוי ריזורטי לילדים, אבל שווה לוודא מראש אילו אזורים פתוחים גם לאורחי חוץ.",
    "icon": "🛝"
  },
  {
    "name": "Cocokids Summer Cafe Krabi",
    "destination": "krabi",
    "category_he": "משחקיות וסדנאות",
    "category": "משחקיות וסדנאות",
    "score": 4,
    "tags": [
      "ac",
      "calm"
    ],
    "hours": "לבדיקה",
    "phone": "66 86 633 5797",
    "link": "https://www.facebook.com/p/Cocokids-Summer-Cafe-61572437880683/",
    "why": "שילוב של בית קפה ומתחם משחק שנראה מתאים במיוחד לילדים קטנים, כך שההורים יכולים לשבת בזמן שהילדים משחקים. תוספת טובה מאוד לקטגוריית ימי חום וגשם.",
    "reviews": "הנוכחות ברשתות והצילומים מראים מתחם צבעוני ומשפחתי עם הרבה משחק. לפני ביקור מומלץ לבדוק שעות פתיחה עדכניות, כי זה מקום חדש יחסית והמידע ברשת עדיין לא תמיד אחיד.",
    "icon": "🎨"
  },
  {
    "name": "Schnitzel Challah – The Kosher Home in Krabi",
    "destination": "krabi",
    "category_he": "מסעדות",
    "category": "מסעדות",
    "score": 4,
    "tags": [
      "calm"
    ],
    "hours": "לפי האתר ניתן להזמין משלוח, איסוף עצמי ויש גם הזמנת שולחן",
    "phone": "",
    "link": "https://www.schnitzelchallakosher.com/en/",
    "why": "אופציה נוחה מאוד למי שמחפש אוכל ישראלי מוכר בקראבי, עם דגש על אוכל ביתי, שניצל בחלה ומשלוחים. טובה במיוחד לימים עייפים או כשפשוט רוצים טעמים מוכרים.",
    "reviews": "האתר הרשמי מדגיש אוכל ביתי, איסוף עצמי ומשלוח, וזה היתרון הגדול כאן. זו פחות מסעדת אווירה ויותר פתרון פרקטי ונוח לאוכל ישראלי וכשר.",
    "cuisine": "ישראלי / כשר",
    "icon": "🥙"
  },
  {
    "name": "MediJungle – Waterfall Restaurant, Bakery & Kosher",
    "destination": "krabi",
    "category_he": "מסעדות",
    "category": "מסעדות",
    "score": 5,
    "tags": [
      "water",
      "calm"
    ],
    "hours": "לבדיקה",
    "phone": "66 95 195 9842",
    "link": "https://www.instagram.com/medijungle.krabi/?hl=en",
    "why": "מקום עם קונספט חזק יותר מסתם מסעדה ישראלית: אוכל ישראלי וכשר, מאפייה, ואווירה ירוקה ליד מים. מתאים גם למי שמחפש חוויה נעימה לשבת בה, לא רק להזמין אוכל.",
    "reviews": "הנוכחות הרשמית והחומרים ברשת מדגישים חומוס, מאפים ואווירת ג׳ונגל עם מים. זה מקום שנראה מושך במיוחד למטיילים ישראלים שרוצים גם טעמים מוכרים וגם לוקיישן מיוחד יותר.",
    "cuisine": "ישראלי / כשר / צמחוני וידידותי לטבעונים",
    "icon": "🍽️"
  },
  {
    "name": "בסיס הוי אן",
    "destination": "hoi_an",
    "category_he": "בסיס",
    "category": "בסיס",
    "score": null,
    "tags": [],
    "hours": "",
    "phone": "",
    "link": "https://www.google.com/maps?q=Hoi%20An%20Vietnam",
    "why": "",
    "reviews": "",
    "icon": "🏠"
  },
  {
    "name": "Hoi An Ancient Town",
    "destination": "hoi_an",
    "category_he": "תרבות ועיר",
    "category": "תרבות ועיר",
    "score": 5,
    "tags": [
      "calm"
    ],
    "hours": "מומלץ מוקדם בבוקר או בערב",
    "phone": "",
    "link": "https://www.google.com/maps?q=Hoi%20An%20Ancient%20Town",
    "why": "הלב של הוי אן. לא רק סימטאות יפות ופנסים, אלא אזור שקל מאוד לשלב בו שיטוט קצר, עצירת אוכל וקניות קטנות בלי לתכנן יום שלם.",
    "reviews": "העיר העתיקה נחשבת לאטרקציה המרכזית של הוי אן ומככבת כמעט בכל מדריך רשמי. מי שמגיע עם ילדים נהנה ממנה יותר כשהולכים בשעות הנעימות ולא בשיא החום."
  },
  {
    "name": "An Bang Beach",
    "destination": "hoi_an",
    "category_he": "חופים",
    "category": "חופים",
    "score": 5,
    "tags": [
      "water",
      "calm"
    ],
    "hours": "כל היום, עדיף בוקר או אחה״צ",
    "phone": "",
    "link": "https://www.google.com/maps?q=An%20Bang%20Beach%20Hoi%20An",
    "why": "החוף הכי שימושי לשהות ארוכה: קל להגיע, יש לאורכו מסעדות ובתי קפה, ואפשר לקפוץ גם רק לשעה בלי להרגיש שמבזבזים יום שלם.",
    "reviews": "אתר התיירות הרשמי של וייטנאם מציג את An Bang כאופציה משפחתית קלאסית להוי אן, עם חוף נעים ואוכל על החול. זה בדיוק מסוג המקומות שחוזרים אליהם יותר מפעם אחת במהלך חודש."
  },
  {
    "name": "Cua Dai Beach",
    "destination": "hoi_an",
    "category_he": "חופים",
    "category": "חופים",
    "score": 4,
    "tags": [
      "water",
      "calm"
    ],
    "hours": "בוקר או לקראת שקיעה",
    "phone": "",
    "link": "https://www.google.com/maps?q=Cua%20Dai%20Beach%20Hoi%20An",
    "why": "עוד חוף טוב לשילוב במהלך השהות, במיוחד כשרוצים גיוון מ-An Bang או מחפשים עצירה קצרה עם פחות אווירת חוף-כפר ויותר קו חוף פתוח.",
    "reviews": "הוא פחות 'הבחירה הראשונה' של רוב המשפחות לעומת An Bang, אבל עדיין עובד טוב ליום חוף קליל או לשקיעה. שווה להכניס כאופציה משלימה, לא ככוכב הראשי."
  },
  {
    "name": "Tra Que Vegetable Village",
    "destination": "hoi_an",
    "category_he": "טבע וכפרים",
    "category": "טבע וכפרים",
    "score": 5,
    "tags": [
      "calm"
    ],
    "hours": "עדיף בוקר",
    "phone": "",
    "link": "https://www.google.com/maps?q=Tra%20Que%20Vegetable%20Village%20Hoi%20An",
    "why": "אחת האטרקציות הכי טובות למשפחה בהוי אן כי היא מרגישה כפרית, ירוקה ורגועה בלי להיות מסע. אפשר לשלב הליכה קצרה, חוויה חקלאית ואוכל טוב באזור.",
    "reviews": "אתרי התיירות הרשמיים של הוי אן ושל וייטנאם מציינים שוב ושוב את Tra Que כאחד מכפרי החוויה הבולטים באזור. היתרון הגדול למשפחות הוא שזה מקום מעניין אבל לא עמוס מדי בגירויים."
  },
  {
    "name": "Cam Thanh Coconut Village",
    "destination": "hoi_an",
    "category_he": "טבע וכפרים",
    "category": "טבע וכפרים",
    "score": 4,
    "tags": [
      "water"
    ],
    "hours": "בוקר או אחר הצהריים",
    "phone": "",
    "link": "https://www.google.com/maps?q=Cam%20Thanh%20Coconut%20Village%20Hoi%20An",
    "why": "חוויה קלאסית של הוי אן עם סירות הסל העגולות בתוך יער הקוקוסים. זה צבעוני וכיפי, אבל עדיף לבחור מפעיל רגוע יותר ופחות 'מופע רועש'.",
    "reviews": "מקורות התיירות הרשמיים מציגים את Cam Thanh כאחד האזורים החזקים מחוץ לעיר העתיקה. למשפחות עם ילדים קטנים זה עובד הכי טוב כששומרים על ציפיות לפעילות קצרה ולא לחצי יום."
  },
  {
    "name": "Thanh Ha Pottery Village",
    "destination": "hoi_an",
    "category_he": "טבע וכפרים",
    "category": "טבע וכפרים",
    "score": 4,
    "tags": [
      "calm"
    ],
    "hours": "בוקר או אחה״צ",
    "phone": "",
    "link": "https://www.google.com/maps?q=Thanh%20Ha%20Pottery%20Village%20Hoi%20An",
    "why": "כפר מסורתי שנוח לשלב עם סדנת קדרות, ונותן תחושת יציאה קטנה מהעיר בלי להיכנס לנסיעה ארוכה או לפעילות מאמצת.",
    "reviews": "הכפר מופיע שוב ושוב בהמלצות הרשמיות של הוי אן כמרכז למלאכת הקרמיקה. היתרון שלו באתר שלך הוא לא רק הביקור עצמו אלא האפשרות לבנות סביבו יום יצירה."
  },
  {
    "name": "My Son Sanctuary",
    "destination": "hoi_an",
    "category_he": "תרבות ועיר",
    "category": "תרבות ועיר",
    "score": 4,
    "tags": [
      "challenging"
    ],
    "hours": "מוקדם מאוד בבוקר",
    "phone": "",
    "link": "https://www.google.com/maps?q=My%20Son%20Sanctuary",
    "why": "אתר מורשת עולמית מרשים מאוד למי שרוצה יום תרבות והיסטוריה, אבל הוא פחות 'קליל' ולכן מתאים יותר ליום עם הרבה אנרגיה ופחות לימים חמים או עייפים.",
    "reviews": "UNESCO מתאר את Mỹ Sơn כמרכז דתי ופוליטי חשוב של ממלכת צ'אמפה. זה מקום חזק מאוד תוכניתית, אבל עם ילדים קטנים הוא פחות נוח מאטרקציות הקרובות להוי אן עצמה."
  },
  {
    "name": "Precious Heritage Art Gallery Museum",
    "destination": "hoi_an",
    "category_he": "תרבות ועיר",
    "category": "תרבות ועיר",
    "score": 4,
    "tags": [
      "ac",
      "calm"
    ],
    "hours": "בדרך כלל בשעות היום",
    "phone": "",
    "link": "https://www.google.com/maps?q=Precious%20Heritage%20Art%20Gallery%20Museum%20Hoi%20An",
    "why": "מוזיאון/גלריה שיכול לעבוד טוב כהפסקה ממוזגת ורגועה, במיוחד אם רוצים פעילות תרבותית קלילה יחסית בתוך העיר ולא משהו תובעני.",
    "reviews": "זה לא 'חובה' לכל משפחה, אבל הוא מתאים מאוד לימים שבהם רוצים תוכן רגוע ומעט שקט. מתאים בעיקר לילדים שיודעים כבר להסתכל ולשאול, ופחות לקטנטנים סופר־אנרגטיים."
  },
  {
    "name": "Hoi An Memories Show",
    "destination": "hoi_an",
    "category_he": "ערב והופעות",
    "category": "ערב והופעות",
    "score": 4,
    "tags": [
      "calm"
    ],
    "hours": "ערב",
    "phone": "",
    "link": "https://www.google.com/maps?q=Hoi%20An%20Memories%20Show",
    "why": "אם רוצים ערב אחד מיוחד ושונה מהרגיל, זו אופציה טובה מאוד. לא משהו שעושים שוב ושוב, אלא חוויה אחת גדולה בתוך שהות ארוכה.",
    "reviews": "אתר התיירות הרשמי של וייטנאם ממליץ על מופעים בהוי אן כחלק מהחוויה התרבותית בעיר. לילדים קטנים זה תלוי אופי, ולכן כדאי להכניס אבל לא להציג כבחירת ברירת מחדל."
  },
  {
    "name": "Roving Chillhouse",
    "destination": "hoi_an",
    "category_he": "בתי קפה ונקודות עצירה",
    "category": "בתי קפה ונקודות עצירה",
    "score": 5,
    "tags": [
      "calm"
    ],
    "hours": "בוקר עד שקיעה",
    "phone": "+84 968 470 047",
    "link": "https://www.google.com/maps?q=Roving%20Chillhouse%20Hoi%20An",
    "why": "אחד המקומות הכי טובים לשגרה של חודש: לא 'אטרקציה' אלא עצירה יפה, נעימה ומאווררת באמצע שדות אורז. מושלם לימים שרוצים רק לצאת קצת מהבית.",
    "reviews": "הנוכחות הרשמית שלו מדגישה את הלוקיישן בין השדות ואת אווירת ה-chill. זה מסוג המקומות שלא חייבים לשמור לסוף שבוע – אפשר לחזור אליהם שוב ושוב."
  },
  {
    "name": "Hoian Vela Candle & Spa",
    "destination": "hoi_an",
    "category_he": "משחקיות וסדנאות",
    "category": "משחקיות וסדנאות",
    "score": 5,
    "tags": [
      "ac",
      "calm"
    ],
    "hours": "פתוח לפי המקום; כדאי לתאם סדנה מראש",
    "phone": "",
    "link": "https://maps.app.goo.gl/rXGnuN4wicZ9Basf8",
    "why": "סדנת נרות נעימה, רגועה ומאוד מתאימה לשעות החמות או ליום גשום. הילדים בוחרים ריחות, צבעים וקישוטים, ויש תחושה של יצירה אמיתית שאפשר לקחת הביתה.",
    "reviews": "מהביקורות והתמונות עולה שזה מקום מסודר, אסתטי ונעים, עם חוויה שמתאימה גם לילדים קטנים. לא אטרקציה רועשת או עמוסה, אלא פעילות יצירה רגועה וטובה להפוגה באמצע יום.",
    "icon": "🕯️"
  },
  {
    "name": "Chau Pottery",
    "destination": "hoi_an",
    "category_he": "משחקיות וסדנאות",
    "category": "משחקיות וסדנאות",
    "score": 5,
    "tags": [
      "calm"
    ],
    "hours": "נפתח לרוב בבוקר; מומלץ לתאם מראש",
    "phone": "",
    "link": "https://maps.app.goo.gl/XVC7nbrWJyy892rAA",
    "why": "סדנת קדרות איכותית ומאוד מוחשית לילדים: נוגעים בחומר, יוצרים כלי קטן ומקבלים חוויה שונה ממסעדה או משחקייה. מתאימה במיוחד לילדים שאוהבים עבודת ידיים.",
    "reviews": "הביקורות חזקות מאוד, והחוויה נראית אישית ולא תעשייתית. היתרון הגדול הוא שהפעילות קצרה יחסית אבל מרגישה משמעותית; החיסרון הוא שכדאי לתאם ולא להגיע ספונטנית בשעה לא נוחה.",
    "icon": "🏺"
  },
  {
    "name": "Spoon it Up – Peanut Workshop",
    "destination": "hoi_an",
    "category_he": "משחקיות וסדנאות",
    "category": "משחקיות וסדנאות",
    "score": 5,
    "tags": [
      "calm"
    ],
    "hours": "לבדיקה",
    "phone": "",
    "link": "https://www.google.com/maps?q=Spoon%20it%20Up%20Hoi%20An",
    "why": "מהסוגים הכי מיוחדים של פעילויות לאתר שלך: לא עוד יצירה גנרית אלא חוויה מקומית, טעימה וקצרה יחסית שמוסיפה משהו שונה לשהות בהוי אן.",
    "reviews": "זה בדיוק המקום שנכנס לרשימת 'דברים שלא כולם מגיעים אליהם' אבל מרגישים אחר כך שהוא היה שוס. מתאים מאוד למשפחות שמחפשות חוויה מקומית קלילה."
  },
  {
    "name": "Bao Huynh Watercolor Atelier",
    "destination": "hoi_an",
    "category_he": "משחקיות וסדנאות",
    "category": "משחקיות וסדנאות",
    "score": 4,
    "tags": [
      "ac",
      "calm"
    ],
    "hours": "לבדיקה",
    "phone": "",
    "link": "https://www.google.com/maps?q=Bao%20Huynh%20Watercolor%20Atelier%20Hoi%20An",
    "why": "שיעור צבעי מים הוא אופציה נהדרת ליום רגוע, במיוחד לילדים שאוהבים לשבת ולהתעמק. הוא פחות 'לפרוק אנרגיה' ויותר חוויה יצירתית ושקטה.",
    "reviews": "מתאים יותר לילדים שמסוגלים לשבת ולהתרכז תקופה מסוימת. לא הייתי בונה עליו כפעילות הראשונה עם קטנטן, אבל בהחלט שווה להחזיק באתר כאופציית יצירה איכותית."
  },
  {
    "name": "PHAP Studio – Painting Workshop",
    "destination": "hoi_an",
    "category_he": "משחקיות וסדנאות",
    "category": "משחקיות וסדנאות",
    "score": 5,
    "tags": [
      "ac",
      "calm"
    ],
    "hours": "לבדיקה",
    "phone": "",
    "link": "https://www.google.com/maps?q=PHAP%20Studio%20Hoi%20An",
    "why": "אחד המקומות הכי טובים ליצירה רחבה יותר מצבעי מים בלבד. מתאים גם למי שמחפש חוויה אמנותית קלילה וגם למי שרוצה שעה־שעתיים נעימות בפנים.",
    "reviews": "העמודים הפעילים של הסטודיו והפלטפורמות שמוכרות את הסדנה מדגישים התאמה גם למתחילים. זו בחירה חזקה במיוחד כי היא באמת נראית נגישה לכל הרמות."
  },
  {
    "name": "Alluvia Chocolate House Hội An",
    "destination": "hoi_an",
    "category_he": "משחקיות וסדנאות",
    "category": "משחקיות וסדנאות",
    "score": 5,
    "tags": [
      "ac",
      "calm"
    ],
    "hours": "09:00–21:30 (לבדיקה)",
    "phone": "",
    "link": "https://www.google.com/maps?q=Alluvia%20Chocolate%20House%20Hoi%20An",
    "why": "זו אחת הסדנאות הכי 'בטוחות' להצלחה עם ילדים: שוקולד, טעימות, הכנה בידיים ואווירה כיפית. קלה מאוד לשילוב ביום בעיר העתיקה.",
    "reviews": "פלטפורמות ההזמנה וההמלצות מתארות כאן סדנת הכנת שוקולד שבה מכינים ולוקחים הביתה תוצרים. זה בדיוק מסוג הדברים שילדים זוכרים גם אחרי הרבה זמן."
  },
  {
    "name": "Taboo Bamboo Workshop",
    "destination": "hoi_an",
    "category_he": "משחקיות וסדנאות",
    "category": "משחקיות וסדנאות",
    "score": 4,
    "tags": [
      "challenging"
    ],
    "hours": "לבדיקה",
    "phone": "",
    "link": "https://www.google.com/maps?q=Taboo%20Bamboo%20Workshop%20Hoi%20An",
    "why": "סדנה מיוחדת ומקומית מאוד, אבל היא מתאימה יותר לילדים גדולים או להורים שמחפשים פעילות יצירתית עם קצת יותר מורכבות.",
    "reviews": "שווה להוסיף כי זה תוכן איכותי ומבדל, אבל לא להציג כבחירת ברירת מחדל למשפחות עם ילדים קטנים מאוד."
  },
  {
    "name": "Driftwood Village – Wood Sculpture Workshop",
    "destination": "hoi_an",
    "category_he": "משחקיות וסדנאות",
    "category": "משחקיות וסדנאות",
    "score": 4,
    "tags": [
      "challenging"
    ],
    "hours": "לבדיקה",
    "phone": "",
    "link": "https://www.google.com/maps?q=Driftwood%20Village%20Hoi%20An",
    "why": "מקום עם אופי אומנותי חזק, טוב להורים ולילדים גדולים יותר שאוהבים ליצור. פחות אידיאלי לפעילות מהירה עם ילד קטן וחסר סבלנות.",
    "reviews": "היתרון כאן הוא הייחוד והאווירה, לא בהכרח הנגישות לכל גיל. לכן הוא שייך לרשימה, אבל נמוך יותר בסדר העדיפויות."
  },
  {
    "name": "Long Gia Kitchen – Tofu Workshop",
    "destination": "hoi_an",
    "category_he": "משחקיות וסדנאות",
    "category": "משחקיות וסדנאות",
    "score": 4,
    "tags": [
      "challenging"
    ],
    "hours": "לבדיקה",
    "phone": "",
    "link": "https://www.google.com/maps?q=Long%20Gia%20Kitchen%20Hoi%20An",
    "why": "סדנה מעניינת ושונה מאוד, אבל מתאימה יותר לילדים גדולים וסבלניים יותר. לא הייתי בונה עליה עם מתחת לגיל 7.",
    "reviews": "זו בחירה מעולה למשפחות עם ילדים גדולים יותר שמחפשים חוויה קולינרית מקומית. עם קטנים היא עלולה להיות ארוכה מדי."
  },
  {
    "name": "Lò Rèn Cẩm Đồng – Knife Workshop",
    "destination": "hoi_an",
    "category_he": "משחקיות וסדנאות",
    "category": "משחקיות וסדנאות",
    "score": 3,
    "tags": [
      "challenging"
    ],
    "hours": "לבדיקה",
    "phone": "",
    "link": "https://www.google.com/maps?q=Lo%20Ren%20Cam%20Dong%20Hoi%20An",
    "why": "סדנה מעניינת תרבותית, אבל לא מתאימה לילדים קטנים. טובה יותר כפריט נישה למי שממש מחפש מלאכה מסורתית מסוג אחר.",
    "reviews": "שווה לשמור באתר כי היא ייחודית, אבל חשוב מאוד להבהיר שהיא לא לילדים קטנים ולא לפעילות משפחתית קלילה."
  },
  {
    "name": "Vietnam Kids Play Cafe",
    "destination": "hoi_an",
    "category_he": "משחקיות וסדנאות",
    "category": "משחקיות וסדנאות",
    "score": 4,
    "tags": [
      "ac"
    ],
    "hours": "פתוח בבקרים, לרוב עד 11:30",
    "phone": "",
    "link": "https://maps.app.goo.gl/AHuM83dzeEqaCwac9",
    "why": "בית קפה מקומי עם משחקייה קטנה ופשוטה לילדים. זה לא מקום יוקרתי או גדול, אבל הוא שימושי מאוד לבוקר קצר שבו רוצים שהילדים ישחקו וההורים ישתו קפה.",
    "reviews": "הערך הוא בעיקר פרקטי: מקום זול, פשוט ופתוח בשעות הבוקר. מתאים יותר להפוגה קצרה מאשר כבילוי מרכזי של היום.",
    "icon": "🧸"
  },
  {
    "name": "Mini Golf Hoi An",
    "destination": "hoi_an",
    "category_he": "משחקיות וסדנאות",
    "category": "משחקיות וסדנאות",
    "score": 5,
    "tags": [
      "calm"
    ],
    "hours": "נפתח לרוב בבוקר; טוב גם אחה״צ",
    "phone": "",
    "link": "https://maps.google.com/?q=Mini+Golf+Hoi+An",
    "why": "פעילות קלילה, צבעונית ולא ארוכה מדי, שמתאימה בדיוק לשלב ביום שבו רוצים משהו כיפי בלי עוד סדנה ובלי הרבה נסיעות.",
    "reviews": "הדירוג גבוה מאוד והמקום נראה מושקע ומתאים לילדים. חשוב לקחת בחשבון שחלק מהמסלול בחוץ, ולכן עדיף להגיע בבוקר או אחה״צ ולא בשמש חזקה.",
    "icon": "⛳"
  },
  {
    "name": "grilled.il הבית הישראלי",
    "destination": "hoi_an",
    "category_he": "מסעדות",
    "category": "מסעדות",
    "score": 4,
    "tags": [
      "calm"
    ],
    "hours": "לבדיקה",
    "phone": "+84 588 264 590",
    "link": "https://www.google.com/maps?q=grilled.il%20hoi%20an",
    "why": "לא כל יום צריך לחפש את הארוחה הכי מעניינת. לפעמים מסעדה ישראלית טובה היא פשוט פתרון חכם ונוח למשפחה – במיוחד בשהות של חודש.",
    "reviews": "לפי הנוכחות הפעילה והמידע העסקי, זה מקום מבוסס ולא רק פופ־אפ לתיירים. שווה מאוד לשמור באתר כאופציית ביטחון נוחה."
  },
  {
    "name": "Papa Sushi Hội An",
    "destination": "hoi_an",
    "category_he": "מסעדות",
    "category": "מסעדות",
    "score": 4,
    "tags": [
      "calm"
    ],
    "hours": "לבדיקה",
    "phone": "+84 90 542 85 85",
    "link": "https://www.google.com/maps?q=Papa%20Sushi%20Hoi%20An",
    "why": "סושי הוא לפעמים פתרון מצוין לילדים ולהורים שרוצים משהו קל, מסודר ולא כבד. טוב במיוחד כארוחה באמצע יום או ערב פשוט.",
    "reviews": "העמוד הרשמי והביקורות הלא־רשמיות מתארים מקום קטן ומשפחתי עם אוכל אהוב ושירות חם. לא 'חובה קולינרית', אבל בחירה מאוד שימושית."
  },
  {
    "name": "IRINI. HOI AN | Greek Restaurant & Cafe",
    "destination": "hoi_an",
    "category_he": "מסעדות",
    "category": "מסעדות",
    "score": 4,
    "tags": [
      "calm"
    ],
    "hours": "לבדיקה",
    "phone": "",
    "link": "https://www.google.com/maps?q=IRINI%20Hoi%20An%20Greek%20Restaurant%20Cafe",
    "why": "גיוון טוב למטבח המקומי כשנמצאים חודש. אוכל ים־תיכוני/יווני הרבה פעמים עובד טוב גם עם ילדים וגם עם הורים שכבר מחפשים משהו אחר.",
    "reviews": "זה מקום שלא חייב להיות במרכז כל מסלול, אבל כן טוב מאוד כאופציית ארוחה יציבה ונעימה במהלך השהות."
  },
  {
    "name": "Greek Souvlaki An Bang Beach",
    "destination": "hoi_an",
    "category_he": "מסעדות",
    "category": "מסעדות",
    "score": 4,
    "tags": [
      "water",
      "calm"
    ],
    "hours": "לבדיקה",
    "phone": "",
    "link": "https://www.google.com/maps?q=Greek%20Souvlaki%20An%20Bang%20Beach",
    "why": "בחירה טובה במיוחד ליום חוף, כי היא יושבת נכון בתוך האזור של An Bang ונותנת אופציית אוכל מוכרת, פשוטה ונוחה.",
    "reviews": "לא יעד בפני עצמו, אלא מקום טוב מאוד לשילוב. שווה להכניס כי הוא פותר יפה את שאלת 'איפה אוכלים ליד החוף'."
  },
  {
    "name": "בסיס דה נאנג",
    "destination": "da_nang",
    "category_he": "בסיס",
    "category": "בסיס",
    "score": null,
    "tags": [],
    "hours": "",
    "phone": "",
    "link": "https://maps.google.com/?q=Chi+House+Danang",
    "why": "",
    "reviews": "",
    "icon": "🏠"
  },
  {
    "name": "My Khe Beach",
    "destination": "da_nang",
    "category_he": "חופים",
    "category": "חופים",
    "score": null,
    "tags": [
      "water",
      "calm"
    ],
    "hours": "כל היום, עדיף בוקר או אחה״צ",
    "phone": "",
    "link": "https://maps.google.com/?q=My+Khe+Beach+Da+Nang",
    "why": "החוף הכי נוח לשהות הקצרה שלכם. הוא רחב, קל להגיע אליו מ‑Chi House, ויש סביבו הרבה מקומות לשבת, לאכול או פשוט לחזור למלון אם צריך.",
    "reviews": "מתאים מאוד למשפחות בגלל הגישה הקלה והמרחב. בימים יפים הים רגוע יחסית, אבל בשעות החמות פחות נעים להתעכב הרבה זמן על החול.",
    "icon": "🏖️"
  },
  {
    "name": "East Sea Park",
    "destination": "da_nang",
    "category_he": "פארקים וטיילות",
    "category": "פארקים וטיילות",
    "score": null,
    "tags": [
      "calm"
    ],
    "hours": "כל היום",
    "phone": "",
    "link": "https://maps.google.com/?q=East+Sea+Park+Da+Nang",
    "why": "נקודת עצירה טובה ליד הים להליכה קצרה, יונים, מרחב פתוח ושילוב עם חוף או ארוחה.",
    "reviews": "לא אטרקציה של יום שלם, אבל מאוד שימושי לשהות של כמה ימים כי אפשר לשלב אותו בקלות בלי מאמץ ובלי התחייבות.",
    "icon": "🌳"
  },
  {
    "name": "Dragon Bridge",
    "destination": "da_nang",
    "category_he": "עיר וערב",
    "category": "עיר וערב",
    "score": null,
    "tags": [
      "calm"
    ],
    "hours": "21:00 בסופי שבוע וחגים",
    "phone": "",
    "link": "https://maps.google.com/?q=Dragon+Bridge+Da+Nang",
    "why": "אחת האטרקציות שהכי שוות לזמן הקצר בעיר: קצרה, מרשימה, ולא דורשת כמעט מאמץ.",
    "reviews": "מופע האש והמים ב‑21:00 בסופי שבוע ובחגים הוא אחלה ׳וואו׳ לילדים. כן יכול להיות עמוס סביב הגשר, לכן עדיף להגיע קצת מוקדם ולבחור נקודת צפייה נוחה.",
    "icon": "🐉"
  },
  {
    "name": "Son Tra Peninsula & Linh Ung Pagoda",
    "destination": "da_nang",
    "category_he": "טבע ותצפיות",
    "category": "טבע ותצפיות",
    "score": null,
    "tags": [
      "calm"
    ],
    "hours": "מומלץ בוקר או אחה״צ",
    "phone": "",
    "link": "https://maps.google.com/?q=Linh+Ung+Pagoda+Son+Tra+Da+Nang",
    "why": "טיול נהיגה יפה וקל יחסית עם נקודות נוף, פסל Lady Buddha ועצירות קצרות שלא מרגישות כמו מסלול.",
    "reviews": "עובד טוב עם ילד קטן כי רובו מבוסס רכב ועצירות קצרות. שווה להימנע משעות הצהריים ולזכור שמדובר יותר בנוף ובאווירה מאשר באטרקציה אינטראקטיבית.",
    "icon": "🛕"
  },
  {
    "name": "Marble Mountains",
    "destination": "da_nang",
    "category_he": "טבע ותצפיות",
    "category": "טבע ותצפיות",
    "score": null,
    "tags": [
      "challenging"
    ],
    "hours": "מומלץ מוקדם בבוקר",
    "phone": "",
    "link": "https://maps.google.com/?q=Marble+Mountains+Da+Nang",
    "why": "מקום מיוחד יותר ממה שנדמה: מערות, מקדשים ונקודות תצפית שמרגישות ממש כמו חוויה, בלי לצאת ליום מלא.",
    "reviews": "יש מעלית שעוזרת מאוד, אבל עדיין יש מדרגות והליכה, ולכן זה עלול להיות מעייף בחום או עם ילד עייף. מתאים אם באים מוקדם ועושים ביקור ממוקד.",
    "icon": "⛰️"
  },
  {
    "name": "Asia Park / Sun World Da Nang Downtown",
    "destination": "da_nang",
    "category_he": "פארקים ואטרקציות",
    "category": "פארקים ואטרקציות",
    "score": null,
    "tags": [],
    "hours": "מ‑15:00 עד הערב",
    "phone": "",
    "link": "https://maps.google.com/?q=Asia+Park+Da+Nang",
    "why": "אופציית ערב מצוינת אם רוצים משהו קליל וכיפי בלי להתחייב ליום שלם.",
    "reviews": "היתרון הגדול הוא השעות: זה עובד טוב אחרי מנוחה במלון. מתאים במיוחד אם רוצים לשלב גלגל ענק ואווירת לילה, אבל לא תמיד חייבים להישאר הרבה זמן.",
    "icon": "🎡"
  },
  {
    "name": "Han Market",
    "destination": "da_nang",
    "category_he": "שווקים וקניות",
    "category": "שווקים וקניות",
    "score": null,
    "tags": [
      "shopping"
    ],
    "hours": "בוקר–אחה״צ",
    "phone": "",
    "link": "https://maps.google.com/?q=Han+Market+Da+Nang",
    "why": "שוק טוב להכרת העיר, קניות קטנות והצצה לחיים המקומיים, במיוחד אם רוצים משהו קצר בעיר עצמה.",
    "reviews": "זה יותר שימושי ממרגש. יכול להיות עמוס ומבלבל, אבל בתור עצירה קצרה של שעה–שעה וחצי הוא מוסיף צבע מקומי נחמד.",
    "icon": "🛍️"
  },
  {
    "name": "Da Nang Museum of Cham Sculpture",
    "destination": "da_nang",
    "category_he": "מוזיאונים ותרבות",
    "category": "מוזיאונים ותרבות",
    "score": null,
    "tags": [
      "ac",
      "calm"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://maps.google.com/?q=Da+Nang+Museum+of+Cham+Sculpture",
    "why": "פתרון טוב ליום חם או גשום ולמי שרוצה עוד רובד תרבותי קליל בלי מאמץ פיזי.",
    "reviews": "לא מוזיאון שמחזיק הרבה זמן עם ילדים קטנים, אבל דווקא בגלל זה הוא עובד יפה כעצירה קצרה וממוזגת באמצע יום בעיר.",
    "icon": "🏺"
  },
  {
    "name": "Helio Night Market",
    "destination": "da_nang",
    "category_he": "עיר וערב",
    "category": "עיר וערב",
    "score": null,
    "tags": [],
    "hours": "ערב",
    "phone": "",
    "link": "https://maps.google.com/?q=Helio+Night+Market+Da+Nang",
    "why": "אופציית ערב זורמת לאוכל, אורות ואווירה, בלי לבנות תוכנית מסובכת.",
    "reviews": "טוב לשילוב עם Asia Park או ערב בעיר. יכול להיות רועש ועמוס, אז עדיף להתייחס אליו כקפיצה קצרה ולא כתוכנית מרכזית לערב שלם.",
    "icon": "🌃"
  },
  {
    "name": "Ba Na Hills & Golden Bridge",
    "destination": "da_nang",
    "category_he": "פארקים ואטרקציות",
    "category": "פארקים ואטרקציות",
    "score": null,
    "tags": [
      "challenging"
    ],
    "hours": "יום מלא",
    "phone": "",
    "link": "https://maps.google.com/?q=Ba+Na+Hills+Golden+Bridge",
    "why": "אחת האטרקציות הכי מפורסמות ומרשימות באזור, עם רכבל ארוך, Golden Bridge והרגשה של יום ׳גדול׳ ומיוחד.",
    "reviews": "שווה להכניס לאתר כי זו אטרקציית חובה קלאסית באזור, אבל חשוב לדעת שזה יום ארוך, יכול להיות עמוס מאוד, ויש בו לא מעט הליכה. יותר מתאים אם קמים עם הרבה אנרגיה ומקבלים מראש שזה יהיה יום מעייף.",
    "icon": "🌉"
  },
  {
    "name": "Tieng Vong Pho Lantern Workshop",
    "destination": "hoi_an",
    "category_he": "משחקיות וסדנאות",
    "category": "משחקיות וסדנאות",
    "score": 5,
    "tags": [
      "ac",
      "calm"
    ],
    "hours": "נפתח לרוב סביב 08:30; מומלץ לתאם מראש",
    "phone": "",
    "link": "https://maps.google.com/?q=Tieng+Vong+Pho+Lantern+Workshop+Hoi+An",
    "why": "סדנת עששיות היא אחת החוויות הכי מזוהות עם הוי אן, והמקום הזה בולט במיוחד בזכות כמות ביקורות גבוהה מאוד ודירוג מצוין. הילדים מקבלים תוצר יפה וצבעוני שמתחבר ממש לאופי של העיר.",
    "reviews": "לפי הביקורות זה מקום מסודר, משפחתי וידידותי לתיירים, עם הדרכה ברורה. מתאים גם לילדים, אבל לילדים קטנים כדאי לבחור עיצוב פשוט ולשבת איתם לאורך הפעילות.",
    "icon": "🏮"
  },
  {
    "name": "Botanica Garden Hoi An – Workshop Hub",
    "destination": "hoi_an",
    "category_he": "משחקיות וסדנאות",
    "category": "משחקיות וסדנאות",
    "score": 4,
    "tags": [
      "calm"
    ],
    "hours": "בתיאום מראש",
    "phone": "",
    "link": "https://maps.app.goo.gl/2rLqfd58BqpzVWVZ8",
    "why": "מרחב יצירה יפה ומושקע עם סדנאות ברמה גבוהה שמתאימות גם לילדים וגם להורים. זו אופציה טובה כשרוצים פעילות איכותית יותר, לא רק משחקייה.",
    "reviews": "נראה כמו מקום יותר פרימיום מבחינת אווירה ומחיר. מתאים במיוחד ליום יצירה מתוכנן מראש, פחות לקפיצה ספונטנית קצרה.",
    "icon": "🖌️"
  },
  {
    "name": "Liulo Coffee & Kids Workshop",
    "destination": "hoi_an",
    "category_he": "משחקיות וסדנאות",
    "category": "משחקיות וסדנאות",
    "score": 4,
    "tags": [
      "calm"
    ],
    "hours": "בתיאום מראש / לפי סדנאות",
    "phone": "",
    "link": "https://maps.app.goo.gl/LYkLjBwt9Nbbo74Y6",
    "why": "שילוב נוח בין בית קפה לסדנת יצירה לילדים. מתאים מאוד כשמחפשים פעילות נעימה ולא כבדה, עם משהו קטן לאכול או לשתות תוך כדי.",
    "reviews": "המחיר שצוין בהמלצות כולל משקה ומאפה, ולכן זו חוויה יחסית סגורה וברורה. פחות ‘וואו’ מסדנה גדולה, אבל מאוד שימושית לשגרה של חודש.",
    "icon": "🎨"
  },
  {
    "name": "Funny Land Hoi An",
    "destination": "hoi_an",
    "category_he": "משחקיות וסדנאות",
    "category": "משחקיות וסדנאות",
    "score": 4,
    "tags": [
      "ac"
    ],
    "hours": "פתוח אחרי הצהריים ובסופי שבוע עד 12:00 לפי ההמלצה",
    "phone": "",
    "link": "https://maps.app.goo.gl/ZtwcGeozUmdUMrPd6",
    "why": "משחקייה מלאה יותר, עם פינות משחק, משחקי ארקייד ובית קפה בחוץ. טובה במיוחד ליום שבו צריך לפרוק אנרגיה בלי להסתובב בשמש.",
    "reviews": "היתרון הוא מגוון הפעילויות והמחיר הנוח יחסית. כדאי לבדוק שעות לפני שמגיעים, כי לפי ההמלצות שעות הפעילות לא תמיד מלאות לאורך כל היום.",
    "icon": "🎡"
  },
  {
    "name": "Softplay Hoi An",
    "destination": "hoi_an",
    "category_he": "משחקיות וסדנאות",
    "category": "משחקיות וסדנאות",
    "score": 4,
    "tags": [
      "ac"
    ],
    "hours": "פתוח משעות הבוקר ובסופי שבוע עד 11:30 לפי ההמלצה",
    "phone": "",
    "link": "https://maps.app.goo.gl/4F7utVm764dueSHz6",
    "why": "משחקייה חדשה יחסית וברמה גבוהה יותר, עם הרבה פינות משחק. מתאימה במיוחד לילדים קטנים שצריכים מקום בטוח, ממוזג וברור.",
    "reviews": "נשמעת כמו אחת האופציות הטובות יותר למשחקייה בהוי אן, במיוחד אם מחפשים מקום נקי ומסודר. החיסרון העיקרי הוא שעות פתיחה מוגבלות יחסית.",
    "icon": "🎈"
  },
  {
    "name": "Zen Library Hoi An",
    "destination": "hoi_an",
    "category_he": "בתי קפה ונקודות עצירה",
    "category": "בתי קפה ונקודות עצירה",
    "score": 4,
    "tags": [
      "ac",
      "calm"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://maps.app.goo.gl/K9ANdasBCYqZzRT4A",
    "why": "ספרייה עם בית קפה וספרי ילדים באנגלית. זה לא בילוי רועש, אלא מקום שקט ומסודר להפוגה, קריאה וקפה.",
    "reviews": "מעולה למשפחות שמחפשות מקום רגוע ואיכותי, במיוחד לילדים שאוהבים ספרים או צריכים זמן שקט. פחות מתאים אם הילדים חייבים לרוץ ולהוציא אנרגיה.",
    "icon": "📚"
  },
  {
    "name": "Nấm Cafe – Pet Cafe",
    "destination": "hoi_an",
    "category_he": "בתי קפה ונקודות עצירה",
    "category": "בתי קפה ונקודות עצירה",
    "score": 4,
    "tags": [
      "calm"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://maps.app.goo.gl/Je4snXatAFkvvJkC7",
    "why": "בית קפה עם חיות, מרחב יחסית גדול ואפשרות לקנות אוכל לחיות. מתאים לילדים שאוהבים בעלי חיים ורוצים חוויה קלילה ולא ארוכה.",
    "reviews": "חוויה נחמדה ולא מחייבת. חשוב להגיע עם ציפיות נכונות: זה יותר קפה עם אינטראקציה עם חיות מאשר אטרקציה גדולה.",
    "icon": "🐾"
  },
  {
    "name": "Duck Stop Hoi An",
    "destination": "hoi_an",
    "category_he": "טבע וכפרים",
    "category": "טבע וכפרים",
    "score": 4,
    "tags": [
      "calm"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://maps.app.goo.gl/gookdnnzjSnDtf9BA",
    "why": "חוויה חמודה ושונה של האכלת ברווזים במקום מקומי. זו לא אטרקציית חובה, אבל מאוד מתאימה לילדים שאוהבים חיות וליום שבו רוצים משהו קצר ופשוט.",
    "reviews": "לפי המלצות מטיילים, העלות משתנה לפי מה שבוחרים לתת/לעשות במקום. מתאים כעצירה קצרה ולא כמרכז יום.",
    "icon": "🦆"
  },
  {
    "name": "Mikazuki Water Park 365",
    "destination": "da_nang",
    "category_he": "פארקים ואטרקציות",
    "category": "פארקים ואטרקציות",
    "score": 4,
    "tags": [
      "water",
      "ac"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://maps.app.goo.gl/iE3RDHBsH6qpLiDNA",
    "why": "פארק מים מקורה בדה נאנג שיכול לעבוד מעולה ביום חם או גשום. יש אזורים לילדים, בריכות, מגלשות, משחקייה ומתחמי ספא למבוגרים.",
    "reviews": "זו אופציה חזקה מאוד למשפחות, במיוחד אם רוצים יום ‘בטוח’ שלא תלוי במזג האוויר. מצד שני זה יום שיכול להרגיש מסחרי ועמוס, אז כדאי להגיע מוקדם.",
    "icon": "🌊"
  },
  {
    "name": "ECO Coffee and Restaurant",
    "destination": "hoi_an",
    "category_he": "בתי קפה ונקודות עצירה",
    "category": "בתי קפה ונקודות עצירה",
    "score": 4,
    "tags": [
      "calm"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://maps.app.goo.gl/655BLVyjSV7rNNNEA",
    "why": "בית קפה עם פינת משחק לילדים בחוץ. מקום נעים ונחמד לעצירה רגועה, במיוחד כשצריך קפה להורים ומרחב קטן לילדים.",
    "reviews": "מתאים כעצירה קלה ולא כאטרקציה גדולה. כדאי להגיע בשעות פחות חמות כי אזור המשחק בחוץ.",
    "icon": "☕"
  },
  {
    "name": "Suoi Mo Waterfall Thác Suối Mơ",
    "destination": "hoi_an",
    "category_he": "טבע וכפרים",
    "category": "טבע וכפרים",
    "score": 4,
    "tags": [
      "water",
      "challenging"
    ],
    "hours": "מומלץ בבוקר",
    "phone": "",
    "link": "https://maps.app.goo.gl/MoRNthTgVqMK7P3A6",
    "why": "בריכה נחמדה עם מפל חמוד ותחושה טבעית יותר מהעיר. טוב ליום שבו רוצים מים וטבע בלי לנסוע רחוק מדי.",
    "reviews": "לפי ההמלצות יש הליכה קצרה מהכניסה עד הבריכה. המקום יכול להיות נחמד מאוד לרענון, אבל עם ילד קטן כדאי להגיע מוקדם ולבדוק תנאים במקום.",
    "icon": "🏞️"
  },
  {
    "name": "Herbal Spa An Bang Beach",
    "destination": "hoi_an",
    "category_he": "ספא",
    "category": "ספא",
    "score": 4,
    "tags": [
      "ac",
      "calm"
    ],
    "hours": "עד ערב, לפי המקום",
    "phone": "",
    "link": "https://maps.google.com/?q=Herbal+Spa+An+Bang+Beach+Hoi+An",
    "why": "ספא מומלץ באזור An Bang Beach, מתאים במיוחד להורים בלבד בזמן שיש חלון קצר לעצמכם. אפשר לשלב עם חוף או ארוחה באזור.",
    "reviews": "הביקורות נראות חזקות והמיקום נוח מאוד למי שנמצא באזור החוף. זה לא מקום לילדים, ולכן באתר כדאי לסמן בבירור כ'להורים בלבד'.",
    "icon": "💆‍♀️"
  },
  {
    "name": "Palm River Academy",
    "destination": "hoi_an",
    "category_he": "משחקיות וסדנאות",
    "category": "משחקיות וסדנאות",
    "score": 5,
    "tags": [
      "calm"
    ],
    "hours": "בתיאום מראש",
    "phone": "",
    "link": "https://maps.google.com/?q=Palm+River+Academy+Hoi+An",
    "why": "גן ובית ספר בסגנון טבעי/קהילתי שיכול להיות רלוונטי מאוד לשהות של חודש, במיוחד אם מחפשים מסגרת, פעילות באנגלית או חיבור לילדים אחרים.",
    "reviews": "ההמלצה שצירפת חזקה ואישית במיוחד, והיא מצביעה על צוות חם, סביבה ירוקה ותחושה משפחתית. מתאים לבדיקה מראש ולא כ'אטרקציה' ספונטנית.",
    "icon": "🌿"
  },
  {
    "name": "מכוניות ואופנועים חשמליים לילדים – Hoi An",
    "destination": "hoi_an",
    "category_he": "משחקיות וסדנאות",
    "category": "משחקיות וסדנאות",
    "score": 4,
    "tags": [],
    "hours": "מ־18:00 בערב",
    "phone": "",
    "link": "https://maps.app.goo.gl/tA2QVXnyPfAA6SnX6",
    "why": "פעילות ערב פשוטה ומהירה לילדים: השכרת כלי רכב חשמליים קטנים באזור פתוח. טוב במיוחד כשרוצים להוציא אנרגיה אחרי יום רגוע.",
    "reviews": "ההמלצה מציינת שהפעילות מתאימה גם לילדים קטנים ומהירה מאוד לביצוע. זו לא אטרקציית חובה, אבל שימושית מאוד לשהות ארוכה.",
    "icon": "🏎️"
  },
  {
    "name": "בסיס דאלאת",
    "destination": "dalat",
    "category_he": "בסיס",
    "category": "בסיס",
    "score": null,
    "tags": [],
    "hours": "",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Da%20Lat%20Vietnam",
    "why": "",
    "reviews": "",
    "icon": "🏠"
  },
  {
    "name": "Crazy House",
    "destination": "dalat",
    "category_he": "אטרקציות",
    "category": "אטרקציות",
    "score": 5,
    "tags": [
      "rain"
    ],
    "hours": "09:00–18:00",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Crazy%20House%20Dalat",
    "why": "אחת האטרקציות הכי מיוחדות בדאלאת: מבנה אגדתי עם מדרגות, גשרים, חדרים מוזרים ופינות חקירה שילדים בדרך כלל מאוד אוהבים.",
    "reviews": "חוויה מאוד זכורה ומשעשעת, אבל לא מקום לשחרר בו ילד קטן לבד. יש מדרגות, מעברים צרים ונקודות שדורשות השגחה צמודה.",
    "icon": "🏠"
  },
  {
    "name": "Xuan Huong Lake",
    "destination": "dalat",
    "category_he": "טבע ונופים",
    "category": "טבע ונופים",
    "score": 4,
    "tags": [
      "calm"
    ],
    "hours": "כל היום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Xuan%20Huong%20Lake%20Dalat",
    "why": "אגם מרכזי ונעים להליכה רגועה, סיבוב קצר, סירות פדלים או עצירה קלה בין אטרקציות בעיר.",
    "reviews": "לא אטרקציה גדולה בפני עצמה, אבל שימושי מאוד כעוגן רגוע במרכז. מתאים במיוחד לבוקר או אחר הצהריים.",
    "icon": "🛶"
  },
  {
    "name": "Dalat Night Market",
    "destination": "dalat",
    "category_he": "תרבות ועיר",
    "category": "תרבות ועיר",
    "score": 4,
    "tags": [],
    "hours": "מ־18:00 בערב",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Dalat%20Night%20Market",
    "why": "שוק ערב גדול עם אוכל רחוב, תותים, קינוחים, צעצועים ואווירה מקומית צבעונית.",
    "reviews": "שווה לערב קצר, אבל יכול להיות עמוס מאוד. עדיף להגיע מוקדם יחסית ולא לבנות על שיטוט ארוך עם ילדים עייפים.",
    "icon": "🌃"
  },
  {
    "name": "Datanla Waterfall & Alpine Coaster",
    "destination": "dalat",
    "category_he": "טבע ונופים",
    "category": "טבע ונופים",
    "score": 5,
    "tags": [
      "water"
    ],
    "hours": "07:00–17:00",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Datanla%20Waterfall%20Alpine%20Coaster%20Dalat",
    "why": "המפל הכי מתאים למשפחות באזור, בעיקר בזכות ה-Alpine Coaster שהופך את הביקור לחוויה ולא רק למסלול.",
    "reviews": "אחת ההמלצות החזקות בדאלאת עם ילדים. מומלץ להגיע בבוקר, לקחת בחשבון תורים ולבדוק מראש מגבלות גיל/גובה למזחלות.",
    "icon": "🌊"
  },
  {
    "name": "Robin Hill Cable Car",
    "destination": "dalat",
    "category_he": "אטרקציות",
    "category": "אטרקציות",
    "score": 4,
    "tags": [
      "calm"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Robin%20Hill%20Cable%20Car%20Dalat",
    "why": "רכבל נעים עם תצפית יפה על העיר והעמקים, ומתאים מאוד לשילוב עם Truc Lam ו-Tuyen Lam Lake.",
    "reviews": "חוויה קצרה ונוחה יחסית עם ילדים. טובה במיוחד ביום עם ראות טובה, פחות אם מזג האוויר סגור או גשום.",
    "icon": "🚡"
  },
  {
    "name": "Truc Lam Zen Monastery",
    "destination": "dalat",
    "category_he": "תרבות ועיר",
    "category": "תרבות ועיר",
    "score": 4,
    "tags": [
      "calm"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Truc%20Lam%20Zen%20Monastery%20Dalat",
    "why": "מנזר יפה ושקט בקצה הרכבל, עם גנים מטופחים ואווירה רגועה. טוב כעצירה קצרה ולא עמוסה.",
    "reviews": "לא מקום שמחזיק יום שלם עם ילדים, אבל משתלב מצוין עם הרכבל והאגם. מתאים אם שומרים על ביקור קצר.",
    "icon": "⛩️"
  },
  {
    "name": "Tuyen Lam Lake",
    "destination": "dalat",
    "category_he": "טבע ונופים",
    "category": "טבע ונופים",
    "score": 4,
    "tags": [
      "calm",
      "water"
    ],
    "hours": "כל היום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Tuyen%20Lam%20Lake%20Dalat",
    "why": "אגם שקט ופסטורלי ליד המנזר, עם נוף, בתי קפה ואפשרות לעצירה רגועה.",
    "reviews": "הכי נכון לשלב אותו כחלק מיום רכבל/מנזר/Clay Tunnel ולא כיעד בודד. טוב למנוחה והורדת קצב.",
    "icon": "🌅"
  },
  {
    "name": "Clay Sculpture Tunnel",
    "destination": "dalat",
    "category_he": "אטרקציות",
    "category": "אטרקציות",
    "score": 4,
    "tags": [
      "rain"
    ],
    "hours": "07:30–17:00",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Clay%20Sculpture%20Tunnel%20Dalat",
    "why": "פארק פסלי חימר גדול ופוטוגני, עם הרבה נקודות צילום ומסלול יחסית ברור.",
    "reviews": "נחמד מאוד לשילוב עם Tuyen Lam Lake. לא חובה אם יש עומס או גשם חזק, אבל מתאים כתחנה משפחתית קלה יחסית.",
    "icon": "🗿"
  },
  {
    "name": "Dalat Railway Station",
    "destination": "dalat",
    "category_he": "תרבות ועיר",
    "category": "תרבות ועיר",
    "score": 4,
    "tags": [
      "calm"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Dalat%20Railway%20Station",
    "why": "תחנת רכבת היסטורית וצבעונית, עם אפשרות לרכבת קצרה לכיוון Trai Mat ולinh Phuoc Pagoda.",
    "reviews": "מתאים כעצירה קצרה, בעיקר אם משלבים נסיעה ברכבת. בלי הרכבת זה נחמד אבל לא חובה.",
    "icon": "🚂"
  },
  {
    "name": "Linh Phuoc Pagoda",
    "destination": "dalat",
    "category_he": "תרבות ועיר",
    "category": "תרבות ועיר",
    "score": 4,
    "tags": [
      "calm"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Linh%20Phuoc%20Pagoda%20Dalat",
    "why": "מקדש צבעוני ומרשים עם פסיפסים ופרטים מיוחדים, בדרך כלל משולב עם נסיעת הרכבת ל-Trai Mat.",
    "reviews": "מעניין ויפה ויזואלית, אבל עם ילדים קטנים כדאי לשמור על ביקור קצר ולא להפוך את זה ליום מקדשים.",
    "icon": "🛕"
  },
  {
    "name": "Bao Dai Summer Palace",
    "destination": "dalat",
    "category_he": "תרבות ועיר",
    "category": "תרבות ועיר",
    "score": 3,
    "tags": [
      "rain"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Bao%20Dai%20Summer%20Palace%20Dalat",
    "why": "ארמון הקיץ של הקיסר האחרון, מתאים למי שרוצה קצת היסטוריה מקומית בתוך ביקור קצר.",
    "reviews": "פחות אטרקציה לילדים ויותר עצירת תרבות למבוגרים. להוסיף אם אתם באזור, לא הייתי נוסעת במיוחד עם ילדים קטנים.",
    "icon": "🏛️"
  },
  {
    "name": "Puppy Farm",
    "destination": "dalat",
    "category_he": "אטרקציות",
    "category": "אטרקציות",
    "score": 5,
    "tags": [
      "calm"
    ],
    "hours": "08:00–17:00",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Puppy%20Farm%20Dalat",
    "why": "חווה מאוד פופולרית למשפחות עם כלבים, קפיברות, ארנבים, גינות, תותים ואזורים פתוחים.",
    "reviews": "מהאטרקציות שהכי חוזרות בהמלצות משפחות. להגיע מוקדם כדי להימנע מעומס, במיוחד בעונות תיירות ובסופי שבוע.",
    "icon": "🐶"
  },
  {
    "name": "Dalat Blue Mountain Farm",
    "destination": "dalat",
    "category_he": "אטרקציות",
    "category": "אטרקציות",
    "score": 5,
    "tags": [
      "calm"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Dalat%20Blue%20Mountain%20Farm",
    "why": "חווה עם קפה, בעלי חיים, תותים, סיור חקלאי ואווירה מאוד נעימה לילדים. אחת ההמלצות הכי רלוונטיות לשהות משפחתית בדאלאת.",
    "reviews": "מההמלצות ששלחת עולה שזו חוויה אישית ומוצלחת במיוחד, עם מדריכים שמסבירים לילדים על חיות וגידולים. מתאים יותר כסיור מתואם מראש.",
    "icon": "🐐"
  },
  {
    "name": "Mongo Land Dalat",
    "destination": "dalat",
    "category_he": "אטרקציות",
    "category": "אטרקציות",
    "score": 4,
    "tags": [
      "calm"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Mongo%20Land%20Dalat",
    "why": "מתחם צבעוני עם חיות, אזורי צילום, גינות ואטרקציות קלילות בסגנון פארק משפחתי.",
    "reviews": "מתאים לילדים ומאוד פוטוגני, אבל יכול להרגיש תיירותי. טוב אם משלבים עם עוד חווה או קפה באזור.",
    "icon": "🦙"
  },
  {
    "name": "Zoodoo Dalat",
    "destination": "dalat",
    "category_he": "אטרקציות",
    "category": "אטרקציות",
    "score": 4,
    "tags": [
      "calm"
    ],
    "hours": "בתיאום מראש",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Zoodoo%20Dalat",
    "why": "חוות חיות בסגנון יותר מסודר, עם אלפקות, קנגורו וחיות שילדים יכולים לראות מקרוב.",
    "reviews": "חוויה טובה מאוד למשפחות, אבל מרוחקת יחסית מהמרכז ולכן מתאימה רק אם בונים סביבה חצי יום ולא כקפיצה קצרה.",
    "icon": "🦘"
  },
  {
    "name": "Valley of Love",
    "destination": "dalat",
    "category_he": "טבע ונופים",
    "category": "טבע ונופים",
    "score": 4,
    "tags": [
      "calm"
    ],
    "hours": "07:00–17:00",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Valley%20of%20Love%20Dalat",
    "why": "פארק גדול עם גנים, אגם, פסלים, מתקנים ונקודות צילום. מתאים למשפחה שרוצה יום קליל בלי מסלול טבע מאתגר.",
    "reviews": "מתויר ומעט קיטשי, אבל ילדים נהנים מהמרחב ומהאטרקציות הקטנות. עדיף להגיע מוקדם ולא באמצע היום.",
    "icon": "💚"
  },
  {
    "name": "Dalat Flower Garden",
    "destination": "dalat",
    "category_he": "טבע ונופים",
    "category": "טבע ונופים",
    "score": 3,
    "tags": [
      "calm"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Dalat%20Flower%20Garden",
    "why": "גן פרחים במרכז העיר, מתאים לסיבוב קצר וצילומים.",
    "reviews": "נחמד אם נמצאים בסביבה, אבל פחות חווייתי לילדים לעומת חוות, מפלים או פארקים עם פעילות.",
    "icon": "🌸"
  },
  {
    "name": "Van Thanh Flower Village",
    "destination": "dalat",
    "category_he": "טבע ונופים",
    "category": "טבע ונופים",
    "score": 4,
    "tags": [
      "calm"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Van%20Thanh%20Flower%20Village%20Dalat",
    "why": "כפר פרחים וחממות באזור יפה, מתאים למי שרוצה לראות את הצד החקלאי והצבעוני של דאלאת.",
    "reviews": "יותר מעניין אם משלבים עם קפה/חווה סמוכה. כיעד יחיד יכול להיות קצר מדי לילדים.",
    "icon": "💐"
  },
  {
    "name": "Fresh Garden Dalat",
    "destination": "dalat",
    "category_he": "טבע ונופים",
    "category": "טבע ונופים",
    "score": 4,
    "tags": [
      "calm"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Fresh%20Garden%20Dalat",
    "why": "גן פרחים גדול ופוטוגני עם פסלים, נוף וקפה. מתאים ליום רגוע בלי הרבה מאמץ.",
    "reviews": "יפה ונעים, אבל בעיקר מקום לצילומים וסיבוב. לא הייתי בונה עליו יום שלם עם ילדים.",
    "icon": "🌷"
  },
  {
    "name": "Dalat Fairytale Land",
    "destination": "dalat",
    "category_he": "אטרקציות",
    "category": "אטרקציות",
    "score": 4,
    "tags": [
      "rain"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Dalat%20Fairytale%20Land",
    "why": "מתחם אגדות קטן וצבעוני, קרוב יחסית לאזור Vinh Tien ולכפר הפרחים, מתאים לילדים בזכות האווירה והדמויות.",
    "reviews": "יותר מקום חמוד ופוטוגני מאשר אטרקציית חובה. עובד טוב כשמשלבים עם עוד תחנה באזור.",
    "icon": "🧚"
  },
  {
    "name": "Langbiang Mountain",
    "destination": "dalat",
    "category_he": "טבע ונופים",
    "category": "טבע ונופים",
    "score": 4,
    "tags": [
      "challenging"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Langbiang%20Mountain%20Dalat",
    "why": "תצפית מפורסמת על האזור, עם אפשרות לעלות בג׳יפ במקום טרק. מתאים אם רוצים נוף רחב ותחושת הרים.",
    "reviews": "עם ילדים קטנים עדיף לא לעשות מסלול רגלי. הג׳יפים חווייתיים אבל יכולים להיות עמוסים ותיירותיים.",
    "icon": "⛰️"
  },
  {
    "name": "Làng Cù Lần",
    "destination": "dalat",
    "category_he": "טבע ונופים",
    "category": "טבע ונופים",
    "score": 4,
    "tags": [
      "calm"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Lang%20Cu%20Lan%20Dalat",
    "why": "כפר/פארק טבעי מחוץ לעיר עם נוף, גשרים, מים ואווירה כפרית.",
    "reviews": "יכול להיות יפה מאוד, אבל דורש נסיעה ולא תמיד מצדיק אם יש לכם רק מעט ימים. מתאים ביום נופים רחב יותר.",
    "icon": "🌲"
  },
  {
    "name": "Elephant Waterfall",
    "destination": "dalat",
    "category_he": "טבע ונופים",
    "category": "טבע ונופים",
    "score": 3,
    "tags": [
      "water",
      "challenging"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Elephant%20Waterfall%20Dalat",
    "why": "מפל עוצמתי ומרשים באזור מערב דאלאת.",
    "reviews": "להכניס לאתר, אבל עם אזהרה ברורה: פחות מתאים לילדים קטנים בגלל מדרגות, רטיבות והליכה שעלולה להיות מחליקה.",
    "icon": "💦"
  },
  {
    "name": "Linh An Pagoda",
    "destination": "dalat",
    "category_he": "תרבות ועיר",
    "category": "תרבות ועיר",
    "score": 4,
    "tags": [
      "calm"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Linh%20An%20Pagoda%20Dalat",
    "why": "פגודה גדולה ומרשימה ליד Elephant Waterfall, עם פסל בודהה ענק ואווירה מיוחדת.",
    "reviews": "שווה לשלב אם כבר נוסעים לאזור המפלים והקפה. פחות הייתי נוסעת במיוחד רק לזה עם ילדים קטנים.",
    "icon": "🛕"
  },
  {
    "name": "Me Linh Coffee Garden",
    "destination": "dalat",
    "category_he": "בתי קפה לילדים",
    "category": "בתי קפה לילדים",
    "score": 4,
    "tags": [
      "calm"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Me%20Linh%20Coffee%20Garden%20Dalat",
    "why": "בית קפה עם נוף פנורמי למטעים, מתאים לעצירה ביום מערב דאלאת.",
    "reviews": "הנוף הוא העיקר. טוב להורים, לילדים פחות יש פעילות משמעותית, לכן עדיף לשלב ולא להפוך ליעד מרכזי.",
    "icon": "☕"
  },
  {
    "name": "Happy Hill Coffee",
    "destination": "dalat",
    "category_he": "בתי קפה לילדים",
    "category": "בתי קפה לילדים",
    "score": 4,
    "tags": [
      "calm"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Happy%20Hill%20Coffee%20Dalat",
    "why": "קפה פוטוגני בטבע, טוב לעצירה רגועה ולתמונות באזור האגם.",
    "reviews": "נחמד מאוד אם אתם באזור Tuyen Lam, פחות חובה אם צריך לנסוע במיוחד.",
    "icon": "☕"
  },
  {
    "name": "Langfarm Center",
    "destination": "dalat",
    "category_he": "תרבות ועיר",
    "category": "תרבות ועיר",
    "score": 4,
    "tags": [
      "rain"
    ],
    "hours": "שעות יום וערב",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Langfarm%20Center%20Dalat",
    "why": "חנות/מרכז טעימות של מוצרים מקומיים כמו תותים מיובשים, ריבות ופירות. טוב לעצירה קצרה וקניות.",
    "reviews": "נחמד מאוד כתוספת לשוק או למרכז העיר, במיוחד אם רוצים לקנות מתנות או נשנושים מקומיים.",
    "icon": "🍓"
  },
  {
    "name": "Silk Factory Dalat",
    "destination": "dalat",
    "category_he": "תרבות ועיר",
    "category": "תרבות ועיר",
    "score": 3,
    "tags": [
      "rain"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Silk%20Factory%20Dalat",
    "why": "ביקור במפעל משי מקומי, מתאים אם רוצים פעילות קצרה עם ערך תרבותי בדרך לאזור כפרים/פרחים.",
    "reviews": "יותר מעניין למבוגרים מאשר לילדים קטנים, אבל יכול להיות עצירה קצרה טובה אם זה על הדרך.",
    "icon": "🧵"
  },
  {
    "name": "Strawberry Farm Dalat",
    "destination": "dalat",
    "category_he": "אטרקציות",
    "category": "אטרקציות",
    "score": 4,
    "tags": [
      "calm"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Strawberry%20Farm%20Dalat",
    "why": "קטיף/ביקור בחוות תותים, חוויה פשוטה וכיפית לילדים שמתאימה מאוד לאופי של דאלאת.",
    "reviews": "שווה לבחור חווה עם ביקורות עדכניות ולבדוק אם יש קטיף בפועל באותו יום. לא כל החוות נותנות אותה חוויה.",
    "icon": "🍓"
  },
  {
    "name": "Joy Dalat Kids Café",
    "destination": "dalat",
    "category_he": "בתי קפה לילדים",
    "category": "בתי קפה לילדים",
    "score": 4,
    "tags": [
      "rain",
      "ac"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Joy%20Dalat%20Kids%20Cafe%20Playground",
    "why": "בית קפה לילדים עם אזור משחק וחול, מתאים מאוד להפוגה ביום גשם או ביום קר.",
    "reviews": "שימושי מאוד למשפחות כי ההורים יכולים לשבת והילדים משחקים. לבדוק שעות לפני הגעה.",
    "icon": "☕"
  },
  {
    "name": "Dang Dan Cafe & Kids House",
    "destination": "dalat",
    "category_he": "בתי קפה לילדים",
    "category": "בתי קפה לילדים",
    "score": 4,
    "tags": [
      "rain",
      "ac"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Dang%20Dan%20Cafe%20Kids%20House%20Dalat",
    "why": "קפה עם אזור משחק לילדים, מכוניות קטנות ופינות ישיבה להורים.",
    "reviews": "מתאים להפוגה ולא כיעד גדול. טוב במיוחד לשהות ארוכה כשצריך מקום קבוע לחזור אליו.",
    "icon": "☕"
  },
  {
    "name": "Dream House Dalat",
    "destination": "dalat",
    "category_he": "בתי קפה לילדים",
    "category": "בתי קפה לילדים",
    "score": 3,
    "tags": [
      "calm"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Dream%20House%20Dalat%20cafe%20kids",
    "why": "בית קפה עם אווירה משפחתית וחיות/אזור ילדים, מתאים לעצירה קלה.",
    "reviews": "נחמד אם קרוב אליכם, אבל פחות חזק מאטרקציות הילדים המרכזיות. להכניס כאופציה ולא כ-must.",
    "icon": "🐾"
  },
  {
    "name": "Ladalat Kids Playground",
    "destination": "dalat",
    "category_he": "משחקיות",
    "category": "משחקיות",
    "score": 4,
    "tags": [
      "rain",
      "ac"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Ladalat%20Kids%20Playground",
    "why": "משחקייה גדולה יחסית בתוך מתחם מלון, טובה במיוחד ליום גשם או להוצאת אנרגיה.",
    "reviews": "פתרון פרקטי מאוד ולא בהכרח חוויית חובה. מתאים לילדים קטנים כשצריך מקום סגור ונוח.",
    "icon": "🧸"
  },
  {
    "name": "Titan Kids Playground Dalat",
    "destination": "dalat",
    "category_he": "משחקיות",
    "category": "משחקיות",
    "score": 3,
    "tags": [
      "rain",
      "ac"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Titan%20Kids%20Playground%20Dalat",
    "why": "משחקייה מקומית סגורה, מתאימה ליום גשם או שעה-שעתיים של משחק.",
    "reviews": "לא אטרקציה ייחודית, אבל שימושית מאוד אם נמצאים באזור ורוצים פתרון לילדים.",
    "icon": "🧸"
  },
  {
    "name": "Yoyo Play Kids Dalat",
    "destination": "dalat",
    "category_he": "משחקיות",
    "category": "משחקיות",
    "score": 3,
    "tags": [
      "rain",
      "ac"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Yoyo%20Play%20Kids%20Dalat",
    "why": "משחקייה מקומית נוספת שיכולה להתאים לשעת משחק קצרה.",
    "reviews": "להשתמש כאופציה גמישה לפי מיקום ומזג אוויר, לא כיעד מרכזי.",
    "icon": "🧸"
  },
  {
    "name": "Herbal Spa Dalat",
    "destination": "dalat",
    "category_he": "ספא",
    "category": "ספא",
    "score": 4,
    "tags": [
      "rain",
      "ac"
    ],
    "hours": "שעות יום וערב",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Herbal%20Spa%20Dalat",
    "why": "ספא להורים בלבד, מתאים אם יש חלון קצר להתאווררות בלי הילדים.",
    "reviews": "לא אטרקציה משפחתית, אבל חשוב להכניס לאתר כי בשהות ארוכה זה מידע שימושי להורים.",
    "icon": "💆‍♀️"
  },
  {
    "name": "QUÊ Garden",
    "destination": "dalat",
    "category_he": "טבע ונופים",
    "category": "טבע ונופים",
    "score": 4,
    "tags": [
      "calm"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=QU%C3%8A%20Garden%20Dalat",
    "why": "המלצה משפחתית שנוספה לדאלאת.",
    "reviews": "מתאים בעיקר לשילוב גמיש לפי מזג האוויר והמיקום.",
    "icon": "🌿"
  },
  {
    "name": "Dalat City Flower Garden",
    "destination": "dalat",
    "category_he": "טבע ונופים",
    "category": "טבע ונופים",
    "score": 4,
    "tags": [
      "calm"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Dalat%20City%20Flower%20Garden%20Dalat",
    "why": "המלצה משפחתית שנוספה לדאלאת.",
    "reviews": "מתאים בעיקר לשילוב גמיש לפי מזג האוויר והמיקום.",
    "icon": "🌸"
  },
  {
    "name": "Dalat Flower Plateau Ecotourism Area",
    "destination": "dalat",
    "category_he": "טבע ונופים",
    "category": "טבע ונופים",
    "score": 4,
    "tags": [
      "calm"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Dalat%20Flower%20Plateau%20Ecotourism%20Area%20Dalat",
    "why": "המלצה משפחתית שנוספה לדאלאת.",
    "reviews": "מתאים בעיקר לשילוב גמיש לפי מזג האוויר והמיקום.",
    "icon": "🌺"
  },
  {
    "name": "Lumiere Da Lat - Light Garden",
    "destination": "dalat",
    "category_he": "אטרקציות",
    "category": "אטרקציות",
    "score": 4,
    "tags": [
      "calm"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Lumiere%20Da%20Lat%20-%20Light%20Garden%20Dalat",
    "why": "המלצה משפחתית שנוספה לדאלאת.",
    "reviews": "מתאים בעיקר לשילוב גמיש לפי מזג האוויר והמיקום.",
    "icon": "💡"
  },
  {
    "name": "Khu vui chơi trẻ em Oh My Kids Coffee",
    "destination": "dalat",
    "category_he": "בתי קפה לילדים",
    "category": "בתי קפה לילדים",
    "score": 4,
    "tags": [
      "rain"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Khu%20vui%20ch%C6%A1i%20tr%E1%BA%BB%20em%20Oh%20My%20Kids%20Coffee%20Dalat",
    "why": "המלצה משפחתית שנוספה לדאלאת.",
    "reviews": "מתאים בעיקר לשילוב גמיש לפי מזג האוויר והמיקום.",
    "icon": "☕"
  },
  {
    "name": "Fresh PlayGround - Khu Trò Chơi Vận Động",
    "destination": "dalat",
    "category_he": "משחקיות",
    "category": "משחקיות",
    "score": 4,
    "tags": [
      "rain"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Fresh%20PlayGround%20-%20Khu%20Tr%C3%B2%20Ch%C6%A1i%20V%E1%BA%ADn%20%C4%90%E1%BB%99ng%20Dalat",
    "why": "המלצה משפחתית שנוספה לדאלאת.",
    "reviews": "מתאים בעיקר לשילוב גמיש לפי מזג האוויר והמיקום.",
    "icon": "🧸"
  },
  {
    "name": "Duck Ducking Beach Xuan Huong Lake",
    "destination": "dalat",
    "category_he": "בתי קפה לילדים",
    "category": "בתי קפה לילדים",
    "score": 4,
    "tags": [
      "rain"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Duck%20Ducking%20Beach%20Xuan%20Huong%20Lake%20Dalat",
    "why": "המלצה משפחתית שנוספה לדאלאת.",
    "reviews": "מתאים בעיקר לשילוב גמיש לפי מזג האוויר והמיקום.",
    "icon": "🦆"
  },
  {
    "name": "Khu Vui Chơi",
    "destination": "dalat",
    "category_he": "משחקיות",
    "category": "משחקיות",
    "score": 4,
    "tags": [
      "rain"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Khu%20Vui%20Ch%C6%A1i%20Dalat",
    "why": "המלצה משפחתית שנוספה לדאלאת.",
    "reviews": "מתאים בעיקר לשילוב גמיש לפי מזג האוויר והמיקום.",
    "icon": "🧸"
  },
  {
    "name": "Tiệm Gốm Ung Dung",
    "destination": "dalat",
    "category_he": "אטרקציות",
    "category": "אטרקציות",
    "score": 4,
    "tags": [
      "calm"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Ti%E1%BB%87m%20G%E1%BB%91m%20Ung%20Dung%20Dalat",
    "why": "המלצה משפחתית שנוספה לדאלאת.",
    "reviews": "מתאים בעיקר לשילוב גמיש לפי מזג האוויר והמיקום.",
    "icon": "🎨"
  },
  {
    "name": "Cafe Sân",
    "destination": "dalat",
    "category_he": "בתי קפה לילדים",
    "category": "בתי קפה לילדים",
    "score": 4,
    "tags": [
      "rain"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Cafe%20S%C3%A2n%20Dalat",
    "why": "המלצה משפחתית שנוספה לדאלאת.",
    "reviews": "מתאים בעיקר לשילוב גמיש לפי מזג האוויר והמיקום.",
    "icon": "☕"
  },
  {
    "name": "Sữa BéBé - Kids Cafe",
    "destination": "dalat",
    "category_he": "בתי קפה לילדים",
    "category": "בתי קפה לילדים",
    "score": 4,
    "tags": [
      "rain"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=S%E1%BB%AFa%20B%C3%A9B%C3%A9%20-%20Kids%20Cafe%20Dalat",
    "why": "המלצה משפחתית שנוספה לדאלאת.",
    "reviews": "מתאים בעיקר לשילוב גמיש לפי מזג האוויר והמיקום.",
    "icon": "🍼"
  },
  {
    "name": "MIKI kid & Coffee",
    "destination": "dalat",
    "category_he": "בתי קפה לילדים",
    "category": "בתי קפה לילדים",
    "score": 4,
    "tags": [
      "rain"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=MIKI%20kid%20%26%20Coffee%20Dalat",
    "why": "המלצה משפחתית שנוספה לדאלאת.",
    "reviews": "מתאים בעיקר לשילוב גמיש לפי מזג האוויר והמיקום.",
    "icon": "☕"
  },
  {
    "name": "Như Ý Family - Cafe Kids",
    "destination": "dalat",
    "category_he": "בתי קפה לילדים",
    "category": "בתי קפה לילדים",
    "score": 4,
    "tags": [
      "rain"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Nh%C6%B0%20%C3%9D%20Family%20-%20Cafe%20Kids%20Dalat",
    "why": "המלצה משפחתית שנוספה לדאלאת.",
    "reviews": "מתאים בעיקר לשילוב גמיש לפי מזג האוויר והמיקום.",
    "icon": "☕"
  },
  {
    "name": "בסיס הו צ׳י מין",
    "destination": "hcmc",
    "category_he": "בסיס",
    "category": "בסיס",
    "score": null,
    "tags": [],
    "hours": "",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Ho%20Chi%20Minh%20City%20Vietnam",
    "why": "",
    "reviews": "",
    "icon": "🏠"
  },
  {
    "name": "Vietopia",
    "destination": "hcmc",
    "category_he": "משחקיות וסדנאות",
    "category": "משחקיות וסדנאות",
    "score": 5,
    "tags": [
      "ac",
      "rain"
    ],
    "hours": "שעות משתנות, מומלץ לבדוק לפני הגעה",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Vietopia%20Ho%20Chi%20Minh%20City",
    "why": "עיר ילדים ענקית שבה הילדים מתנסים במקצועות שונים כמו רופא, כבאי, טייס ועוד. זו אחת האטרקציות הכי חזקות לשבוע בעיר כי היא מחזיקה כמה שעות ונותנת חוויה אמיתית ולא רק משחקייה.",
    "reviews": "חוזר הרבה בהמלצות משפחות. רוב המבקרים מתארים בילוי של כמה שעות טובות, במיוחד לילדים בגילאי גן ובית ספר יסודי. כדאי להגיע כשיש מספיק אנרגיה ולא בסוף יום עמוס.",
    "icon": "🏙️"
  },
  {
    "name": "Kiwooza Planet – Thiso Mall Sala",
    "destination": "hcmc",
    "category_he": "משחקיות וסדנאות",
    "category": "משחקיות וסדנאות",
    "score": 5,
    "tags": [
      "ac",
      "rain",
      "mall"
    ],
    "hours": "לפי שעות הקניון",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Kiwooza%20Planet%20Thiso%20Mall%20Sala%20Ho%20Chi%20Minh",
    "why": "אחת המשחקיות הכי מושקעות בעיר, בתוך קניון נוח ומודרני. יש אזורי טיפוס, משחקי תפקידים, פעילות לפי גיל ואפשרות נוחה לאוכל לפני או אחרי.",
    "reviews": "מומלצת מאוד למשפחות בגלל הניקיון, המיזוג והמיקום הנוח. טובה במיוחד ליום גשם או לשעות החמות.",
    "icon": "🪐"
  },
  {
    "name": "tiNiWorld Thiso Mall",
    "destination": "hcmc",
    "category_he": "משחקיות וסדנאות",
    "category": "משחקיות וסדנאות",
    "score": 4,
    "tags": [
      "ac",
      "rain",
      "mall"
    ],
    "hours": "לפי שעות הקניון",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=tiNiWorld%20Thiso%20Mall%20Sala%20Ho%20Chi%20Minh",
    "why": "משחקייה מוכרת ונוחה בתוך קניון, מתאימה להפוגה של שעה-שעתיים בלי לתכנן יום שלם.",
    "reviews": "פתרון טוב מאוד כשצריך משהו בטוח, ממוזג וקל עם ילדים. פחות אטרקציה ייחודית ויותר מקום פרקטי לשגרה עירונית.",
    "icon": "🧸"
  },
  {
    "name": "Tinker Box",
    "destination": "hcmc",
    "category_he": "משחקיות וסדנאות",
    "category": "משחקיות וסדנאות",
    "score": 5,
    "tags": [
      "ac",
      "rain",
      "calm"
    ],
    "hours": "בתיאום / לפי פעילות",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Tinker%20Box%20Ho%20Chi%20Minh%20City",
    "why": "מרכז יצירה, חקר ו-STEM לילדים. מתאים במיוחד לילדים סקרנים שאוהבים לבנות, ליצור ולפתור דברים.",
    "reviews": "אופציה איכותית יותר ממשחקייה רגילה. כדאי לבדוק מראש אילו פעילויות מתקיימות ובאיזה גילאים.",
    "icon": "🧪"
  },
  {
    "name": "KIDS CAMP PLUS",
    "destination": "hcmc",
    "category_he": "משחקיות וסדנאות",
    "category": "משחקיות וסדנאות",
    "score": 4,
    "tags": [
      "ac",
      "rain"
    ],
    "hours": "שעות משתנות",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=KIDS%20CAMP%20PLUS%20Ho%20Chi%20Minh%20City",
    "why": "מתחם משחקים מקורה שמתאים ליום גשם או להפוגה של כמה שעות.",
    "reviews": "טוב במיוחד כשמחפשים מקום סגור עם מגוון פעילויות. פחות יעד חובה אם כבר הייתם במשחקיות הגדולות יותר.",
    "icon": "🏕️"
  },
  {
    "name": "OH MY KIDS Premium Kids Cafe",
    "destination": "hcmc",
    "category_he": "בתי קפה לילדים",
    "category": "בתי קפה לילדים",
    "score": 5,
    "tags": [
      "ac",
      "rain"
    ],
    "hours": "שעות משתנות",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=OH%20MY%20KIDS%20Premium%20Kids%20Cafe%20Ho%20Chi%20Minh",
    "why": "קידס קפה איכותי שמשלב ישיבה להורים עם משחקייה לילדים. טוב במיוחד לשהות עירונית של שבוע כשצריך מקום נוח לחזור אליו.",
    "reviews": "מהמקומות החזקים בקטגוריית Kids Cafe. מתאים במיוחד לילדים צעירים ולימים שבהם לא רוצים להסתובב בחוץ.",
    "icon": "☕"
  },
  {
    "name": "Lullaby Premium Kids Cafe",
    "destination": "hcmc",
    "category_he": "בתי קפה לילדים",
    "category": "בתי קפה לילדים",
    "score": 5,
    "tags": [
      "ac",
      "rain"
    ],
    "hours": "שעות משתנות",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Lullaby%20Premium%20Kids%20Cafe%20Ho%20Chi%20Minh",
    "why": "Kids Cafe מושקע ונעים שמתאים במיוחד לילדים קטנים, עם אזורי משחק ומקום נוח להורים.",
    "reviews": "נראה כמו אופציה חזקה ליום גשם או לזמן מנוחה עירוני. כדאי לבדוק שעות ועומסים בסופי שבוע.",
    "icon": "🍼"
  },
  {
    "name": "Kawaii Family & Kids Cafe",
    "destination": "hcmc",
    "category_he": "בתי קפה לילדים",
    "category": "בתי קפה לילדים",
    "score": 4,
    "tags": [
      "ac",
      "rain"
    ],
    "hours": "שעות משתנות",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Kawaii%20Family%20Kids%20Cafe%20Ho%20Chi%20Minh",
    "why": "בית קפה משפחתי עם אזורי משחק, מתאים להפוגה נוחה באמצע יום.",
    "reviews": "פתרון טוב למשפחות עם ילדים קטנים. לא בהכרח יעד מרכזי, אבל שימושי מאוד כשצריך מזגן ומשחק.",
    "icon": "🎀"
  },
  {
    "name": "Penguin Kidsplay & Cafe",
    "destination": "hcmc",
    "category_he": "בתי קפה לילדים",
    "category": "בתי קפה לילדים",
    "score": 4,
    "tags": [
      "ac",
      "rain"
    ],
    "hours": "שעות משתנות",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Penguin%20Kidsplay%20Cafe%20Ho%20Chi%20Minh",
    "why": "משחקייה עם קפה להורים, טובה להפוגה של שעה-שעתיים ביום עירוני.",
    "reviews": "מתאים בעיקר לילדים צעירים. כדאי לבדוק מיקום ביחס לאזור הלינה כדי שלא לנסוע במיוחד רחוק.",
    "icon": "🐧"
  },
  {
    "name": "Meow Meow Kidsplay Cafe",
    "destination": "hcmc",
    "category_he": "בתי קפה לילדים",
    "category": "בתי קפה לילדים",
    "score": 4,
    "tags": [
      "ac",
      "rain"
    ],
    "hours": "שעות משתנות",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Meow%20Meow%20Kidsplay%20Cafe%20Ho%20Chi%20Minh",
    "why": "קידס קפה קטן ונעים, מתאים במיוחד לילדים צעירים ולזמן משחק קצר.",
    "reviews": "טוב כאופציה קרובה וגמישה, פחות כיעד מרכזי של חצי יום.",
    "icon": "🐱"
  },
  {
    "name": "Saigon Zoo & Botanical Gardens",
    "destination": "hcmc",
    "category_he": "טבע וכפרים",
    "category": "טבע וכפרים",
    "score": 5,
    "tags": [
      "calm"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Saigon%20Zoo%20and%20Botanical%20Gardens",
    "why": "גן חיות וגן בוטני במרכז העיר, עם הרבה ירוק ותחושה של הפסקה מהעיר. מתאים מאוד לחצי יום עם ילדים.",
    "reviews": "חוזר בהמלצות למשפחות בגלל השילוב של חיות, פארק ומיקום נוח. כדאי להגיע בבוקר לפני החום והעומס.",
    "icon": "🦁"
  },
  {
    "name": "Mekong Delta Day Tour",
    "destination": "hcmc",
    "category_he": "טבע וכפרים",
    "category": "טבע וכפרים",
    "score": 5,
    "tags": [
      "water",
      "challenging"
    ],
    "hours": "יום מלא",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Mekong%20Delta%20day%20tour%20from%20Ho%20Chi%20Minh%20City",
    "why": "טיול יום קלאסי מחוץ לעיר עם שיט, תעלות, כפרים מקומיים וחוויה שונה לגמרי מהעיר.",
    "reviews": "שווה אם אתם רוצים יום יציאה אמיתי. עם ילד קטן חשוב לבחור סיור לא ארוך מדי, עם רכב נוח וקצב רגוע.",
    "icon": "🛶"
  },
  {
    "name": "Can Gio Monkey Island",
    "destination": "hcmc",
    "category_he": "טבע וכפרים",
    "category": "טבע וכפרים",
    "score": 4,
    "tags": [
      "challenging"
    ],
    "hours": "יום מלא",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Can%20Gio%20Monkey%20Island%20Ho%20Chi%20Minh",
    "why": "טיול טבע מחוץ לעיר עם קופים, מנגרובים ואווירה שונה. מתאים אם רוצים לברוח מהעיר ליום אחד.",
    "reviews": "יכול להיות כיף מאוד, אבל זה יום יותר לוגיסטי וארוך. הקופים עלולים להיות אגרסיביים סביב אוכל, לכן צריך לשמור היטב על הילדים והציוד.",
    "icon": "🐒"
  },
  {
    "name": "Vinhomes Central Park",
    "destination": "hcmc",
    "category_he": "פארקים ואטרקציות",
    "category": "פארקים ואטרקציות",
    "score": 5,
    "tags": [
      "calm"
    ],
    "hours": "כל היום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Vinhomes%20Central%20Park%20Ho%20Chi%20Minh",
    "why": "פארק גדול, ירוק ונוח מאוד למשפחות, עם מדשאות, אזורי משחק, נוף לנהר וקירבה ל-Landmark 81.",
    "reviews": "מקום מעולה ליום רגוע או אחה״צ. לא אטרקציית חובה תיירותית, אבל אחד המקומות הכי שימושיים עם ילדים בעיר.",
    "icon": "🌳"
  },
  {
    "name": "Landmark 81 SkyView",
    "destination": "hcmc",
    "category_he": "פארקים ואטרקציות",
    "category": "פארקים ואטרקציות",
    "score": 4,
    "tags": [
      "ac"
    ],
    "hours": "שעות משתנות",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Landmark%2081%20SkyView",
    "why": "תצפית גבוהה ומרשימה על העיר, טובה לשילוב עם Vinhomes Central Park ו-Vincom Landmark 81.",
    "reviews": "מרשים במיוחד בשקיעה או בערב. לא חובה עם ילדים קטנים, אבל אם אתם באזור זה יכול להיות רגע וואו קצר.",
    "icon": "🏙️"
  },
  {
    "name": "Saigon WaterBus",
    "destination": "hcmc",
    "category_he": "פארקים ואטרקציות",
    "category": "פארקים ואטרקציות",
    "score": 5,
    "tags": [
      "water",
      "calm"
    ],
    "hours": "לפי לוח זמנים",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Saigon%20WaterBus%20Ho%20Chi%20Minh",
    "why": "דרך קלה וכיפית לראות את העיר מהנהר בלי להתחייב לשייט יקר או ארוך.",
    "reviews": "ילדים נהנים מעצם השיט. מומלץ לבדוק לוח זמנים ולהגיע קצת לפני, במיוחד בסופי שבוע.",
    "icon": "⛴️"
  },
  {
    "name": "Suoi Tien Theme Park",
    "destination": "hcmc",
    "category_he": "פארקים ואטרקציות",
    "category": "פארקים ואטרקציות",
    "score": 5,
    "tags": [
      "water"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Suoi%20Tien%20Theme%20Park%20Ho%20Chi%20Minh",
    "why": "פארק שעשועים/מים ענק, צבעוני וייחודי מאוד לוייטנאם. מתאים ליום גדול ומלא עם ילדים.",
    "reviews": "חוויה מאוד מקומית וגדולה. יכול להיות חם ועמוס, לכן כדאי להגיע מוקדם ולבחור מראש אזורים שמתאימים לגילאים.",
    "icon": "🎢"
  },
  {
    "name": "Dam Sen Cultural Park",
    "destination": "hcmc",
    "category_he": "פארקים ואטרקציות",
    "category": "פארקים ואטרקציות",
    "score": 4,
    "tags": [
      "water"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Dam%20Sen%20Cultural%20Park%20Ho%20Chi%20Minh",
    "why": "פארק גדול עם מתקנים, גנים, אגם ואפשרות לשלב גם פארק מים באזור.",
    "reviews": "יותר מקומי ופחות מלוטש מחלק מהאטרקציות החדשות, אבל טוב ליום מלא אם רוצים הרבה פעילות במקום אחד.",
    "icon": "🎡"
  },
  {
    "name": "The Global City",
    "destination": "hcmc",
    "category_he": "פארקים ואטרקציות",
    "category": "פארקים ואטרקציות",
    "score": 5,
    "tags": [
      "calm"
    ],
    "hours": "בעיקר אחה״צ/ערב",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=The%20Global%20City%20Ho%20Chi%20Minh",
    "why": "מתחם מודרני עם תעלות, אזורי הליכה, אירועים, מזרקות ואווירה נעימה למשפחות.",
    "reviews": "טוב במיוחד לאחה״צ או ערב קליל. זה לא פארק שעשועים קלאסי, אלא מתחם נעים להסתובבות עם ילדים.",
    "icon": "🌆"
  },
  {
    "name": "The Global City Playground",
    "destination": "hcmc",
    "category_he": "משחקיות וסדנאות",
    "category": "משחקיות וסדנאות",
    "score": 4,
    "tags": [
      "calm"
    ],
    "hours": "בעיקר אחה״צ/ערב",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=The%20Global%20City%20Playground%20Ho%20Chi%20Minh",
    "why": "אזור משחקים בתוך/ליד מתחם The Global City, טוב לשילוב עם סיבוב במתחם.",
    "reviews": "נחמד כתחנה לילדים, לא יעד בפני עצמו. עובד טוב כשנמצאים באזור או משלבים עם Thiso Mall Sala.",
    "icon": "🛝"
  },
  {
    "name": "Sala Park",
    "destination": "hcmc",
    "category_he": "פארקים ואטרקציות",
    "category": "פארקים ואטרקציות",
    "score": 4,
    "tags": [
      "calm"
    ],
    "hours": "כל היום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Sala%20Park%20Ho%20Chi%20Minh",
    "why": "פארק מטופח ונעים באזור מודרני, מתאים לעצירה קצרה, טיול רגלי או הוצאת אנרגיה לילדים.",
    "reviews": "מקום שימושי יותר מאשר אטרקציה גדולה. טוב במיוחד אם נמצאים באזור Sala / Thiso Mall.",
    "icon": "🌿"
  },
  {
    "name": "Crescent Lake & Starlight Bridge",
    "destination": "hcmc",
    "category_he": "פארקים ואטרקציות",
    "category": "פארקים ואטרקציות",
    "score": 5,
    "tags": [
      "calm"
    ],
    "hours": "אחה״צ/ערב",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Crescent%20Lake%20Starlight%20Bridge%20Ho%20Chi%20Minh",
    "why": "טיילת יפה ונעימה עם אגם, גשר מואר ואווירה טובה לערב רגוע עם ילדים.",
    "reviews": "בחירה מצוינת לערב לא עמוס. הכי מתאים לשלב עם Crescent Mall או ארוחת ערב באזור.",
    "icon": "🌉"
  },
  {
    "name": "Bach Dang Riverside Park",
    "destination": "hcmc",
    "category_he": "פארקים ואטרקציות",
    "category": "פארקים ואטרקציות",
    "score": 4,
    "tags": [
      "calm",
      "water"
    ],
    "hours": "כל היום, עדיף אחה״צ/ערב",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Bach%20Dang%20Riverside%20Park%20Ho%20Chi%20Minh",
    "why": "טיילת נעימה לאורך הנהר עם נוף לסירות ולבניינים הגבוהים. טובה כעצירה קצרה או לפני/אחרי WaterBus.",
    "reviews": "מקום טוב להרגיש את העיר בלי להיכנס למוזיאון או קניון. עדיף בשעות פחות חמות.",
    "icon": "🚤"
  },
  {
    "name": "Cái Tổ Chim",
    "destination": "hcmc",
    "category_he": "בתי קפה ונקודות עצירה",
    "category": "בתי קפה ונקודות עצירה",
    "score": 4,
    "tags": [
      "calm"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Cai%20To%20Chim%20141P%20Vo%20Nguyen%20Giap%20Thu%20Duc",
    "why": "בית קפה-גן גדול עם פרחים, בריכות, מפלים מלאכותיים ופינות צילום. מתאים בדיוק כנוקדת עצירה יפה ולא כאטרקציה של חצי יום.",
    "reviews": "שווה לשלב אם נמצאים באזור Thu Duc. הילדים יכולים להסתובב ולחקור, אבל זה בעיקר מקום יפה לקפה ותמונות.",
    "icon": "🌺"
  },
  {
    "name": "Vườn Thiên Giới",
    "destination": "hcmc",
    "category_he": "בתי קפה ונקודות עצירה",
    "category": "בתי קפה ונקודות עצירה",
    "score": 4,
    "tags": [
      "calm"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Vuon%20Thien%20Gioi%2080%20Street%2036%20Thu%20Duc",
    "why": "בית קפה/גן קונספטואלי עם מערות מלאכותיות, מים וגינות טרופיות. טוב לעצירה קצרה ומיוחדת.",
    "reviews": "מומלץ כתחנה של שעה-שעתיים באזור, לא כיעד מרכזי של יום שלם.",
    "icon": "🌴"
  },
  {
    "name": "Chuyện Của Tùng",
    "destination": "hcmc",
    "category_he": "בתי קפה ונקודות עצירה",
    "category": "בתי קפה ונקודות עצירה",
    "score": 3,
    "tags": [
      "calm"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Chuyen%20Cua%20Tung%2082%20Street%2036%20Thu%20Duc",
    "why": "בית קפה בגינה בסגנון כפרי, מתאים לעצירה רגועה להורים יותר מאשר אטרקציית ילדים.",
    "reviews": "נחמד אם אתם באזור בתי הקפה הקונספטואליים. פחות הייתי נוסע במיוחד רק בשבילו.",
    "icon": "🏡"
  },
  {
    "name": "Nhà Có Một Vườn Hoa",
    "destination": "hcmc",
    "category_he": "בתי קפה ונקודות עצירה",
    "category": "בתי קפה ונקודות עצירה",
    "score": 4,
    "tags": [
      "calm"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Nha%20Co%20Mot%20Vuon%20Hoa%20141P%20Vo%20Nguyen%20Giap%20Thu%20Duc",
    "why": "בית קפה עם גני פרחים ועיצוב עונתי, מתאים לעצירה קצרה יפה בין אטרקציות באזור.",
    "reviews": "הערך הוא בעיקר ויזואלי ואווירה. טוב לשעה רגועה, לא ליום שלם.",
    "icon": "🌸"
  },
  {
    "name": "Blank Lounge – Landmark 81",
    "destination": "hcmc",
    "category_he": "בתי קפה ונקודות עצירה",
    "category": "בתי קפה ונקודות עצירה",
    "score": 4,
    "tags": [
      "ac",
      "calm"
    ],
    "hours": "שעות משתנות",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Blank%20Lounge%20Landmark%2081",
    "why": "נקודת עצירה גבוהה ומרשימה בתוך Landmark 81, טובה לקפה/קינוח עם נוף.",
    "reviews": "מתאים יותר להורים ולילדים שיודעים לשבת קצת. טוב לשילוב עם הפארק והקניון, לא כיעד עצמאי לילדים.",
    "icon": "☕"
  },
  {
    "name": "Independence Palace",
    "destination": "hcmc",
    "category_he": "תרבות ועיר",
    "category": "תרבות ועיר",
    "score": 4,
    "tags": [
      "calm"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Independence%20Palace%20Ho%20Chi%20Minh",
    "why": "אתר היסטורי מרכזי שאפשר לבקר בו יחסית קצר, עם אולמות, חצרות ומרחבים גדולים.",
    "reviews": "יותר נגיש לילדים ממוזיאון כבד, אבל עדיין לא אטרקציית ילדים. טוב אם רוצים להכניס קצת היסטוריה בלי להעמיס.",
    "icon": "🏛️"
  },
  {
    "name": "Vietnam History Museum",
    "destination": "hcmc",
    "category_he": "תרבות ועיר",
    "category": "תרבות ועיר",
    "score": 3,
    "tags": [
      "ac",
      "rain"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Vietnam%20History%20Museum%20Ho%20Chi%20Minh",
    "why": "מוזיאון קטן יחסית שיכול להתאים ליום גשם או לשילוב עם גן החיות הסמוך.",
    "reviews": "לא חובה עם ילדים קטנים, אבל אם נמצאים ליד Saigon Zoo אפשר לשלב ביקור קצר.",
    "icon": "🏺"
  },
  {
    "name": "Ao Dai Museum",
    "destination": "hcmc",
    "category_he": "תרבות ועיר",
    "category": "תרבות ועיר",
    "score": 4,
    "tags": [
      "calm"
    ],
    "hours": "שעות יום",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Ao%20Dai%20Museum%20Ho%20Chi%20Minh",
    "why": "מוזיאון ייחודי לבגד הלאומי הווייטנאמי, במתחם יפה ורגוע יותר ממוזיאון עירוני כבד.",
    "reviews": "מתאים אם אתם רוצים חוויה תרבותית שונה ועדינה. פחות מרכזי, ולכן כדאי לשלב עם משהו באזור ולא לנסוע במיוחד ביום קצר.",
    "icon": "👘"
  },
  {
    "name": "Cu Chi Tunnels",
    "destination": "hcmc",
    "category_he": "תרבות ועיר",
    "category": "תרבות ועיר",
    "score": 4,
    "tags": [
      "challenging"
    ],
    "hours": "חצי יום / יום מלא",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Cu%20Chi%20Tunnels",
    "why": "אתר היסטורי מפורסם מאוד מחוץ לעיר. חשוב להכניס לאתר כי הוא יעד קלאסי, אבל הוא לא בהכרח מתאים לכל ילד.",
    "reviews": "מעניין למבוגרים ולילדים גדולים, אבל עלול להיות קשה, חם ופחות מתאים לילדים רגישים או קטנים. לבחור רק אם זה חשוב לכם.",
    "icon": "🕳️"
  },
  {
    "name": "Nguyen Hue Walking Street",
    "destination": "hcmc",
    "category_he": "עיר וערב",
    "category": "עיר וערב",
    "score": 5,
    "tags": [
      "calm"
    ],
    "hours": "אחה״צ/ערב",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Nguyen%20Hue%20Walking%20Street%20Ho%20Chi%20Minh",
    "why": "מדרחוב מרכזי, רחב ונוח לשיטוט ערב עם ילדים, אורות, גלידה ואווירה עירונית.",
    "reviews": "אחד המקומות הכי פשוטים ונוחים לערב קצר. בסופי שבוע יכול להיות עמוס אבל עדיין נעים.",
    "icon": "🚶"
  },
  {
    "name": "Ben Thanh Market",
    "destination": "hcmc",
    "category_he": "עיר וערב",
    "category": "עיר וערב",
    "score": 4,
    "tags": [
      "shopping"
    ],
    "hours": "שעות יום וערב בסביבה",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Ben%20Thanh%20Market%20Ho%20Chi%20Minh",
    "why": "שוק מרכזי, צבעוני ותיירותי. טוב לסיבוב קצר, טעימות וקניות קטנות.",
    "reviews": "יכול להיות עמוס ולחוץ עם ילדים, לכן עדיף להגיע לזמן קצר ובשעה נוחה.",
    "icon": "🛍️"
  },
  {
    "name": "Takashimaya Food Hall",
    "destination": "hcmc",
    "category_he": "עיר וערב",
    "category": "עיר וערב",
    "score": 4,
    "tags": [
      "ac",
      "mall"
    ],
    "hours": "לפי שעות הקניון",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Takashimaya%20Ho%20Chi%20Minh%20Food%20Hall",
    "why": "אופציית אוכל וקניון נוחה מאוד במרכז העיר, עם מיזוג, שירותים ומבחר גדול.",
    "reviews": "לא אטרקציה, אבל נקודת עצירה מאוד פרקטית עם ילדים באמצע יום עירוני.",
    "icon": "🍱"
  },
  {
    "name": "Vincom Landmark 81",
    "destination": "hcmc",
    "category_he": "עיר וערב",
    "category": "עיר וערב",
    "score": 4,
    "tags": [
      "ac",
      "mall"
    ],
    "hours": "לפי שעות הקניון",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Vincom%20Landmark%2081%20Ho%20Chi%20Minh",
    "why": "קניון נוח וממוזג מתחת ל-Landmark 81, טוב לשילוב עם הפארק והתצפית.",
    "reviews": "מקום פרקטי מאוד למשפחה: אוכל, שירותים, חנויות ומזגן. לא יעד בפני עצמו לכל היום.",
    "icon": "🏬"
  },
  {
    "name": "Thiso Mall Sala",
    "destination": "hcmc",
    "category_he": "עיר וערב",
    "category": "עיר וערב",
    "score": 5,
    "tags": [
      "ac",
      "mall"
    ],
    "hours": "לפי שעות הקניון",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Thiso%20Mall%20Sala%20Ho%20Chi%20Minh",
    "why": "קניון מודרני ונוח במיוחד למשפחות באזור Sala, עם משחקיות ואוכל.",
    "reviews": "אחת הנקודות הכי שימושיות למשפחה בעיר כי אפשר לשלב משחקייה, אוכל ומזגן במקום אחד.",
    "icon": "🏬"
  },
  {
    "name": "Crescent Mall",
    "destination": "hcmc",
    "category_he": "עיר וערב",
    "category": "עיר וערב",
    "score": 4,
    "tags": [
      "ac",
      "mall"
    ],
    "hours": "לפי שעות הקניון",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Crescent%20Mall%20Ho%20Chi%20Minh",
    "why": "קניון נוח לשילוב עם Crescent Lake ו-Starlight Bridge, טוב לאוכל ומיזוג.",
    "reviews": "מקום פרקטי מאוד ליום רגוע באזור District 7. לא חובה אם לא נמצאים באזור.",
    "icon": "🏬"
  },
  {
    "name": "Beehive Premium Kids Cafe",
    "destination": "hcmc",
    "category_he": "בתי קפה לילדים",
    "category": "בתי קפה לילדים",
    "score": 5,
    "tags": [
      "ac",
      "rain"
    ],
    "hours": "שעות משתנות, מומלץ לבדוק לפני הגעה",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Beehive%20Premium%20Kids%20Cafe%20Ho%20Chi%20Minh",
    "why": "Kids Cafe מושקע במיוחד עם אזורי משחק איכותיים לילדים וישיבה נוחה להורים. מתאים מאוד ליום חם או גשום, או כשצריך פעילות רגועה ולא עוד קניון.",
    "reviews": "נראה כאחת האפשרויות החזקות בקטגוריית בתי הקפה לילדים בעיר, ולכן עדיף להשאיר אותו במקום המלצות כלליות או מקומות פחות עדכניים.",
    "icon": "🐝"
  },
{
    "name": "בסיס דאלי",
    "destination": "dali",
    "category_he": "בסיס",
    "category": "בסיס",
    "score": null,
    "tags": [],
    "hours": "",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Manjiang+Dali+Yunnan",
    "why": "",
    "reviews": "",
    "icon": "🏠"
  },
  {
    "name": "赖克宝儿童主题乐园 – Raikebao Children’s Theme Park",
    "destination": "dali",
    "category_he": "משחקיות וסדנאות",
    "category": "משחקיות וסדנאות",
    "score": 4,
    "tags": [
      "ac"
    ],
    "hours": "לבדיקה",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=%E8%B5%96%E5%85%8B%E5%AE%9D%E5%84%BF%E7%AB%A5%E4%B8%BB%E9%A2%98%E4%B9%90%E5%9B%AD+%E5%A4%A7%E7%90%86",
    "why": "משחקייה מקורה באזור 满江, קרובה מאוד לבסיס. פתרון שימושי במיוחד לשעה–שעתיים ביום גשום או כשלא רוצים להפוך כל יציאה לטיול.",
    "reviews": "נמצא מידע עקבי על קיומה ומיקומה, אבל המידע המקוון על שעות, מחיר ורמת התחזוקה מוגבל; מומלץ לבדוק באפליקציה מקומית לפני הגעה.",
    "icon": "🛝",
    "distance_min": "כ־0–5 דק׳"
  },
  {
    "name": "洱海公园 – Erhai Park",
    "destination": "dali",
    "category_he": "פארקים",
    "category": "פארקים",
    "score": 4,
    "tags": [
      "calm"
    ],
    "hours": "לבדיקה",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Erhai+Park+Dali",
    "why": "פארק גדול ונגיש יחסית ב-Xiaguan, טוב לטיול קצר, מרחב פתוח ונוף לאגם. בתוך אזור הפארק מופיעים גם מתקני שעשועים לילדים.",
    "reviews": "אופציה טובה לשגרת יום רגילה עם ילדים; פחות מתאימה כפתרון לגשם חזק.",
    "icon": "🌳",
    "distance_min": "כ־5–10 דק׳"
  },
  {
    "name": "洱海公园游乐区 – Erhai Park Amusement Area",
    "destination": "dali",
    "category_he": "גני שעשועים",
    "category": "גני שעשועים",
    "score": 4,
    "tags": [],
    "hours": "לבדיקה",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=%E6%B4%B1%E6%B5%B7%E5%85%AC%E5%9B%AD%E6%B8%B8%E4%B9%90%E5%8C%BA+%E5%A4%A7%E7%90%86",
    "why": "אזור מתקנים בתוך Erhai Park, שימושי במיוחד כשרוצים פעילות פשוטה לילדים בלי נסיעה ארוכה.",
    "reviews": "המידע באנגלית דל יחסית ולכן כדאי לבדוק במקום אילו מתקנים פעילים ובאילו שעות.",
    "icon": "🎠",
    "distance_min": "כ־5–10 דק׳"
  },
  {
    "name": "洱海玉白菜湿地公园 – Jade Cabbage Wetland Park",
    "destination": "dali",
    "category_he": "פארקים",
    "category": "פארקים",
    "score": 4,
    "tags": [
      "calm"
    ],
    "hours": "לבדיקה",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=%E6%B4%B1%E6%B5%B7%E7%8E%89%E7%99%BD%E8%8F%9C%E6%B9%BF%E5%9C%B0%E5%85%AC%E5%9B%AD+%E5%A4%A7%E7%90%86",
    "why": "פארק ביצות וטבע קרוב מאוד לאזור 满江. מתאים ליציאה קצרה, הליכה ואוויר פתוח בלי לנסוע לאטרקציה גדולה.",
    "reviews": "לא גן שעשועים, אלא מקום שימושי לשגרת שבועיים ולזמן רגוע בחוץ.",
    "icon": "🌿",
    "distance_min": "כ־0–5 דק׳"
  },
  {
    "name": "大理爱琴海购物公园 – Dali Aegean Shopping Park",
    "destination": "dali",
    "category_he": "קניות",
    "category": "קניות",
    "score": 4,
    "tags": [
      "ac",
      "mall"
    ],
    "hours": "לבדיקה",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=%E5%A4%A7%E7%90%86%E7%88%B1%E7%90%B4%E6%B5%B7%E8%B4%AD%E7%89%A9%E5%85%AC%E5%9B%AD",
    "why": "קניון גדול ב-Xiaguan עם אוכל, קניות ופעילויות משפחתיות. לפי פרסומי הקבוצה יש בו גם מתחם ילדים, ולכן הוא שימושי במיוחד ביום גשום.",
    "reviews": "בחירה פרקטית ליום שבו צריך מזגן וגמישות; מומלץ לבדוק באותו יום אילו מתחמי ילדים פעילים.",
    "icon": "🏬",
    "distance_min": "כ־10–15 דק׳"
  },
  {
    "name": "Kaka Children’s Paradise",
    "destination": "dali",
    "category_he": "משחקיות וסדנאות",
    "category": "משחקיות וסדנאות",
    "score": "check",
    "tags": [
      "ac"
    ],
    "hours": "לבדיקה",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Kaka+Children%27s+Paradise+Dali+Wenhua+Road",
    "why": "מתחם ילדים נוסף באזור העיר החדשה/Xiaguan שיכול להרחיב את אפשרויות המשחק המקורות.",
    "reviews": "המידע המקוון עליו מוגבל משמעותית, ולכן הוא נשאר באתר כאופציה לבדיקה ולא כהמלצה חזקה.",
    "icon": "🎈",
    "distance_min": "כ־15–20 דק׳"
  },
  {
    "name": "大理古城 – Dali Ancient City",
    "destination": "dali",
    "category_he": "עיר עתיקה ושווקים",
    "category": "עיר עתיקה ושווקים",
    "score": 5,
    "tags": [],
    "hours": "לבדיקה",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Dali+Ancient+City",
    "why": "אחד המקומות המרכזיים בדאלי: רחובות עתיקים, אוכל, חנויות ואווירה. מתאים למשפחה כשמגיעים בשעות נעימות ולא מנסים להספיק הכול.",
    "reviews": "יעד קלאסי וחזק לביקור בדאלי; עם ילדים עדיף לבנות ביקור קצר וגמיש.",
    "icon": "🏮",
    "distance_min": "כ־25–35 דק׳"
  },
  {
    "name": "才村码头 – Caicun Wharf",
    "destination": "dali",
    "category_he": "אגם וטיילות",
    "category": "אגם וטיילות",
    "score": 4,
    "tags": [
      "water",
      "calm"
    ],
    "hours": "לבדיקה",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Caicun+Wharf+Dali",
    "why": "אזור נעים ליד Erhai שמתאים להליכה, נוף ועצירה רגועה ליד האגם, ואפשר לשלב עם העיר העתיקה.",
    "reviews": "מתאים יותר כחצי יום רגוע מאשר כאטרקציה בפני עצמה.",
    "icon": "🌊",
    "distance_min": "כ־25–35 דק׳"
  },
  {
    "name": "喜洲古镇 – Xizhou Ancient Town",
    "destination": "dali",
    "category_he": "עיר עתיקה ושווקים",
    "category": "עיר עתיקה ושווקים",
    "score": 5,
    "tags": [],
    "hours": "לבדיקה",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Xizhou+Ancient+Town+Dali",
    "why": "עיירה היסטורית מצפון לדאלי עם אדריכלות Bai, רחובות נעימים ואוכל מקומי. טובה ליום טיול משפחתי בקצב רגוע.",
    "reviews": "אחת העצירות המומלצות באזור Erhai; עדיף להגיע מוקדם ולשלב עם יעד אחד נוסף בלבד.",
    "icon": "🏘️",
    "distance_min": "כ־40–50 דק׳"
  },
  {
    "name": "双廊古镇 – Shuanglang Ancient Town",
    "destination": "dali",
    "category_he": "אגם וטיילות",
    "category": "אגם וטיילות",
    "score": 5,
    "tags": [
      "water"
    ],
    "hours": "לבדיקה",
    "phone": "",
    "link": "https://www.google.com/maps/search/?api=1&query=Shuanglang+Ancient+Town+Dali",
    "why": "עיירה על שפת Erhai עם נוף יפה מאוד לאגם. מתאימה ליום טיול מלא יותר מחוץ לבסיס.",
    "reviews": "יפה במיוחד, אבל הנסיעה ארוכה יותר ולכן עדיף להקדיש לה יום ולא לשלב יותר מדי תחנות.",
    "icon": "⛰️",
    "distance_min": "כ־60–75 דק׳"
  }
];

(function(){
  const raw = (window.ATTRACTIONS || []).slice();

  const TAG_LABELS = {
    ac: "ממוזג",
    water: "מים",
    supermarket: "סופרים",
    mall: "קניון",
    shopping: "קניות",
    calm: "רגוע",
    challenging: "אתגרי"
}
  ;

  const TAG_ORDER = ["ac","water","calm","challenging"];

  const elSearch = document.getElementById("search");
  const elCategory = document.getElementById("category");
  const elMinScore = document.getElementById("minScore");
  const elSortBy = document.getElementById("sortBy");
  const elTags = document.getElementById("tags");
  const elDestination = document.getElementById("destination");
  const elCards = document.getElementById("cards");
  const elCount = document.getElementById("count");
  const elReset = document.getElementById("resetBtn");

  const elMap = document.getElementById("map");
  const elOpenMaps = document.getElementById("openMaps");

  const elMode = document.getElementById("mode");
  const elBuild = document.getElementById("buildBtn");

  const elModal = document.getElementById("modal");
  const elModalOverlay = document.getElementById("modalOverlay");
  const elCloseModal = document.getElementById("closeModal");
  const elModalTitle = document.getElementById("modalTitle");
  const elModalGrid = document.getElementById("modalGrid");

  // How-to modal
  const elHowToBtn = document.getElementById("openHowTo");
  const elHowTo = document.getElementById("howtoModal");
  const elHowToOverlay = document.getElementById("howtoOverlay");
  const elCloseHowTo = document.getElementById("closeHowTo");


  function isBase(item){
    return (item.category_he || item.category) === "בסיס" || (item.category === "Base") || /base/i.test(item.name);
  }

  function parseMin(distanceText){
    if(!distanceText) return null;
    const t = String(distanceText);
    // Handles: "10–15 דק׳" or "55–65 דקות" or "15 דק׳"
    let m = t.match(/(\d+)\s*[–-]\s*(\d+)/);
    if(m) return parseInt(m[1], 10);
    m = t.match(/(\d+)/);
    if(m) return parseInt(m[1], 10);
    return null;
  }

  function stars(score){
    if(score === "check") return `<span class="checkBadge"><span class="checkIcon">?</span><span class="checkText">(לבדיקה)</span></span>`;
    if(score == null) return "";
    const n = Number(score);
    if(Number.isNaN(n)) return "";
    const s = Math.max(0, Math.min(5, n));
    return "★".repeat(s) + "☆".repeat(5 - s);
  }

  function unique(arr){
    return Array.from(new Set(arr));
  }

  // Category dropdown (destination-aware)
  function populateCategories(dest){
    const cats = unique(raw.filter(x=>!isBase(x)).filter(x=>(x.destination||'koh_samui')===dest).map(x => x.category_he || x.category)).sort((a,b)=>a.localeCompare(b,'he'));
    elCategory.innerHTML = `<option value="">כל הקטגוריות</option>` + cats.map(c=>`<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`).join("");
  }

  let currentDestination = "koh_samui";
  if(elDestination && elDestination.value) currentDestination = elDestination.value;

  // Tag checkboxes (locked to approved Hebrew tags only)
  const tagsToShow = TAG_ORDER.slice();

  elTags.innerHTML = tagsToShow.map(tagKey => {
    const label = TAG_LABELS[tagKey] || tagKey;
    return `<label class="tag"><input type="checkbox" value="${escapeHtml(tagKey)}"> ${escapeHtml(label)}</label>`;
  }).join("");

  const tagInputs = Array.from(elTags.querySelectorAll('input[type="checkbox"]'));

  const DEST_DEFAULT_MAP = {
    koh_samui: "https://www.google.com/maps?q=The%20Gardens%20by%20Samui%20Beach%20Properties%20Bang%20Rak&output=embed",
    bangkok: "https://www.google.com/maps?q=Gate43%20Airport%20Hotel%20Bangkok&output=embed",
    krabi: "https://www.google.com/maps?q=Ao%20Nang%20Krabi&output=embed",
    hoi_an: "https://www.google.com/maps?q=Hoi%20An%20Vietnam&output=embed",
    da_nang: "https://www.google.com/maps?q=Chi%20House%20Danang&output=embed",
    dalat: "https://www.google.com/maps?q=Dalat%20Vietnam&output=embed",
    hcmc: "https://www.google.com/maps?q=Ho%20Chi%20Minh%20City%20Vietnam&output=embed",
    dali: "https://www.google.com/maps?q=Manjiang%20Dali%20Yunnan&output=embed"
  };

  const DEST_TITLES = {
    koh_samui: "קוסמוי – אטרקציות למשפחה",
    bangkok: "בנגקוק – אטרקציות למשפחה",
    krabi: "קראבי – אטרקציות למשפחה",
    hoi_an: "הוי אן – אטרקציות למשפחה",
    da_nang: "דה נאנג – אטרקציות למשפחה",
    dalat: "דאלאת – אטרקציות למשפחה",
    hcmc: "הו צ׳י מין – אטרקציות למשפחה",
    dali: "דאלי – אטרקציות למשפחה"
  };

  populateCategories(currentDestination);
  updateHeaderTitle();

  function updateHeaderTitle(){
    const h1 = document.querySelector('.topbar h1');
    if(h1) h1.textContent = DEST_TITLES[currentDestination] || DEST_TITLES.koh_samui;
    document.title = DEST_TITLES[currentDestination] || DEST_TITLES.koh_samui;
  }


  function escapeHtml(s){
    return String(s)
      .replace(/&/g,"&amp;")
      .replace(/</g,"&lt;")
      .replace(/>/g,"&gt;")
      .replace(/"/g,"&quot;")
      .replace(/'/g,"&#039;");
  }

  function buildMapEmbed(linkOrName){
    const base = "https://www.google.com/maps";
    if(linkOrName && String(linkOrName).includes("google.com/maps")){
      // Use embed based on query param if possible
      const url = new URL(linkOrName);
      const q = url.searchParams.get("q");
      if(q){
        return `${base}?q=${encodeURIComponent(q)}&output=embed`;
      }
    }
    const q = linkOrName || "Koh Samui";
    return `${base}?q=${encodeURIComponent(q)}&output=embed`;
  }

  function openMapHref(linkOrName){
    if(linkOrName && String(linkOrName).includes("google.com/maps")) return linkOrName;
    return `https://www.google.com/maps?q=${encodeURIComponent(linkOrName || "Koh Samui")}`;
  }

  function buildPlanRouteHref(plan){
    const names = (plan.places || []).filter(Boolean);
    if(!names.length) return openMapHref();
    if(names.length === 1) return openMapHref(names[0]);
    const origin = names[0];
    const destination = names[names.length - 1];
    const waypoints = names.slice(1, -1);
    const params = new URLSearchParams({
      api: '1',
      origin,
      destination,
      travelmode: 'driving'
    });
    if(waypoints.length) params.set('waypoints', waypoints.join('|'));
    return `https://www.google.com/maps/dir/?${params.toString()}`;
  }

  function buildPlanMapEmbed(plan){
    const names = (plan.places || []).filter(Boolean);
    if(!names.length) return DEST_DEFAULT_MAP[currentDestination] || DEST_DEFAULT_MAP.koh_samui;
    if(names.length === 1) return buildMapEmbed(names[0]);
    const origin = names[0];
    const destination = names[names.length - 1];
    const waypoints = names.slice(1, -1);
    const params = new URLSearchParams({
      api: '1',
      origin,
      destination,
      travelmode: 'driving',
      output: 'embed'
    });
    if(waypoints.length) params.set('waypoints', waypoints.join('|'));
    return `https://www.google.com/maps/dir/?${params.toString()}`;
  }

  function setPlanMap(plan){
    elMap.src = buildPlanMapEmbed(plan);
    elOpenMaps.href = buildPlanRouteHref(plan);
  }

  function setDefaultMap(){
    elMap.src = DEST_DEFAULT_MAP[currentDestination] || DEST_DEFAULT_MAP.koh_samui;
  }

  function setMap(item){
    const q = item.link && item.link.includes("google.com/maps") ? item.link : item.name;
    elMap.src = buildMapEmbed(q);
    elOpenMaps.href = openMapHref(q);
  }

  function matchesSearch(item, q){
    if(!q) return true;
    const hay = [
      item.name, item.category_he, item.why, item.reviews, item.how_to_get || "", item.price || "",
      (item.includes_lines||[]).join(" "), (item.tips_lines||[]).join(" "),
      (item.tags||[]).map(t => TAG_LABELS[t] || t).join(" ")
    ].join(" ").toLowerCase();
    return hay.includes(q.toLowerCase());
  }

  function matchesTags(item, selectedTags){
    if(selectedTags.length === 0) return true;
    const tags = item.tags || [];
    return selectedTags.every(t => tags.includes(t));
  }

  function sortItems(items){
    const mode = elSortBy.value;
    const copy = items.slice();
    if(mode === "distance_asc"){
      copy.sort((a,b)=> (parseMin(a.distance_min)??9999) - (parseMin(b.distance_min)??9999));
      return copy;
    }
    if(mode === "name_asc"){
      copy.sort((a,b)=> String(a.name).localeCompare(String(b.name), 'he'));
      return copy;
    }
    // score desc
    copy.sort((a,b)=> (Number(b.score)||0) - (Number(a.score)||0));
    return copy;
  }

  function render(){
    const q = elSearch.value.trim();
    const cat = elCategory.value;
    const minScore = Number(elMinScore.value || 0);
    const selectedTags = tagInputs.filter(i=>i.checked).map(i=>i.value);

    let items = raw.filter(x => !isBase(x));

    // destination filter
    items = items.filter(x => (x.destination || 'koh_samui') === currentDestination);

    items = items.filter(x => matchesSearch(x, q));
    if(cat) items = items.filter(x => (x.category_he || x.category) === cat);
    if(minScore > 0) items = items.filter(x => (Number(x.score)||0) >= minScore);
    items = items.filter(x => matchesTags(x, selectedTags));

    items = sortItems(items);

    elCount.textContent = `${items.length} תוצאות`;

    elCards.innerHTML = items.map((x, idx) => cardHtml(x, idx)).join("");

    // attach listeners
    Array.from(document.querySelectorAll("[data-action='focus']")).forEach(btn=>{
      btn.addEventListener("click", (e)=>{
        e.preventDefault();
        const id = btn.getAttribute("data-id");
        const item = items.find(i => i._id === id);
        if(item) setMap(item);
      });
    });

    Array.from(document.querySelectorAll(".card")).forEach(card=>{
      card.addEventListener("click", (e)=>{
        // ignore clicks on buttons/links
        const tag = (e.target && e.target.tagName) ? e.target.tagName.toLowerCase() : "";
        if(tag === "a" || tag === "button" || tag === "input") return;
        const id = card.getAttribute("data-id");
        const item = items.find(i => i._id === id);
        if(item) setMap(item);
      });
      card.addEventListener("keydown", (e)=>{
        if(e.key === "Enter"){
          const id = card.getAttribute("data-id");
          const item = items.find(i => i._id === id);
          if(item) setMap(item);
        }
      });
    });

    Array.from(document.querySelectorAll("[data-action='gallery']")).forEach(btn=>{
      btn.addEventListener("click", (e)=>{
        e.preventDefault();
        e.stopPropagation();
        const id = btn.getAttribute("data-id");
        const item = items.find(i => i._id === id);
        if(item) openGallery(item);
      });
    });

    Array.from(document.querySelectorAll("[data-action='openLink']")).forEach(a=>{
      a.addEventListener("click", (e)=>{ e.stopPropagation(); });
    });
  }

  function cardHtml(item, idx){
    // stable id (avoid recompute)
    const id = item._id;
    const cat = item.category_he || item.category;
    const icon = item.icon || "✨";
    const dist = item.distance_min || "";
    const score = item.score;
    const starsText = stars(score);
    const metaParts = [];
    if(item.cuisine) metaParts.push(`מטבח: ${escapeHtml(item.cuisine)}`);
    if(item.price) metaParts.push(`מחיר: ${escapeHtml(item.price)}`);
    const metaLine = metaParts.length ? `<div class="line"><div class="k">פרטים</div><div class="v">${metaParts.join(" · ")}</div></div>` : "";
    const metaText = "";

    const hoursLine = item.hours ? `<div class="line"><div class="k">שעות</div><div class="v">${item.hours === 'לבדיקה' ? '<span class="checkBadge">❓</span> לבדיקה' : escapeHtml(item.hours)}</div></div>` : ``;
    let phoneLine = ``;
    if(item.phone){
      if(item.phone === "לבדיקה"){
        phoneLine = `<div class="line"><div class="k">טלפון</div><div class="v"><span class="qmark">❓</span> לבדיקה</div></div>`;
      } else {
        const ph = escapeHtml(item.phone);
        phoneLine = `<div class="line"><div class="k">טלפון</div><div class="v"><a class="tel" href="tel:${ph}">${ph}</a></div></div>`;
      }
    }

    const dayPassBlock = (item.day_pass_lines && item.day_pass_lines.length)
      ? `<div class="line"><div class="k">Day Pass</div><div class="v"><ul class="bullets">${item.day_pass_lines.map(l => `<li>${escapeHtml(l)}</li>`).join("")}</ul></div></div>`
      : ``;

    const howToBlock = item.how_to_get
      ? `<div class="line"><div class="k">איך מגיעים</div><div class="v">${escapeHtml(item.how_to_get)}</div></div>`
      : ``;

    const includesBlock = (item.includes_lines && item.includes_lines.length)
      ? `<div class="line"><div class="k">מה כולל</div><div class="v"><ul class="bullets">${item.includes_lines.map(l => `<li>${escapeHtml(l)}</li>`).join("")}</ul></div></div>`
      : ``;

    const tipsBlock = (item.tips_lines && item.tips_lines.length)
      ? `<div class="line"><div class="k">טיפים</div><div class="v"><ul class="bullets">${item.tips_lines.map(l => `<li>${escapeHtml(l)}</li>`).join("")}</ul></div></div>`
      : ``;

    const mainImg = (item.images && item.images[0]) ? item.images[0] : "";
    const rawTags = (item.tags || []);
    const tags = rawTags.filter(t => TAG_LABELS[t]).map(t => TAG_LABELS[t]);

    const tagsForChips = rawTags.filter(t => TAG_LABELS[t] && ![].includes(t)).map(t => TAG_LABELS[t]);

    const tagChips = tagsForChips.slice(0, 5).map(t => `<span class="badge tag"><span class="emoji">🏷️</span>${escapeHtml(t)}</span>`).join("");

    return `
      <article class="card" tabindex="0" data-id="${escapeHtml(id)}" aria-label="${escapeHtml(item.name)}">
        <div class="cardTop">
          <div class="cardMain">
            <div class="cardTitleRow">
              <h3 class="cardTitle">${escapeHtml(icon)} ${escapeHtml(item.name)}</h3>
              ${score ? `<div class="stars" title="ציון">${starsText}</div>` : ``}
            </div>

            <div class="badges">
              <span class="badge"><span class="emoji">📌</span>${escapeHtml(cat)}</span>
              ${dist ? `<span class="badge"><span class="emoji">🚗</span>${escapeHtml(dist)}</span>` : ``}
              ${tagChips}
            </div>
          </div>
        </div>

        <div class="cardBody">
          ${hoursLine}
          ${phoneLine}
          ${metaLine}
          ${dayPassBlock}
          ${howToBlock}
          ${includesBlock}
          <div class="line"><div class="k">למה שווה</div><div class="v">${escapeHtml(item.why || "")}</div></div>
          <div class="line"><div class="k">תמצית ביקורות</div><div class="v">${escapeHtml(item.reviews || "")}</div></div>
          ${tipsBlock}
        </div>

        <div class="cardLinks">
          <a class="linkBtn" data-action="openLink" target="_blank" rel="noopener" href="${escapeHtml(item.link || "#")}">קישור להתרשמות</a>
          <a class="linkBtn" data-action="openLink" target="_blank" rel="noopener" href="${escapeHtml(openMapHref(item.link && item.link.includes('google.com/maps') ? item.link : item.name))}">פתחי מפה</a>
          <button class="linkBtn" data-action="focus" data-id="${escapeHtml(id)}" type="button">מקד במפה</button>
        </div>
      </article>
    `;
  }

  function openGallery(item){
    const imgs = (item.images || []).slice(0, 4);
    elModalTitle.textContent = `תמונות – ${item.name}`;
    elModalGrid.innerHTML = imgs.map(src => `<img loading="lazy" alt="" src="${escapeHtml(src)}">`).join("");
    elModal.setAttribute("aria-hidden", "false");
    document.body.style.overflow = "hidden";
  }

  function closeGallery(){
    elModal.setAttribute("aria-hidden", "true");
    document.body.style.overflow = "";
  }

  function openHowTo(){
    if(!elHowTo) return;
    elHowTo.setAttribute("aria-hidden","false");
    elHowTo.style.display = "block";
    document.body.style.overflow = "hidden";
  }

  function closeHowTo(){
    if(!elHowTo) return;
    elHowTo.setAttribute("aria-hidden","true");
    elHowTo.style.display = "none";
    document.body.style.overflow = "";
  }

  function resetAll(){
    const dest = (elDestination && elDestination.value) || currentDestination || "koh_samui";
    elSearch.value = "";
    elCategory.value = "";
    elMinScore.value = "0";
    elSortBy.value = "score_desc";
    tagInputs.forEach(i => i.checked = false);
    if(elDestination) elDestination.value = dest;
    currentDestination = dest;
    render();
  }

    function buildDay(){
    const mode = elMode.value;

    // Destination-aware pool
    const poolAll = raw.filter(x => !isBase(x) && (x.destination || "koh_samui") === currentDestination);

    const isRestaurant = (it) => (it.category_he === "מסעדות" || it.category_he === "מסעדות חוף");
    const isAttraction = (it) => !isRestaurant(it);

    const krabiPlans = [
      {
        title: "יום רגוע ונוח – Ao Nang",
        short_description: "חוף, משחקיה ואוכל טוב בלי נסיעות מיותרות.",
        vibe: "רגוע · קליל · מתאים ליום חם",
        why: "זה יום שקל לזרום איתו. יש בו מעט מעברים, אופציה למקום ממוזג באמצע, ואפשר לקצר או לעצור בכל שלב בלי להרגיש שפספסתם משהו.",
        stops: [
          {label:"בוקר", name:"Noppharat Thara Beach", note:"חוף רחב עם יותר צל ומרחב לריצה."},
          {label:"צהריים", name:"The Fun Garden", note:"משחקיה והתרעננות בשעות החמות."},
          {label:"סיום", name:"Ao Nang Landmark Night Market", note:"אוכל קליל או סיבוב קצר אם נשאר כוח."}
        ],
        tips: ["להתחיל מוקדם בחוף", "להשאיר את המשחקיה לשעות החמות", "לעצור לארוחה פשוטה ולא למשוך יותר מדי את היום"],
        places: ["Noppharat Thara Beach", "The Fun Garden", "Ao Nang Landmark Night Market"]
      },
      {
        title: "יום שייט רגוע – Hong Islands",
        short_description: "לגונה טורקיז, מים שקטים ותחושת יום מיוחד בלי עומס מיותר.",
        vibe: "מים · חוויה · רגוע יחסית",
        why: "מבין השייטים באזור זה אחד היותר נעים למשפחות. הוא מרגיש מיוחד, אבל לא תזזיתי מדי, ומתאים יותר מ־4 Islands כשמחפשים יום זורם עם ילדים.",
        stops: [
          {label:"יציאה", name:"Noppharat Thara Pier", note:"מכאן לרוב יוצאות סירות ושייטים מאורגנים."},
          {label:"לב היום", name:"Hong Islands Tour", note:"לגונה, עצירות מים ונקודות שנורקלינג."},
          {label:"חזרה", name:"Ao Nang Beach", note:"אפשר לסיים בארוחה קלה או גלידה ליד הים."}
        ],
        tips: ["עם ילדים עדיף לשקול סירה פרטית", "לבחור יציאה מוקדמת", "לבדוק רוח וים יום קודם", "להביא כובעים ובגדי החלפה"],
        places: ["Noppharat Thara Pier", "Hong Islands Tour", "Ao Nang Beach"]
      },
      {
        title: "יום חופים שקטים – Klong Muang + Tubkaek",
        short_description: "שני חופים רגועים יותר מאו נאנג עם אווירה נעימה ונוף פתוח.",
        vibe: "חוף · רגוע · שקיעה",
        why: "זה יום שמתאים כשלא רוצים אטרקציה אלא פשוט יום טוב. הוא עובד נהדר באזור הלינה של Klong Muang ונותן תחושה הרבה יותר שקטה ופחות תיירותית.",
        stops: [
          {label:"בוקר", name:"Khlong Muang Beach", note:"בוקר רגוע ושחייה נוחה."},
          {label:"צהריים", name:"Dusit Thani Krabi Beach Resort", note:"עצירת אוכל / קפה מול הים."},
          {label:"שקיעה", name:"Tubkaek Beach", note:"סיום יפה ושקט עם נוף פתוח לאיים."}
        ],
        tips: ["לבחור מסעדה עם צל", "להגיע מוקדם כדי ליהנות מהשקט", "להישאר לשקיעה אם הילדים זורמים"],
        places: ["Khlong Muang Beach", "Dusit Thani Krabi Beach Resort", "Tubkaek Beach"]
      },
      {
        title: "יום טבע קל – Emerald Pool",
        short_description: "טבע, מים והליכה יחסית קצרה – בתנאי שמגיעים מוקדם.",
        vibe: "טבע · מים · חצי יום",
        why: "זה יום שנותן תחושת טיול אמיתית בלי מסלול קשה במיוחד. הוא מתאים בעיקר אם יוצאים מוקדם, נשארים בקצב רגוע, ולא בונים עליו יום עמוס מדי.",
        stops: [
          {label:"יציאה", name:"Emerald Pool (Sa Morakot) – Thung Teao Forest", note:"הגעה מוקדמת והליכה קצרה יחסית לבריכה."},
          {label:"אופציונלי", name:"Klong Thom Hot Springs", note:"תוספת רק אם יש כוח ורוצים עוד עצירת מים."},
          {label:"סיום", name:"Ao Nang Beach", note:"חזרה רגועה ואפשרות לארוחת ערב קלילה."}
        ],
        tips: ["לצאת מוקדם מאוד", "להביא מים ונשנושים", "אם חם מדי – לוותר על התחנה השנייה"],
        places: ["Emerald Pool (Sa Morakot) – Thung Teao Forest", "Klong Thom Hot Springs", "Ao Nang Beach"]
      },
      {
        title: "יום חיות + חוף",
        short_description: "חוויה מיוחדת עם פילים ואז זמן רגוע ליד הים.",
        vibe: "חיות · מגוון · רגוע",
        why: "השילוב הזה עובד טוב כי הוא מתחיל בחוויה עם ערך וזיכרון, ומסתיים במשהו קל ולא מחייב. זה יום מגוון בלי להרגיש דחוס מדי.",
        stops: [
          {label:"בוקר", name:"Ao Nang Elephant Sanctuary", note:"סשן בוקר רגוע יותר ומתאים לילדים."},
          {label:"צהריים", name:"Botany Cafe & Eatery", note:"עצירת אוכל / קפה נעימה בדרך חזרה."},
          {label:"אחר הצהריים", name:"Khlong Muang Beach", note:"זמן רגוע בים לסיום היום."}
        ],
        tips: ["להזמין מקום מראש", "להעדיף סשן בוקר", "לא להעמיס עוד אטרקציה אחרי"],
        places: ["Ao Nang Elephant Sanctuary", "Botany Cafe & Eatery", "Khlong Muang Beach"]
      }
    ];

    const hoiAnPlans = [
      {
        title: "יום רגוע של הוי אן",
        short_description: "חוף, קפה יפה ואוכל נוח בלי להתרוצץ.",
        vibe: "רגוע · חוף · קליל",
        why: "זה יום שעובד מצוין בשהות ארוכה: מעט מעברים, הרבה גמישות, ואפשר לעצור בכל שלב בלי להרגיש שהיום נהרס.",
        stops: [
          {label:"בוקר", name:"An Bang Beach", note:"חוף נוח מאוד למשפחה, עדיף בשעות הנעימות."},
          {label:"צהריים", name:"Greek Souvlaki An Bang Beach", note:"אופציית אוכל פשוטה ונוחה ליד החוף."},
          {label:"אחר הצהריים", name:"Roving Chillhouse", note:"עצירת קפה יפה בתוך השדות לסיום רגוע."}
        ],
        tips: ["להתחיל מוקדם", "לא למשוך את החוף לשעות הכי חמות", "להשאיר את הקפה לסוף היום"],
        places: ["An Bang Beach", "Greek Souvlaki An Bang Beach", "Roving Chillhouse"]
      },
      {
        title: "יום יצירה ממוזג",
        short_description: "שתי סדנאות טובות ליום חם או ליום גשם.",
        vibe: "ממוזג · יצירתי · רגוע",
        why: "זה יום מצוין כשלא בא על חוף או על נסיעות. שתי עצירות קצרות יחסית שנותנות ערך אמיתי וגם זיכרון נחמד לקחת הביתה.",
        stops: [
          {label:"בוקר", name:"Hoian Vela Candle & Spa", note:"סדנת נרות נעימה ורגועה."},
          {label:"צהריים", name:"Papa Sushi Hội An", note:"ארוחה קלה באמצע היום."},
          {label:"אחר הצהריים", name:"Alluvia Chocolate House Hội An", note:"סדנת שוקולד כיפית במיוחד לילדים."}
        ],
        tips: ["להזמין סדנאות מראש", "לבדוק גילאים מדויקים לפני ההגעה", "להשאיר זמן ספונטני בין התחנות"],
        places: ["Hoian Vela Candle & Spa", "Papa Sushi Hội An", "Alluvia Chocolate House Hội An"]
      },
      {
        title: "יום כפרים ומים",
        short_description: "ירוק, מים וחוויה מקומית בלי יום קשה.",
        vibe: "טבע · מים · מגוון",
        why: "השילוב בין Tra Que ל-Cam Thanh נותן טעימה טובה מהצד הכפרי של הוי אן. זה יום עשיר יותר, אבל עדיין לא כזה שמרגיש מעייף מדי אם מתחילים מוקדם.",
        stops: [
          {label:"בוקר", name:"Tra Que Vegetable Village", note:"הליכה קצרה, אווירה ירוקה וחוויה כפרית."},
          {label:"צהריים", name:"ECO Coffee and Restaurant", note:"עצירה קלה לפני המים."},
          {label:"אחר הצהריים", name:"Cam Thanh Coconut Village", note:"סירות הסל והיער של הקוקוסים."}
        ],
        tips: ["להתחיל מוקדם", "לבחור מפעיל רגוע בסירות", "לא להעמיס עוד פעילות אחר כך"],
        places: ["Tra Que Vegetable Village", "ECO Coffee and Restaurant", "Cam Thanh Coconut Village"]
      },
      {
        title: "יום קל לעיר העתיקה",
        short_description: "הוי אן הקלאסית, אבל בקצב נוח למשפחה.",
        vibe: "עיר · תרבות · קליל",
        why: "העיר העתיקה יכולה להיות קסומה מאוד עם ילדים אם לא הופכים אותה למרתון. השילוב הזה עובד טוב במיוחד בשעות נעימות ועם עצירה ממוזגת באמצע.",
        stops: [
          {label:"בוקר", name:"Hoi An Ancient Town", note:"שיטוט קצר ונעים בשעות הפחות חמות."},
          {label:"צהריים", name:"Precious Heritage Art Gallery Museum", note:"עצירה רגועה וממוזגת יחסית."},
          {label:"ערב", name:"Hoi An Memories Show", note:"אופציונלי לערב מיוחד פעם אחת במהלך השהות."}
        ],
        tips: ["להעדיף בוקר או ערב לעיר העתיקה", "לא להיכנס ליותר מדי נקודות ביום אחד", "את המופע לשמור ליום עם הרבה אנרגיה"],
        places: ["Hoi An Ancient Town", "Precious Heritage Art Gallery Museum", "Hoi An Memories Show"]
      },
      {
        title: "יום גשם / יום עייפים",
        short_description: "פתרון טוב ליום שלא בא לצאת להרפתקה.",
        vibe: "ממוזג · פשוט · שימושי",
        why: "זה יום שבנוי על מקומות שמצילים שהות ארוכה: משחקייה, יצירה ואוכל פשוט. לא נוצץ, אבל מאוד שימושי בפועל.",
        stops: [
          {label:"בוקר", name:"Vietnam Kids Play Cafe", note:"זמן לפרוק אנרגיה בתוך מקום סגור."},
          {label:"צהריים", name:"grilled.il הבית הישראלי", note:"אוכל מוכר וקל."},
          {label:"אחר הצהריים", name:"PHAP Studio – Painting Workshop", note:"יצירה רגועה לסיום."}
        ],
        tips: ["לבדוק שעות פתיחה באותו יום", "להשאיר גמישות אם הילדים זורמים על המשחקייה", "לא צריך להספיק הכול"],
        places: ["Vietnam Kids Play Cafe", "grilled.il הבית הישראלי", "PHAP Studio – Painting Workshop"]
      }
    ];

    const daNangPlans = [
      {
        title: "יום קליל של הגעה + ערב בעיר",
        short_description: "חוף קרוב, מנוחה טובה וערב עם קצת וואו בלי להעמיס.",
        vibe: "רגוע · ים · ערב",
        why: "זה היום הכי נכון לפתוח איתו את דה נאנג: מעט מעברים, קרוב מאוד למלון, והרבה גמישות לפי האנרגיה של כולם אחרי הדרך.",
        stops: [
          {label:"בוקר / צהריים", name:"My Khe Beach", note:"קפיצה קלה לים או הליכה קצרה ליד החוף."},
          {label:"אחה״צ", name:"Chi House Danang", note:"מנוחה, בריכה או זמן שקט במלון."},
          {label:"ערב", name:"Dragon Bridge", note:"אם זה סוף שבוע או חג – להגיע קצת לפני 21:00."},
          {label:"סיום", name:"Helio Night Market", note:"אוכל ואווירת ערב אם נשאר כוח."}
        ],
        tips: ["לא לבנות על יותר מדי ביום ההגעה", "לבדוק אם יש מופע אש ומים באותו ערב", "אם עייפים – אפשר להסתפק רק בחוף ובארוחת ערב"],
        places: ["My Khe Beach", "Chi House Danang", "Dragon Bridge", "Helio Night Market"]
      },
      {
        title: "יום נוף וטבע קל יחסית",
        short_description: "מערות, תצפיות ונהיגה יפה – בלי יום קשה מדי אם מתחילים מוקדם.",
        vibe: "טבע · נוף · מגוון",
        why: "זה יום שנותן תחושת טיול אמיתית אבל עדיין נשאר בשליטה. יש בו שילוב טוב בין חוויה, נוף והפסקות, בלי להרגיש שנכנסתם למרתון.",
        stops: [
          {label:"בוקר", name:"Marble Mountains", note:"לעשות ממוקד ולהשתמש במעלית."},
          {label:"צהריים", name:"Da Nang Museum of Cham Sculpture", note:"עצירה ממוזגת וקצרה אם רוצים."},
          {label:"אחה״צ", name:"Son Tra Peninsula & Linh Ung Pagoda", note:"נסיעה יפה ועצירות תצפית."},
          {label:"ערב", name:"Asia Park / Sun World Da Nang Downtown", note:"אופציית סיום כיפית אם נשארת אנרגיה."}
        ],
        tips: ["להגיע מוקדם ל‑Marble Mountains", "לא לנסות להספיק הכל בכל תחנה", "אם יש עייפות – לדלג על המוזיאון או על הפארק בערב"],
        places: ["Marble Mountains", "Da Nang Museum of Cham Sculpture", "Son Tra Peninsula & Linh Ung Pagoda", "Asia Park / Sun World Da Nang Downtown"]
      },
      {
        title: "יום גדול – לבחור Ba Na Hills או My Son",
        short_description: "זה היום של האטרקציה הגדולה – פארק מפורסם או אתר עתיקות מרשים.",
        vibe: "יום מלא · מרשים · יותר מאמץ",
        why: "בשלושה ימים אין טעם לעשות גם Ba Na Hills וגם My Son אלא אם ממש חשוב לכם. עדיף לבחור אחד לפי מצב הרוח: Ba Na ליום ׳וואו׳ תיירותי, או My Son ליום תרבותי ושקט יותר.",
        stops: [
          {label:"אופציה 1", name:"Ba Na Hills & Golden Bridge", note:"יום ארוך, יפה ועמוס יותר."},
          {label:"אופציה 2", name:"My Son Sanctuary", note:"מרשים מאוד, אבל חם יותר ועם פחות ׳אקשן׳ לילדים."},
          {label:"סיום", name:"My Khe Beach", note:"אם נשאר כוח – עצירת ים קצרה או ארוחה קרובה למלון."}
        ],
        tips: ["לבחור רק אחת מהאופציות", "לצאת מוקדם", "להתחשב במזג האוויר", "עם ילד עייף – עדיף להעדיף יום רגוע יותר בעיר"],
        places: ["Ba Na Hills & Golden Bridge", "My Son Sanctuary", "My Khe Beach"]
      }
    ];


    const dalatPlans = [
      {
        title: "יום קלאסי במרכז דאלאת",
        short_description: "אטרקציות קרובות יחסית, בלי נסיעות ארוכות.",
        vibe: "עיר · קליל · מתאים ליום ראשון",
        why: "יום טוב לפתיחה כי הכול יחסית נגיש, יש שילוב של אטרקציה מיוחדת, אגם, שוק ותחנת רכבת, ואפשר לקצר בכל שלב.",
        stops: [
          {label:"בוקר", name:"Crazy House", note:"להגיע מוקדם ולהשגיח במדרגות."},
          {label:"צהריים", name:"Xuan Huong Lake", note:"הליכה קצרה או סירות פדלים."},
          {label:"אחה״צ", name:"Dalat Railway Station", note:"עצירה צבעונית ואפשרות לרכבת קצרה."},
          {label:"ערב", name:"Dalat Night Market", note:"שוק ערב, אוכל רחוב וקינוחים."}
        ],
        tips: ["לא למשוך את Crazy House אם הילדים מתעייפים", "השוק יכול להיות עמוס", "להשאיר את הערב גמיש"],
        places: ["Crazy House", "Xuan Huong Lake", "Dalat Railway Station", "Dalat Night Market"]
      },
      {
        title: "יום רכבל, אגם ומפלים",
        short_description: "היום הכי מאוזן לטבע קל וחוויה לילדים.",
        vibe: "טבע · מים · רכבל",
        why: "זה אחד הימים הכי חזקים בדאלאת: רכבל, מנזר, אגם ומפל עם Alpine Coaster, בלי להפוך את זה לטרק קשה.",
        stops: [
          {label:"בוקר", name:"Robin Hill Cable Car", note:"רכבל עם נוף לעיר ולעמקים."},
          {label:"המשך", name:"Truc Lam Zen Monastery", note:"עצירה רגועה וקצרה."},
          {label:"צהריים", name:"Tuyen Lam Lake", note:"קפה או עצירה ליד האגם."},
          {label:"אחה״צ", name:"Datanla Waterfall & Alpine Coaster", note:"המזחלות הן גולת הכותרת."}
        ],
        tips: ["לבדוק מזג אוויר לפני הרכבל", "להגיע לדאטנלה לא מאוחר מדי", "לא להוסיף עוד מפל באותו יום"],
        places: ["Robin Hill Cable Car", "Truc Lam Zen Monastery", "Tuyen Lam Lake", "Datanla Waterfall & Alpine Coaster"]
      },
      {
        title: "יום חוות וחיות",
        short_description: "יום חווייתי לילדים עם חיות, תותים וקפה.",
        vibe: "חיות · חווה · ילדים",
        why: "זה היום הכי מתאים לילדים קטנים: הרבה חיות, מרחב פתוח, תותים ואטרקציות שמרגישות טבעיות ולא עירוניות.",
        stops: [
          {label:"בוקר", name:"Puppy Farm", note:"להגיע מוקדם לפני עומס."},
          {label:"צהריים", name:"Dalat Blue Mountain Farm", note:"סיור חווה, חיות וקפה."},
          {label:"אופציונלי", name:"Strawberry Farm Dalat", note:"קטיף או קנייה של תותים אם יש כוח."}
        ],
        tips: ["לתאם מראש את Blue Mountain Farm", "להביא בגדים נוחים", "זה יום שיכול להתארך אז לא להעמיס ערב"],
        places: ["Puppy Farm", "Dalat Blue Mountain Farm", "Strawberry Farm Dalat"]
      },
      {
        title: "יום נופים ופרחים",
        short_description: "יום יפה ופוטוגני עם גנים, פרחים ותצפיות.",
        vibe: "נוף · פרחים · רגוע",
        why: "מתאים ליום שבו רוצים לראות את הצד היפה והצבעוני של דאלאת בלי הרבה מאמץ פיזי.",
        stops: [
          {label:"בוקר", name:"Valley of Love", note:"פארק גדול עם גנים ואגם."},
          {label:"צהריים", name:"Fresh Garden Dalat", note:"גן פרחים וקפה."},
          {label:"אחה״צ", name:"Van Thanh Flower Village", note:"כפר פרחים וחממות."}
        ],
        tips: ["להתחיל מוקדם", "לבחור רק 2 תחנות אם הילדים עייפים", "מתאים פחות לגשם חזק"],
        places: ["Valley of Love", "Fresh Garden Dalat", "Van Thanh Flower Village"]
      },
      {
        title: "יום מערב דאלאת",
        short_description: "יום טיול ארוך יותר עם קפה, מפל ופגודה.",
        vibe: "יום מלא · נוף · יותר נסיעה",
        why: "מתאים אם רוצים יום מחוץ למרכז עם תחושה של טיול אמיתי. לא הייתי עושה אותו ביום עייף.",
        stops: [
          {label:"בוקר", name:"Me Linh Coffee Garden", note:"קפה עם נוף למטעים."},
          {label:"המשך", name:"Elephant Waterfall", note:"מרשים אבל פחות מתאים לילדים קטנים – בזהירות."},
          {label:"צהריים", name:"Linh An Pagoda", note:"פגודה גדולה ליד האזור."},
          {label:"אופציונלי", name:"Silk Factory Dalat", note:"עצירה תרבותית קצרה אם זה על הדרך."}
        ],
        tips: ["לא מומלץ ביום גשום", "להיזהר מאוד באזור המפל", "אפשר לוותר על Elephant Waterfall עם ילד קטן"],
        places: ["Me Linh Coffee Garden", "Elephant Waterfall", "Linh An Pagoda", "Silk Factory Dalat"]
      },
      {
        title: "יום גשם / יום רגוע",
        short_description: "מקומות סגורים, משחקיות וקפה לילדים.",
        vibe: "גשם · משחקיות · קל",
        why: "דאלאת יכולה להיות קרירה וגשומה, וזה יום שנועד להציל תוכנית בלי להסתובב בחוץ יותר מדי.",
        stops: [
          {label:"בוקר", name:"Joy Dalat Kids Café", note:"קפה עם אזור משחק לילדים."},
          {label:"צהריים", name:"Ladalat Kids Playground", note:"משחקייה סגורה להוצאת אנרגיה."},
          {label:"אחה״צ", name:"Langfarm Center", note:"טעימות וקניות של מוצרים מקומיים."},
          {label:"ערב", name:"Dalat Night Market", note:"רק אם הגשם נרגע ויש כוח."}
        ],
        tips: ["לבדוק שעות של המשחקיות לפני הגעה", "לשמור את היום הזה כגיבוי", "לא חייבים לעשות את כל התחנות"],
        places: ["Joy Dalat Kids Café", "Ladalat Kids Playground", "Langfarm Center", "Dalat Night Market"]
      }
    ];




    const hcmcPlans = [
      {
        title: "יום ראשון רגוע בעיר",
        short_description: "פארק גדול, קניון נוח ותצפית אם נשאר כוח.",
        vibe: "רגוע · עיר · קל",
        why: "יום טוב לפתיחה כי הוא לא דורש הרבה לוגיסטיקה ונותן שילוב של חוץ, מזגן ואוכל נוח.",
        stops: [
          {label:"בוקר", name:"Vinhomes Central Park", note:"מרחב פתוח, הליכה קלה ומשחק."},
          {label:"צהריים", name:"Vincom Landmark 81", note:"אוכל, מזגן ומנוחה."},
          {label:"אופציונלי", name:"Landmark 81 SkyView", note:"תצפית קצרה אם הילדים זורמים."}
        ],
        tips: ["להתחיל בחוץ לפני החום", "להשאיר את התצפית כאופציה", "אפשר לקצר בקלות"],
        places: ["Vinhomes Central Park", "Vincom Landmark 81", "Landmark 81 SkyView"]
      },
      {
        title: "יום ילדים מקורה",
        short_description: "עיר ילדים או משחקייה גדולה + קניון נוח.",
        vibe: "גשום · ממוזג · ילדים",
        why: "זה היום ששומר לכם על שפיות כשחם או גשום: מקום אחד גדול לילדים, אוכל ומזגן.",
        stops: [
          {label:"בוקר", name:"Vietopia", note:"פעילות מרכזית של כמה שעות."},
          {label:"צהריים", name:"Thiso Mall Sala", note:"אוכל ומנוחה בקניון."},
          {label:"אחה״צ", name:"Kiwooza Planet – Thiso Mall Sala", note:"אם עדיין יש אנרגיה."}
        ],
        tips: ["לא חייבים גם Vietopia וגם Kiwooza באותו יום", "לבדוק שעות מראש", "להביא גרביים למשחקיות"],
        places: ["Vietopia", "Thiso Mall Sala", "Kiwooza Planet – Thiso Mall Sala"]
      },
      {
        title: "יום גן חיות ומרכז העיר",
        short_description: "חיות בבוקר, מדרחוב ונהר לקראת ערב.",
        vibe: "חיות · עיר · ערב",
        why: "יום מאוזן שמתחיל בפעילות לילדים ומסתיים במקומות עירוניים קלים בלי מוזיאון כבד.",
        stops: [
          {label:"בוקר", name:"Saigon Zoo & Botanical Gardens", note:"להגיע מוקדם לפני החום."},
          {label:"צהריים", name:"Vietnam History Museum", note:"רק אם יש כוח, קרוב לגן החיות."},
          {label:"אחה״צ", name:"Bach Dang Riverside Park", note:"הליכה קצרה ליד הנהר."},
          {label:"ערב", name:"Nguyen Hue Walking Street", note:"גלידה, אורות ואווירה."}
        ],
        tips: ["אפשר לוותר על המוזיאון", "להגיע לגן החיות מוקדם", "בערב לא למשוך יותר מדי"],
        places: ["Saigon Zoo & Botanical Gardens", "Vietnam History Museum", "Bach Dang Riverside Park", "Nguyen Hue Walking Street"]
      },
      {
        title: "יום Sala ו-Global City",
        short_description: "קניון, משחקייה, פארק ומתחם ערב מודרני.",
        vibe: "מודרני · נוח · משפחתי",
        why: "יום קל מאוד מבחינת לוגיסטיקה, עם הרבה נקודות עצירה קצרות שמתאימות למשפחה בעיר גדולה.",
        stops: [
          {label:"בוקר", name:"Sala Park", note:"סיבוב ירוק קצר."},
          {label:"צהריים", name:"Thiso Mall Sala", note:"אוכל ומזגן."},
          {label:"אחה״צ", name:"The Global City Playground", note:"משחקים לילדים."},
          {label:"ערב", name:"The Global City", note:"סיבוב ערב קליל."}
        ],
        tips: ["טוב במיוחד ליום חם", "לא חייבים להספיק הכול", "לבדוק אירועים ב-Global City"],
        places: ["Sala Park", "Thiso Mall Sala", "The Global City Playground", "The Global City"]
      },
      {
        title: "יום District 7 רגוע",
        short_description: "אגם, קניון וגשר מואר לערב.",
        vibe: "רגוע · ערב · משפחתי",
        why: "יום נעים ופחות אינטנסיבי, טוב במיוחד אם רוצים לצאת מהמרכז הצפוף אבל לא לנסוע רחוק מדי.",
        stops: [
          {label:"בוקר/צהריים", name:"Crescent Mall", note:"אוכל, מזגן וקצת קניות."},
          {label:"אחה״צ", name:"Crescent Lake & Starlight Bridge", note:"הליכה רגועה סביב האגם."},
          {label:"ערב", name:"Starlight Bridge", note:"יפה יותר כשהאורות נדלקים."}
        ],
        tips: ["להגיע לקראת אחה״צ", "זה יום רגוע ולא יום אטרקציות", "מתאים אחרי יום עמוס"],
        places: ["Crescent Mall", "Crescent Lake & Starlight Bridge", "Starlight Bridge"]
      },
      {
        title: "יום בתי קפה מיוחדים ב-Thu Duc",
        short_description: "נקודות עצירה יפות וקפה, לא אטרקציות כבדות.",
        vibe: "קפה · פרחים · קצר",
        why: "היום הזה טוב כשרוצים משהו יפה וקל בלי להיכנס למוזיאון או משחקייה. כל מקום הוא עצירה קצרה, לא יעד של חצי יום.",
        stops: [
          {label:"בוקר", name:"Cái Tổ Chim", note:"גן קפה עם פרחים ומים."},
          {label:"המשך", name:"Vườn Thiên Giới", note:"מערות, מים וגנים."},
          {label:"אופציונלי", name:"Nhà Có Một Vườn Hoa", note:"קפה פרחים נוסף אם הילדים זורמים."}
        ],
        tips: ["לא צריך לעשות את כל המקומות", "מתאים לשעתיים-שלוש", "לשלב עם Thiso Mall או Global City אם נמצאים באזור"],
        places: ["Cái Tổ Chim", "Vườn Thiên Giới", "Nhà Có Một Vườn Hoa"]
      },
      {
        title: "טיול יום מחוץ לעיר",
        short_description: "לבחור אחד: מקונג, קו צ׳י או קאן ג׳יו.",
        vibe: "יום מלא · יותר לוגיסטיקה",
        why: "בשבוע בעיר אפשר לבחור יום אחד מחוץ להו צ׳י מין. לא הייתי עושה יותר מאחד עם ילדים קטנים.",
        stops: [
          {label:"אופציה 1", name:"Mekong Delta Day Tour", note:"הכי משפחתי וקלאסי."},
          {label:"אופציה 2", name:"Cu Chi Tunnels", note:"יותר היסטורי ופחות לילדים קטנים."},
          {label:"אופציה 3", name:"Can Gio Monkey Island", note:"טבע וקופים, אבל דורש זהירות."}
        ],
        tips: ["לבחור רק אחד", "לסגור סיור פרטי/קטן אם אפשר", "לוודא מזגן ורכב נוח"],
        places: ["Mekong Delta Day Tour", "Cu Chi Tunnels", "Can Gio Monkey Island"]
      }
    ];


    // Curated full-day options per destination
    const plans = [];
    if(currentDestination === "krabi"){
      if(mode === "hot"){
        plans.push(krabiPlans[0], krabiPlans[1], krabiPlans[2]);
      } else if(mode === "rain"){
        plans.push(krabiPlans[0], krabiPlans[4]);
      } else if(mode === "tired"){
        plans.push(krabiPlans[0], krabiPlans[2]);
      } else {
        plans.push(...krabiPlans);
      }
    } else if(currentDestination === "hoi_an"){
      if(mode === "hot"){
        plans.push(hoiAnPlans[1], hoiAnPlans[4], hoiAnPlans[0]);
      } else if(mode === "rain"){
        plans.push(hoiAnPlans[4], hoiAnPlans[1]);
      } else if(mode === "tired"){
        plans.push(hoiAnPlans[0], hoiAnPlans[4]);
      } else {
        plans.push(...hoiAnPlans);
      }
    } else if(currentDestination === "da_nang"){
      if(mode === "hot"){
        plans.push(daNangPlans[0], daNangPlans[1]);
      } else if(mode === "rain"){
        plans.push(daNangPlans[0]);
      } else if(mode === "tired"){
        plans.push(daNangPlans[0], daNangPlans[2]);
      } else {
        plans.push(...daNangPlans);
      }
    } else if(currentDestination === "dalat"){
      if(mode === "rain"){
        plans.push(dalatPlans[5], dalatPlans[0]);
      } else if(mode === "tired"){
        plans.push(dalatPlans[0], dalatPlans[3], dalatPlans[5]);
      } else if(mode === "hot"){
        plans.push(dalatPlans[1], dalatPlans[2], dalatPlans[5]);
      } else {
        plans.push(...dalatPlans);
      }
    } else if(currentDestination === "hcmc"){
      if(mode === "rain"){
        plans.push(hcmcPlans[1], hcmcPlans[0], hcmcPlans[5]);
      } else if(mode === "tired"){
        plans.push(hcmcPlans[0], hcmcPlans[4], hcmcPlans[5]);
      } else if(mode === "hot"){
        plans.push(hcmcPlans[1], hcmcPlans[3], hcmcPlans[0]);
      } else {
        plans.push(...hcmcPlans);
      }
    } else if(currentDestination === "bangkok"){
      plans.push({
        title: "יום רגוע ליד המלון",
        short_description: "יום קל יחסית עם מעט מעברים והרבה גמישות.",
        vibe: "עיר · קליל",
        why: "נוח ליום מעבר או ליום שאין בו רצון להתרוצץ יותר מדי.",
        stops: [
          {label:"בוקר", name:"Siam Serpentarium"},
          {label:"צהריים", name:"Thai-Kor (The Paseo Mall)"},
          {label:"אחה״צ", name:"Hua Takhe Old Market"},
          {label:"ערב", name:"The First Lounge (Gate43 Hotel Restaurant)"}
        ],
        tips: [],
        places: ["Siam Serpentarium", "Thai-Kor (The Paseo Mall)", "Hua Takhe Old Market", "The First Lounge (Gate43 Hotel Restaurant)"]
      });
      plans.push({
        title: "יום אאוטלטים קלילים (קרוב לשדה)",
        short_description: "קניות, אוכל ונקודות עצירה נוחות ליד שדה התעופה.",
        vibe: "קניות · קליל",
        why: "מתאים אם רוצים יום פשוט שמבוסס על מקומות נוחים וממוזגים.",
        stops: [
          {label:"בוקר", name:"Central Village – Bangkok Luxury Outlet"},
          {label:"צהריים", name:"The First Lounge (Gate43 Hotel Restaurant)"},
          {label:"אחה״צ", name:"Siam Premium Outlets Bangkok"},
          {label:"ערב", name:"Chocolate Ville"}
        ],
        tips: [],
        places: ["Central Village – Bangkok Luxury Outlet", "The First Lounge (Gate43 Hotel Restaurant)", "Siam Premium Outlets Bangkok", "Chocolate Ville"]
      });
      plans.push({
        title: "יום משחקים + קניון",
        short_description: "פתרון נוח ליום חם עם הרבה זמן בפנים.",
        vibe: "ממוזג · ילדים",
        why: "זה יום נוח במיוחד אם מחפשים פעילות קלה וממוזגת.",
        stops: [
          {label:"בוקר", name:"HarborLand – MEGA Bangna"},
          {label:"צהריים", name:"Sizzler (Mega Bangna)"},
          {label:"אחה״צ", name:"MEGA Bangna (קניון)"},
          {label:"ערב", name:"Chocolate Ville"}
        ],
        tips: [],
        places: ["HarborLand – MEGA Bangna", "Sizzler (Mega Bangna)", "MEGA Bangna (קניון)", "Chocolate Ville"]
      });
    } else {
      const hasTag = (it, t) => (it.tags || []).includes(t);
      const score = (it) => Number(it.score) || 0;
      const mins = (it) => parseMin(it.distance_min) ?? 9999;

      let pool = poolAll.filter(isAttraction);

      if(mode === "hot"){
        pool = pool.filter(it => hasTag(it, "ac") || hasTag(it, "water"));
      } else if(mode === "rain"){
        pool = pool.filter(it => hasTag(it, "rain") || hasTag(it, "ac"));
      } else if(mode === "tired"){
        pool = pool.filter(it => hasTag(it, "short")).sort((a,b)=> mins(a) - mins(b));
      }

      pool.sort((a,b)=> (score(b) - score(a)) || (mins(a) - mins(b)));

      const morning = pool[0];
      const afternoon = pool[1] || pool[0];

      const restaurants = poolAll.filter(isRestaurant).sort((a,b)=> (score(b)-score(a)) || (mins(a)-mins(b)));
      const lunch = restaurants[0];
      const dinner = restaurants[1] || restaurants[0];

      if(!morning){
        alert("לא מצאתי מספיק נתונים לבניית יום. נסי לשנות מצב 🙂");
        return;
      }

      plans.push({
        title: "יום מומלץ (אוטומטי)",
        short_description: "שילוב אוטומטי של בוקר, צהריים ואחה״צ לפי הנתונים באתר.",
        vibe: "אוטומטי",
        why: "בחירה מהירה כשלא בא לבנות ידנית.",
        stops: [
          {label:"בוקר", name: morning.name},
          {label:"צהריים", name: lunch ? lunch.name : "—"},
          {label:"אחה״צ", name: afternoon.name},
          {label:"ערב", name: dinner ? dinner.name : "—"}
        ],
        tips: [],
        places: [morning.name, lunch ? lunch.name : null, afternoon.name, dinner ? dinner.name : null].filter(Boolean)
      });
    }

    const planHtml = (plan) => {
      const items = plan.stops.map(s => {
        const it = poolAll.find(x => x.name === s.name);
        if(!it){
          return `<div class="dayStop"><div class="dayLabel">${escapeHtml(s.label)}</div><div class="dayName">${escapeHtml(s.name || "—")}</div></div>`;
        }
        return `<div class="dayStop">
          <div class="dayLabel">${escapeHtml(s.label)}</div>
          <a href="#" class="dayName" data-action="focus" data-id="${escapeHtml(it._id)}">${escapeHtml(it.name)}</a>
          ${s.note ? `<div class="dayNote">${escapeHtml(s.note)}</div>` : ``}
        </div>`;
      }).join("");

      const tips = (plan.tips || []).length
        ? `<div class="dayTips"><strong>טיפים:</strong> ${(plan.tips || []).map(t => `<span>${escapeHtml(t)}</span>`).join(" · ")}</div>`
        : ``;

      return `<div class="dayPlan">
        <div class="dayPlanTitle">🗓️ ${escapeHtml(plan.title)}</div>
        ${plan.short_description ? `<div class="dayPlanShort">${escapeHtml(plan.short_description)}</div>` : ``}
        ${plan.vibe ? `<div class="dayPlanVibe">${escapeHtml(plan.vibe)}</div>` : ``}
        <div class="dayStops">${items}</div>
        ${plan.why ? `<div class="dayWhy"><strong>למה זה עובד:</strong> ${escapeHtml(plan.why)}</div>` : ``}
        ${tips}
        <div class="dayPlanActions">
          <button class="linkBtn" data-action="plan-map" data-plan="${escapeHtml(plan.title)}" type="button">📍 כל התחנות על המפה</button>
          <a class="linkBtn" data-action="openLink" target="_blank" rel="noopener" href="${escapeHtml(buildPlanRouteHref(plan))}">פתחי מסלול</a>
        </div>
      </div>`;
    };

    resetAll();
    elCount.textContent = `ימי טיול מוכנים: ${plans.length}`;
    elCards.innerHTML = plans.map(planHtml).join("");

    Array.from(document.querySelectorAll("[data-action='focus']")).forEach(btn=>{
      btn.addEventListener("click", (e)=>{
        e.preventDefault();
        const id = btn.getAttribute("data-id");
        const item = raw.find(i => i._id === id);
        if(item){
          setMap(item);
          if(window.innerWidth < 900){
            document.querySelector(".mapPane")?.scrollIntoView({behavior:"smooth"});
          }
        }
      });
    });

    Array.from(document.querySelectorAll("[data-action='plan-map']")).forEach(btn=>{
      btn.addEventListener("click", (e)=>{
        e.preventDefault();
        const title = btn.getAttribute("data-plan");
        const plan = plans.find(p => p.title === title);
        if(plan){
          setPlanMap(plan);
          if(window.innerWidth < 900){
            document.querySelector(".rightPane")?.scrollIntoView({behavior:"smooth"});
          }
        }
      });
    });

    Array.from(document.querySelectorAll("[data-action='openLink']")).forEach(a=>{
      a.addEventListener("click", (e)=>{ e.stopPropagation(); });
    });

    if(plans[0]) setPlanMap(plans[0]);
    window.scrollTo({top: 0, behavior: "smooth"});
  }



  // Assign stable ids
  raw.forEach((it, idx)=>{
    it._id = `${idx}-${(it.name||"").replace(/\s+/g,'-').slice(0,24)}`;
  });

  // Wire events
  [elSearch, elCategory, elMinScore, elSortBy].forEach(el => el.addEventListener("input", render));
  if(elDestination){
    elDestination.addEventListener("change", ()=>{
      currentDestination = elDestination.value || "koh_samui";
      populateCategories(currentDestination);
      updateHeaderTitle();
      // reset category selection when switching destination
      elCategory.value = "";
      resetAll();
      // keep destination selection
      if(elDestination) elDestination.value = currentDestination;
      setDefaultMap();
      render();
    });
  }
  elTags.addEventListener("change", render);
  elReset.addEventListener("click", resetAll);
  elBuild.addEventListener("click", buildDay);

  elModalOverlay.addEventListener("click", closeGallery);
  elCloseModal.addEventListener("click", closeGallery);

  // How-to modal listeners
  if(elHowToBtn) elHowToBtn.addEventListener("click", openHowTo);
  if(elHowToOverlay) elHowToOverlay.addEventListener("click", closeHowTo);
  if(elCloseHowTo) elCloseHowTo.addEventListener("click", closeHowTo);
  document.addEventListener("keydown", (e)=>{
    if(e.key !== "Escape") return;
    if(elModal && elModal.getAttribute("aria-hidden") === "false") closeGallery();
    if(elHowTo && elHowTo.getAttribute("aria-hidden") === "false") closeHowTo();
  });

  // Initial map should be base if exists
  const base = raw.find(isBase);
  if(base){
    setMap(base);
  }

  render();
})();
